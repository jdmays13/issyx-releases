# Issyx Imaging Platform - Installation Guide

Install and deploy the Issyx Imaging Platform with PXE boot support.

---

## Installation Options

| Method | Best For | Docker Required |
|--------|----------|-----------------|
| **Standalone** (Recommended) | Production, LXC containers, bare metal | No |
| **Docker** | Development, quick testing | Yes |

---

## Standalone Installation (Recommended)

Install directly on Ubuntu/Debian without Docker. Similar to FOG Project installation.

### Requirements

- **OS:** Ubuntu 22.04+ or Debian 12+
- **RAM:** 4GB minimum (8GB recommended)
- **Disk:** 100GB (500GB+ for OS images)
- **Network:** Gigabit Ethernet with **static IP** (critical for PXE)
- **Access:** Root/sudo privileges

### Quick Install

```bash
# Download latest release
wget https://github.com/jdmays13/issyx-releases/releases/download/v2.5.1/issyx-v2.5.1.tar.gz

# Extract
tar -xzf issyx-v2.5.1.tar.gz
cd issyx-imaging-platform

# Run the standalone installer
sudo ./install-standalone.sh
```

Or use curl:
```bash
curl -LO https://github.com/jdmays13/issyx-releases/releases/download/v2.5.1/issyx-v2.5.1.tar.gz
tar -xzf issyx-v2.5.1.tar.gz
cd issyx-imaging-platform
sudo ./install-standalone.sh
```

### What the Installer Does

1. **Verifies network configuration** - Detects IP, gateway, netmask, DNS
2. **Checks for static IP** - Warns if DHCP is detected (PXE needs static)
3. **Prompts for confirmation** - Ensures IP is correct before proceeding
4. **Installs system packages** - Python 3, PostgreSQL, Redis, Nginx, TFTP, Node.js
5. **Creates directory structure** - `/opt/issyx`, `/data/issyx`, `/var/lib/tftpboot`
6. **Configures PostgreSQL** - Creates database and user
7. **Configures Redis** - Sets up caching
8. **Installs Python dependencies** - FastAPI, SQLAlchemy, etc.
9. **Builds frontend** - Compiles React app with Vite
10. **Configures Nginx** - Reverse proxy for API and frontend
11. **Configures TFTP** - PXE boot file server
12. **Initializes database** - Creates tables and default settings
13. **Auto-configures** - Sets server IP, WinPE endpoint, TFTP path
14. **Starts services** - Backend, Nginx, Redis, PostgreSQL, TFTP
15. **Runs setup wizard** - Creates first admin user

### Network Configuration (Important!)

The installer will detect your current network configuration:

```
Current Network Configuration:
  Interface:  eth0
  IP Address: 10.0.1.25
  Gateway:    10.0.1.1
  Netmask:    /24
  DNS:        1.1.1.1 8.8.8.8

⚠️  WARNING: IP address may be DHCP-assigned
For a PXE server, a STATIC IP is strongly recommended.
```

**For Proxmox LXC containers:**
- Configure static IP in Proxmox BEFORE running installer
- Container → Network → Edit → Set IPv4 to Static
- Or: `pct set <CTID> -net0 name=eth0,bridge=vmbr0,ip=10.0.1.25/24,gw=10.0.1.1`

**For bare metal:**
- Configure static IP via netplan or /etc/network/interfaces
- Example netplan (`/etc/netplan/01-netcfg.yaml`):
```yaml
network:
  version: 2
  ethernets:
    eth0:
      addresses: [10.0.1.25/24]
      gateway4: 10.0.1.1
      nameservers:
        addresses: [1.1.1.1, 8.8.8.8]
```

### Post-Installation

After successful installation:

```
============================================
  Issyx Imaging Platform Installed!
============================================

Access URLs:
  Web Interface: http://10.0.1.25
  API Docs:      http://10.0.1.25/docs
  PXE Endpoint:  http://10.0.1.25:8000/api/v1

Configuration:
  Install Dir:   /opt/issyx
  Data Dir:      /data/issyx
  TFTP Root:     /var/lib/tftpboot
  Config File:   /etc/issyx/config.env
  Logs:          /var/log/issyx/

Services:
  ✓ PostgreSQL:  Running
  ✓ Redis:       Running
  ✓ Backend:     Running (port 8001 internal, proxied via Nginx)
  ✓ Nginx:       Running (ports 80 and 8000)
  ✓ TFTP:        Running (port 69)

Next Steps:
  1. Open http://10.0.1.25 in your browser
  2. Complete the setup wizard to create admin account
  3. Configure your DHCP server with PXE options
  4. Upload OS images and drivers
  5. Create master profiles and jobs
```

### Service Management

```bash
# View service status
sudo systemctl status issyx-backend
sudo systemctl status nginx
sudo systemctl status postgresql
sudo systemctl status redis-server
sudo systemctl status tftpd-hpa

# View logs
sudo tail -f /var/log/issyx/backend.log
sudo tail -f /var/log/issyx/backend.error.log
sudo journalctl -u issyx-backend -f

# Restart services
sudo systemctl restart issyx-backend
sudo systemctl restart nginx

# Stop/Start all Issyx services
sudo systemctl stop issyx-backend
sudo systemctl start issyx-backend
```

### Directory Structure

```
/opt/issyx/                    # Application directory
├── backend/                   # FastAPI backend code
├── frontend/                  # Built React frontend
├── venv/                      # Python virtual environment
└── boot-files/                # PXE boot configuration

/data/issyx/                   # Data storage
├── images/                    # OS images (WIM, ISO)
├── drivers/                   # Driver packages
├── software/                  # Software installers
├── scripts/                   # Custom scripts
└── backups/                   # Database backups

/var/lib/tftpboot/             # TFTP root (PXE files)
├── undionly.kpxe             # iPXE bootloader
├── boot.ipxe                 # Boot script
└── issyx/                    # Issyx-specific boot files

/etc/issyx/                    # Configuration
└── config.env                # Environment variables

/var/log/issyx/                # Application logs
├── backend.log               # Application logs
└── backend.error.log         # Error logs
```

---

## Docker Installation (Development)

For development or quick testing environments.

### Requirements

- **OS:** Ubuntu 20.04+, Debian 11+, or any Docker-supported OS
- **Docker:** Docker Engine 20.10+
- **Docker Compose:** v2.0+
- **RAM:** 4GB minimum
- **Disk:** 50GB minimum

### Quick Start

```bash
# Clone repository
git clone https://github.com/issyx/issyx-imaging-platform.git
cd issyx-imaging-platform

# Copy environment template
cp .env.example .env

# Edit configuration
nano .env

# Start services
docker compose up -d

# View logs
docker compose logs -f
```

### Docker Services

- **Frontend:** http://localhost:3000
- **Backend API:** http://localhost:8000
- **API Docs:** http://localhost:8000/docs
- **PostgreSQL:** localhost:5432
- **Redis:** localhost:6379

### Docker Commands

```bash
# Start services
docker compose up -d

# Stop services
docker compose down

# View logs
docker compose logs -f backend

# Rebuild after code changes
docker compose build
docker compose up -d

# Reset database (caution: data loss)
docker compose down -v
docker compose up -d
```

---

## Initial Setup

After installation, complete the setup wizard:

1. **Open Web Interface**
   - Standalone: http://YOUR_SERVER_IP
   - Docker: http://localhost:3000

2. **Create Admin Account**
   - Enter email and password
   - Account will have full administrative access

3. **Configure System Settings** (auto-populated for standalone)
   - Network Interface (read-only)
   - WinPE API Endpoint (read-only)
   - TFTP Root Path

4. **Upload Resources**
   - Operating Systems (Windows WIM images)
   - Drivers (INF packages)
   - Software (MSI/EXE installers)
   - Scripts (PowerShell/batch)

5. **Create Master Profile**
   - Select OS
   - Add drivers
   - Add software
   - Add post-install scripts

6. **Create Imaging Job**
   - Select customer
   - Select master profile
   - Configure job options
   - Start job

---

## DHCP Configuration

The Issyx server does NOT include a DHCP server. You need to configure your existing DHCP server (router, Windows Server, ISC DHCP) with PXE boot options.

### Option 1: Router/Firewall DHCP

Add these DHCP options:
- **Next Server (Option 66):** Your Issyx server IP (e.g., 10.0.1.25)
- **Boot Filename (Option 67):** `undionly.kpxe`

### Option 2: Windows Server DHCP

1. Open DHCP Manager
2. Right-click Server → Set Predefined Options
3. Add Option 66 (Boot Server Host Name): `10.0.1.25`
4. Add Option 67 (Bootfile Name): `undionly.kpxe`
5. Apply to scope

### Option 3: ISC DHCP Server

Add to `/etc/dhcp/dhcpd.conf`:

```conf
subnet 10.0.1.0 netmask 255.255.255.0 {
  range 10.0.1.100 10.0.1.200;
  option routers 10.0.1.1;
  option domain-name-servers 1.1.1.1, 8.8.8.8;

  # PXE Boot Options
  next-server 10.0.1.25;
  filename "undionly.kpxe";
}
```

---

## Firewall Configuration

### Required Ports

| Port | Protocol | Service | Description |
|------|----------|---------|-------------|
| 80 | TCP | Nginx | Web interface |
| 8000 | TCP | Nginx | PXE API endpoint |
| 69 | UDP | TFTP | PXE boot files |
| 5432 | TCP | PostgreSQL | Database (internal only) |
| 6379 | TCP | Redis | Cache (internal only) |

### UFW (Ubuntu/Debian)

```bash
sudo ufw allow 80/tcp
sudo ufw allow 8000/tcp
sudo ufw allow 69/udp
sudo ufw enable
```

### firewalld (CentOS/Rocky)

```bash
sudo firewall-cmd --permanent --add-port=80/tcp
sudo firewall-cmd --permanent --add-port=8000/tcp
sudo firewall-cmd --permanent --add-port=69/udp
sudo firewall-cmd --reload
```

---

## Troubleshooting

### Standalone Installation Issues

**Backend not starting:**
```bash
sudo systemctl status issyx-backend
sudo journalctl -u issyx-backend -n 100
# Check for Python import errors or database connection issues
```

**Database connection failed:**
```bash
sudo systemctl status postgresql
sudo -u postgres psql -c "\l"  # List databases
sudo -u postgres psql -d issyx -c "\dt"  # List tables
```

**Frontend not loading:**
```bash
sudo systemctl status nginx
sudo nginx -t  # Test configuration
sudo tail -f /var/log/nginx/error.log
```

**TFTP not working:**
```bash
sudo systemctl status tftpd-hpa
tftp localhost -c get undionly.kpxe  # Test TFTP
ls -la /var/lib/tftpboot/
```

### Docker Installation Issues

**Containers not starting:**
```bash
docker compose ps
docker compose logs
```

**Database errors:**
```bash
docker compose logs db
docker compose exec db psql -U issyx -d issyx
```

**Network connectivity:**
```bash
docker compose exec backend curl http://localhost:8000/health
```

---

## Upgrading

### Standalone

```bash
cd /opt/issyx
git pull origin main
sudo systemctl restart issyx-backend
```

### Docker

```bash
cd /path/to/issyx-imaging-platform
git pull origin main
docker compose build
docker compose up -d
```

---

## Backup & Restore

### Database Backup

```bash
# Standalone
sudo -u postgres pg_dump issyx > /data/issyx/backups/issyx_$(date +%Y%m%d).sql

# Docker
docker compose exec db pg_dump -U issyx issyx > backup.sql
```

### Database Restore

```bash
# Standalone
sudo -u postgres psql issyx < /data/issyx/backups/issyx_backup.sql

# Docker
docker compose exec -T db psql -U issyx issyx < backup.sql
```

### Full Backup (Standalone)

```bash
# Backup everything
sudo tar -czf /backup/issyx_full_$(date +%Y%m%d).tar.gz \
  /opt/issyx \
  /data/issyx \
  /etc/issyx \
  /var/lib/tftpboot/issyx

# Database backup
sudo -u postgres pg_dump issyx > /backup/issyx_db_$(date +%Y%m%d).sql
```

---

## Security Recommendations

1. **Use HTTPS** - Configure SSL certificates via Let's Encrypt
2. **Change default passwords** - Database, Redis, admin account
3. **Restrict network access** - Firewall rules for management interface
4. **Regular backups** - Automate database and file backups
5. **Keep updated** - Regular security patches and application updates
6. **Monitor logs** - Set up log monitoring and alerting
7. **Secure PXE network** - VLAN isolation for imaging network if possible

---

## Getting Help

- **Logs:** Check application and service logs first
- **Documentation:** See other .md files in repository
- **Issues:** Report bugs at https://github.com/issyx/issyx-imaging-platform/issues

---

## Quick Reference

**Standalone Installation:**
```bash
git clone https://github.com/issyx/issyx-imaging-platform.git
cd issyx-imaging-platform
sudo ./install-standalone.sh
```

**Docker Installation:**
```bash
git clone https://github.com/issyx/issyx-imaging-platform.git
cd issyx-imaging-platform
cp .env.example .env
docker compose up -d
```

**Service Management (Standalone):**
```bash
sudo systemctl status issyx-backend
sudo systemctl restart issyx-backend
sudo tail -f /var/log/issyx/backend.log
```

**Service Management (Docker):**
```bash
docker compose ps
docker compose logs -f
docker compose restart
```
