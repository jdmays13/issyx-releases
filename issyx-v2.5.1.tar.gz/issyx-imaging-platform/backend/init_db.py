"""
Database initialization script with seed data.
Run this once to create tables and populate with initial data.
"""
import os
from app.core.database import engine, SessionLocal, Base
from app.core.security import get_password_hash
from app.models import (
    User, Role, Customer, OperatingSystem, DriverLibrary,
    DriverProfile, SoftwareCatalog, ScriptsLibrary, MasterProfile, SystemSettings
)

def init_db():
    """Initialize database with tables and essential system data only."""
    print("Creating database tables...")
    Base.metadata.create_all(bind=engine)

    db = SessionLocal()

    try:
        # Check if database is already initialized
        if db.query(Role).count() > 0:
            print("Database already initialized!")
            return

        print("Initializing essential system data...")

        # 1. Create System Roles (required for the application to function)
        print("Creating system roles...")
        roles = [
            Role(
                id="R-001",
                name="Admin",
                permissions=["Manage users & roles", "Create/modify profiles", "Create/disable jobs", "View devices & logs", "Delete resources"],
                is_system=True
            ),
            Role(
                id="R-002",
                name="Engineer",
                permissions=["Create/modify profiles", "Create/retry jobs", "View devices & logs"],
                is_system=True
            ),
            Role(
                id="R-003",
                name="Viewer",
                permissions=["Read-only: customers, profiles, devices, jobs"],
                is_system=True
            )
        ]
        for role in roles:
            db.add(role)
        db.commit()

        # 2. Create Default System Settings (required for settings page)
        print("Creating default system settings...")

        # Get server IP from environment variable (set during installation)
        server_ip = os.environ.get("ISSYX_SERVER_IP", "")
        winpe_api_endpoint = ""
        if server_ip:
            winpe_api_endpoint = f"http://{server_ip}:8000/api/v1"
            print(f"  Server IP: {server_ip}")
            print(f"  WinPE API Endpoint: {winpe_api_endpoint}")

        # Default TFTP path for standalone installation (standard Debian/Ubuntu path)
        tftp_root = os.environ.get("ISSYX_TFTP_ROOT", "/var/lib/tftpboot")
        print(f"  TFTP Root: {tftp_root}")

        settings = SystemSettings(
            id=1,
            pxe_server_ip=server_ip,
            pxe_tftp_root=tftp_root,
            use_custom_pxe_ip=bool(server_ip),
            use_custom_tftp_path=True,
            multicast_enabled=False,
            winpe_display_enabled=True,
            winpe_api_endpoint=winpe_api_endpoint
        )
        db.add(settings)
        db.commit()

        print("\n✓ Database initialized successfully!")
        print("\nIMPORTANT: No users have been created.")
        print("Please run the setup wizard or create an admin user:")
        print("")
        print("  python create_admin.py")
        print("")
        print("Or via the web UI setup wizard at first launch.")

    except Exception as e:
        print(f"\n✗ Error initializing database: {e}")
        db.rollback()
        raise
    finally:
        db.close()


if __name__ == "__main__":
    init_db()
