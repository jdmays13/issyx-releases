"""
Add imaging_mode column to jobs table
"""
from app.core.database import engine
from sqlalchemy import text

def add_column():
    try:
        with engine.begin() as conn:
            # Check if column already exists (PostgreSQL)
            result = conn.execute(text("""
                SELECT COUNT(*)
                FROM information_schema.columns
                WHERE table_name='jobs'
                AND column_name='imaging_mode'
            """))
            exists = result.scalar() > 0

            if exists:
                print("Column 'imaging_mode' already exists. Skipping.")
                return

            # Add the column (PostgreSQL) with ENUM type
            # First create the enum type if it doesn't exist
            conn.execute(text("""
                DO $$ BEGIN
                    CREATE TYPE imagingmode AS ENUM ('unicast', 'multicast');
                EXCEPTION
                    WHEN duplicate_object THEN null;
                END $$;
            """))

            # Add the column with default value 'UNICAST'::imagingmode
            conn.execute(text(
                "ALTER TABLE jobs ADD COLUMN imaging_mode imagingmode DEFAULT 'UNICAST'::imagingmode"
            ))

            # Update existing jobs: set to multicast if total_devices >= 2
            conn.execute(text("""
                UPDATE jobs
                SET imaging_mode = 'MULTICAST'
                WHERE total_devices >= 2
            """))

            print("Column 'imaging_mode' added successfully!")
            print("Updated existing jobs with total_devices >= 2 to multicast mode")

    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    add_column()
