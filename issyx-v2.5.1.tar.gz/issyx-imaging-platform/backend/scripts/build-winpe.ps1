<#
.SYNOPSIS
    Build Custom WinPE Image for Issyx Imaging Platform

.DESCRIPTION
    Creates a custom Windows PE boot image with:
    - PowerShell support
    - Network drivers
    - DISM tools
    - Embedded Issyx imaging client script
    - Optimized for PXE boot

.REQUIREMENTS
    - Windows ADK (Assessment and Deployment Kit)
    - Administrator privileges
    - Internet connection for driver downloads

.EXAMPLE
    .\build-winpe.ps1 -OutputPath "C:\PXE\boot.wim" -Architecture amd64

.NOTES
    Version: 1.0.0
    Requires Windows ADK 10 or later
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory=$false)]
    [string]$OutputPath = ".\boot-files\tftp\boot.wim",

    [Parameter(Mandatory=$false)]
    [ValidateSet("amd64", "x86")]
    [string]$Architecture = "amd64",

    [Parameter(Mandatory=$false)]
    [string]$WorkingDir = "$env:TEMP\WinPE_Build",

    [Parameter(Mandatory=$false)]
    [string]$ClientScriptPath = "..\resources\winpe-client.ps1",

    [Parameter(Mandatory=$false)]
    [switch]$IncludeCommonDrivers
)

#Requires -RunAsAdministrator

$ErrorActionPreference = "Stop"

#region Helper Functions

function Write-BuildLog {
    param([string]$Message, [string]$Level = "INFO")

    $timestamp = Get-Date -Format "HH:mm:ss"

    switch ($Level) {
        "ERROR"   { Write-Host "[$timestamp] [ERROR] $Message" -ForegroundColor Red }
        "WARNING" { Write-Host "[$timestamp] [WARN]  $Message" -ForegroundColor Yellow }
        "SUCCESS" { Write-Host "[$timestamp] [OK]    $Message" -ForegroundColor Green }
        default   { Write-Host "[$timestamp] [INFO]  $Message" }
    }
}

function Test-WindowsADK {
    <#
    .SYNOPSIS
        Check if Windows ADK is installed.
    #>
    $adkPath = "C:\Program Files (x86)\Windows Kits\10\Assessment and Deployment Kit\Deployment Tools"

    if (-not (Test-Path $adkPath)) {
        throw "Windows ADK not found. Please install Windows ADK from: https://docs.microsoft.com/en-us/windows-hardware/get-started/adk-install"
    }

    Write-BuildLog "Windows ADK found: $adkPath" -Level "SUCCESS"
}

function Initialize-WorkingDirectory {
    param([string]$Path)

    if (Test-Path $Path) {
        Write-BuildLog "Cleaning existing working directory: $Path" -Level "WARNING"
        Remove-Item -Path $Path -Recurse -Force
    }

    New-Item -Path $Path -ItemType Directory -Force | Out-Null
    Write-BuildLog "Created working directory: $Path"
}

#endregion

#region WinPE Build Functions

function New-WinPEImage {
    param(
        [string]$WorkingDir,
        [string]$Architecture
    )

    Write-BuildLog "Creating base WinPE image ($Architecture)..."

    # Set ADK environment
    $adkPath = "C:\Program Files (x86)\Windows Kits\10\Assessment and Deployment Kit"
    $deploymentTools = "$adkPath\Deployment Tools\DandISetEnv.bat"

    # Run copype.cmd to create base WinPE
    $copepeCmd = "$adkPath\Windows Preinstallation Environment\copype.cmd"

    if (-not (Test-Path $copepeCmd)) {
        throw "copype.cmd not found. Ensure Windows PE add-on for ADK is installed."
    }

    # Execute copype
    $process = Start-Process -FilePath "cmd.exe" -ArgumentList "/c `"$copepeCmd`" $Architecture `"$WorkingDir`"" -Wait -PassThru -NoNewWindow

    if ($process.ExitCode -ne 0) {
        throw "Failed to create base WinPE image (exit code: $($process.ExitCode))"
    }

    Write-BuildLog "Base WinPE image created" -Level "SUCCESS"

    # Return path to WIM file
    return "$WorkingDir\media\sources\boot.wim"
}

function Mount-WinPEImage {
    param(
        [string]$WimPath,
        [string]$MountPath
    )

    Write-BuildLog "Mounting WinPE image..."

    # Create mount directory
    if (-not (Test-Path $MountPath)) {
        New-Item -Path $MountPath -ItemType Directory -Force | Out-Null
    }

    # Mount the WIM
    dism /Mount-Wim /WimFile:$WimPath /Index:1 /MountDir:$MountPath

    if ($LASTEXITCODE -ne 0) {
        throw "Failed to mount WinPE image"
    }

    Write-BuildLog "WinPE image mounted at: $MountPath" -Level "SUCCESS"
}

function Add-PowerShellToWinPE {
    param(
        [string]$MountPath,
        [string]$Architecture
    )

    Write-BuildLog "Adding PowerShell to WinPE..."

    $adkPath = "C:\Program Files (x86)\Windows Kits\10\Assessment and Deployment Kit"
    $winpeOCs = "$adkPath\Windows Preinstallation Environment\$Architecture\WinPE_OCs"

    # Required packages for PowerShell
    $packages = @(
        "WinPE-WMI.cab",
        "WinPE-NetFx.cab",
        "WinPE-Scripting.cab",
        "WinPE-PowerShell.cab",
        "WinPE-StorageWMI.cab",
        "WinPE-DismCmdlets.cab"
    )

    foreach ($package in $packages) {
        $packagePath = "$winpeOCs\$package"

        if (Test-Path $packagePath) {
            Write-BuildLog "Adding package: $package"
            dism /Image:$MountPath /Add-Package /PackagePath:$packagePath

            if ($LASTEXITCODE -ne 0) {
                Write-BuildLog "Warning: Failed to add package $package" -Level "WARNING"
            }
        }
        else {
            Write-BuildLog "Package not found: $package" -Level "WARNING"
        }
    }

    Write-BuildLog "PowerShell components added" -Level "SUCCESS"
}

function Add-NetworkDriversToWinPE {
    param(
        [string]$MountPath
    )

    Write-BuildLog "Adding network drivers to WinPE..."

    # Common network driver sources (if available)
    $driverPaths = @(
        "$env:SystemRoot\System32\DriverStore\FileRepository",
        "C:\Drivers\Network"  # Custom driver path if exists
    )

    $driversAdded = 0

    foreach ($driverPath in $driverPaths) {
        if (Test-Path $driverPath) {
            Write-BuildLog "Scanning for drivers in: $driverPath"

            # Add drivers recursively
            dism /Image:$MountPath /Add-Driver /Driver:$driverPath /Recurse /ForceUnsigned

            if ($LASTEXITCODE -eq 0) {
                $driversAdded++
            }
        }
    }

    if ($driversAdded -gt 0) {
        Write-BuildLog "Network drivers added from $driversAdded source(s)" -Level "SUCCESS"
    }
    else {
        Write-BuildLog "No additional network drivers added (WinPE has basic drivers)" -Level "WARNING"
    }
}

function Add-IssyxClientScript {
    param(
        [string]$MountPath,
        [string]$ClientScriptPath
    )

    Write-BuildLog "Embedding Issyx imaging client script..."

    if (-not (Test-Path $ClientScriptPath)) {
        throw "Client script not found: $ClientScriptPath"
    }

    # Copy client script to WinPE
    $targetPath = "$MountPath\Windows\System32\issyx-client.ps1"
    Copy-Item -Path $ClientScriptPath -Destination $targetPath -Force

    Write-BuildLog "Client script embedded: $targetPath" -Level "SUCCESS"

    # Create autostart script in startnet.cmd
    $startnetPath = "$MountPath\Windows\System32\startnet.cmd"
    $startnetContent = @"
@echo off
echo.
echo =========================================
echo Issyx Imaging Platform - WinPE Client
echo =========================================
echo.
echo Initializing network...
wpeinit

echo.
echo Starting imaging client...
powershell.exe -ExecutionPolicy Bypass -File X:\Windows\System32\issyx-client.ps1

echo.
echo Imaging client exited. Dropping to command prompt...
cmd.exe
"@

    Set-Content -Path $startnetPath -Value $startnetContent -Force
    Write-BuildLog "Auto-start configured in startnet.cmd" -Level "SUCCESS"
}

function Optimize-WinPEImage {
    param([string]$MountPath)

    Write-BuildLog "Optimizing WinPE image..."

    # Clean up component store
    dism /Image:$MountPath /Cleanup-Image /StartComponentCleanup /ResetBase

    Write-BuildLog "Image optimized" -Level "SUCCESS"
}

function Dismount-WinPEImage {
    param(
        [string]$MountPath,
        [bool]$Commit = $true
    )

    Write-BuildLog "Dismounting WinPE image..."

    if ($Commit) {
        dism /Unmount-Wim /MountDir:$MountPath /Commit
    }
    else {
        dism /Unmount-Wim /MountDir:$MountPath /Discard
    }

    if ($LASTEXITCODE -ne 0) {
        throw "Failed to dismount WinPE image"
    }

    Write-BuildLog "WinPE image dismounted" -Level "SUCCESS"
}

function Copy-WinPEToOutput {
    param(
        [string]$SourceWim,
        [string]$OutputPath
    )

    Write-BuildLog "Copying WinPE image to output location..."

    # Create output directory if needed
    $outputDir = Split-Path -Path $OutputPath -Parent
    if (-not (Test-Path $outputDir)) {
        New-Item -Path $outputDir -ItemType Directory -Force | Out-Null
    }

    # Copy the WIM file
    Copy-Item -Path $SourceWim -Destination $OutputPath -Force

    Write-BuildLog "WinPE image copied to: $OutputPath" -Level "SUCCESS"

    # Show file size
    $fileSize = (Get-Item $OutputPath).Length / 1MB
    Write-BuildLog "Image size: $([math]::Round($fileSize, 2)) MB"
}

#endregion

#region Main Build Process

function Start-WinPEBuild {
    Write-BuildLog "======================================"
    Write-BuildLog "Issyx WinPE Image Builder v1.0.0"
    Write-BuildLog "======================================"
    Write-BuildLog ""
    Write-BuildLog "Architecture: $Architecture"
    Write-BuildLog "Output Path: $OutputPath"
    Write-BuildLog "Working Directory: $WorkingDir"
    Write-BuildLog ""

    # Step 1: Verify prerequisites
    Write-BuildLog "Step 1: Verifying prerequisites..."
    Test-WindowsADK

    # Step 2: Initialize working directory
    Write-BuildLog "Step 2: Initializing working directory..."
    Initialize-WorkingDirectory -Path $WorkingDir

    # Step 3: Create base WinPE image
    Write-BuildLog "Step 3: Creating base WinPE image..."
    $wimPath = New-WinPEImage -WorkingDir $WorkingDir -Architecture $Architecture

    # Step 4: Mount the image
    Write-BuildLog "Step 4: Mounting WinPE image..."
    $mountPath = "$WorkingDir\mount"
    Mount-WinPEImage -WimPath $wimPath -MountPath $mountPath

    try {
        # Step 5: Add PowerShell
        Write-BuildLog "Step 5: Adding PowerShell components..."
        Add-PowerShellToWinPE -MountPath $mountPath -Architecture $Architecture

        # Step 6: Add network drivers
        Write-BuildLog "Step 6: Adding network drivers..."
        if ($IncludeCommonDrivers) {
            Add-NetworkDriversToWinPE -MountPath $mountPath
        }
        else {
            Write-BuildLog "Skipping additional network drivers (use -IncludeCommonDrivers to add)" -Level "WARNING"
        }

        # Step 7: Embed Issyx client script
        Write-BuildLog "Step 7: Embedding Issyx imaging client..."
        Add-IssyxClientScript -MountPath $mountPath -ClientScriptPath $ClientScriptPath

        # Step 8: Optimize image
        Write-BuildLog "Step 8: Optimizing image..."
        Optimize-WinPEImage -MountPath $mountPath

        # Step 9: Dismount and commit
        Write-BuildLog "Step 9: Committing changes..."
        Dismount-WinPEImage -MountPath $mountPath -Commit $true

        # Step 10: Copy to output location
        Write-BuildLog "Step 10: Copying to output location..."
        Copy-WinPEToOutput -SourceWim $wimPath -OutputPath $OutputPath

        Write-BuildLog ""
        Write-BuildLog "======================================"
        Write-BuildLog "Build completed successfully!" -Level "SUCCESS"
        Write-BuildLog "======================================"
        Write-BuildLog ""
        Write-BuildLog "Next steps:"
        Write-BuildLog "1. Deploy boot.wim to your TFTP server"
        Write-BuildLog "2. Configure PXE/iPXE to boot from this image"
        Write-BuildLog "3. Ensure the Issyx API is accessible from WinPE"
        Write-BuildLog ""
    }
    catch {
        Write-BuildLog "Build failed: $_" -Level "ERROR"

        # Attempt to dismount on error
        try {
            Dismount-WinPEImage -MountPath $mountPath -Commit $false
        }
        catch {
            Write-BuildLog "Failed to dismount image: $_" -Level "ERROR"
        }

        throw
    }
    finally {
        # Cleanup working directory (optional)
        # Remove-Item -Path $WorkingDir -Recurse -Force -ErrorAction SilentlyContinue
    }
}

#endregion

# Execute the build
try {
    Start-WinPEBuild
}
catch {
    Write-BuildLog "FATAL ERROR: $_" -Level "ERROR"
    exit 1
}
