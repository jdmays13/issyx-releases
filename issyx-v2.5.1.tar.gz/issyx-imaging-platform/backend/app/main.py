from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
from .core.config import settings
from .core.database import engine, Base, SessionLocal
from .routes import auth, customers, operating_systems, drivers, software, scripts, master_profiles, jobs, users, system_settings, upload, audit, websocket, devices, hardware, windows_update, notifications, bulk_operations, system_health, boot, device_imaging, setup
from .services.scheduler import start_scheduler, shutdown_scheduler, load_scheduled_jobs
from .services.imaging_worker import start_imaging_worker, stop_imaging_worker

# Create database tables
Base.metadata.create_all(bind=engine)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Lifespan context manager for startup and shutdown events.
    """
    # Startup
    start_scheduler()
    db = SessionLocal()
    try:
        await load_scheduled_jobs(db)
        await start_imaging_worker(db)
    finally:
        db.close()

    yield

    # Shutdown
    shutdown_scheduler()
    await stop_imaging_worker()

# Initialize FastAPI app
app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    openapi_url=f"{settings.API_V1_PREFIX}/openapi.json",
    lifespan=lifespan
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.BACKEND_CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Health check endpoint
@app.get("/")
async def root():
    return {
        "message": "Issyx Imaging Platform API",
        "version": settings.VERSION,
        "status": "running"
    }

@app.get("/health")
async def health():
    return {"status": "healthy"}

# Include routers
app.include_router(auth.router, prefix=settings.API_V1_PREFIX, tags=["Authentication"])
app.include_router(customers.router, prefix=settings.API_V1_PREFIX, tags=["Customers"])
app.include_router(operating_systems.router, prefix=settings.API_V1_PREFIX, tags=["Operating Systems"])
app.include_router(drivers.router, prefix=settings.API_V1_PREFIX, tags=["Drivers"])
app.include_router(software.router, prefix=settings.API_V1_PREFIX, tags=["Software"])
app.include_router(scripts.router, prefix=settings.API_V1_PREFIX, tags=["Scripts"])
app.include_router(master_profiles.router, prefix=settings.API_V1_PREFIX, tags=["Master Profiles"])
app.include_router(jobs.router, prefix=settings.API_V1_PREFIX, tags=["Jobs"])
app.include_router(users.router, prefix=settings.API_V1_PREFIX, tags=["Users & Roles"])
app.include_router(system_settings.router, prefix=settings.API_V1_PREFIX, tags=["System Settings"])
app.include_router(upload.router, prefix=settings.API_V1_PREFIX, tags=["File Upload"])
app.include_router(audit.router, prefix=settings.API_V1_PREFIX, tags=["Audit Logs"])
app.include_router(websocket.router, prefix=settings.API_V1_PREFIX, tags=["WebSocket"])
app.include_router(devices.router, prefix=settings.API_V1_PREFIX, tags=["Devices"])
app.include_router(hardware.router, prefix=settings.API_V1_PREFIX, tags=["Hardware & Smart Detection"])
app.include_router(windows_update.router, prefix=settings.API_V1_PREFIX, tags=["Windows Update"])
app.include_router(notifications.router, prefix=settings.API_V1_PREFIX, tags=["Notifications"])
app.include_router(bulk_operations.router, prefix=settings.API_V1_PREFIX, tags=["Bulk Operations"])
app.include_router(system_health.router, prefix=settings.API_V1_PREFIX, tags=["System Health"])
app.include_router(boot.router, prefix=settings.API_V1_PREFIX, tags=["Boot Files"])
app.include_router(device_imaging.router, prefix=settings.API_V1_PREFIX, tags=["Device Imaging"])
app.include_router(setup.router, prefix=settings.API_V1_PREFIX, tags=["Setup"])
