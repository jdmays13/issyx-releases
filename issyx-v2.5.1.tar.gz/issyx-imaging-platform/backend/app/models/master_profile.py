from sqlalchemy import Column, String, ForeignKey, DateTime, Enum, Integer, Table, JSON
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import enum
from ..core.database import Base


class DriverMode(str, enum.Enum):
    SMART = "smart"  # Use hardware compatibility matching
    ALL = "all"  # Install all drivers from library


class WindowsUpdates(str, enum.Enum):
    OFFLINE = "offline"
    POST_IMAGING = "post-imaging"
    WSUS = "wsus"


class ExecutionPhase(str, enum.Enum):
    PRE = "pre"
    POST = "post"


# Junction table for master profiles and software
master_profile_software = Table(
    'master_profile_software',
    Base.metadata,
    Column('profile_id', String(50), ForeignKey('master_profiles.id'), primary_key=True),
    Column('software_id', String(50), ForeignKey('software_catalog.id'), primary_key=True),
    Column('install_order', Integer)
)


# Junction table for master profiles and scripts
master_profile_scripts = Table(
    'master_profile_scripts',
    Base.metadata,
    Column('profile_id', String(50), ForeignKey('master_profiles.id'), primary_key=True),
    Column('script_id', String(50), ForeignKey('scripts_library.id'), primary_key=True),
    Column('execution_phase', Enum(ExecutionPhase), primary_key=True),
    Column('execution_order', Integer)
)


class MasterProfile(Base):
    __tablename__ = "master_profiles"

    id = Column(String(50), primary_key=True)  # e.g., 'MP-001'
    name = Column(String(255), nullable=False)
    customer_id = Column(String(50), ForeignKey("customers.id"), index=True)
    os_id = Column(String(50), ForeignKey("operating_systems.id"))
    driver_mode = Column(Enum(DriverMode), default=DriverMode.SMART)  # smart = hardware compatibility, all = all drivers
    windows_updates = Column(Enum(WindowsUpdates), default=WindowsUpdates.OFFLINE)
    system_config = Column(JSON, nullable=True)  # Computer naming, local admin, DNS, etc.
    task_sequence = Column(JSON, nullable=True)  # Task execution sequence
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    customer = relationship("Customer", back_populates="master_profiles")
    operating_system = relationship("OperatingSystem", back_populates="master_profiles")
    software = relationship(
        "SoftwareCatalog",
        secondary=master_profile_software,
        back_populates="master_profiles"
    )
    scripts = relationship(
        "ScriptsLibrary",
        secondary=master_profile_scripts,
        back_populates="master_profiles"
    )
    jobs = relationship("Job", back_populates="profile")


# Aliases for junction tables
MasterProfileSoftware = master_profile_software
MasterProfileScript = master_profile_scripts
