from sqlalchemy import Column, String, BigInteger, DateTime, ForeignKey, Table
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from ..core.database import Base


# Junction table for driver profiles and drivers
driver_profile_drivers = Table(
    'driver_profile_drivers',
    Base.metadata,
    Column('profile_id', String(50), ForeignKey('driver_profiles.id'), primary_key=True),
    Column('driver_id', String(50), ForeignKey('driver_library.id'), primary_key=True)
)


class DriverLibrary(Base):
    __tablename__ = "driver_library"

    id = Column(String(50), primary_key=True)  # e.g., 'DRV-001'
    name = Column(String(255), nullable=False)
    version = Column(String(100), nullable=False)
    manufacturer = Column(String(255))
    category = Column(String(100), index=True)
    hw_id = Column(String(255))
    file_path = Column(String(500))
    file_size = Column(BigInteger)
    hash_sha256 = Column(String(64), unique=True, nullable=False, index=True)
    upload_date = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    driver_profiles = relationship(
        "DriverProfile",
        secondary=driver_profile_drivers,
        back_populates="drivers"
    )


class DriverProfile(Base):
    __tablename__ = "driver_profiles"

    id = Column(String(50), primary_key=True)  # e.g., 'DP-001'
    name = Column(String(255), nullable=False)
    hardware = Column(String(255), nullable=False)
    description = Column(String(1000))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    drivers = relationship(
        "DriverLibrary",
        secondary=driver_profile_drivers,
        back_populates="driver_profiles"
    )


# Aliases to make it easier to import
DriverProfileDriver = driver_profile_drivers
Driver = DriverLibrary  # Alias for backward compatibility
