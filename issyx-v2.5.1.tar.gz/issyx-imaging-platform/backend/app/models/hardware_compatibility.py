"""
Hardware Compatibility Model

Maps hardware IDs (PCI IDs, USB IDs, etc.) to compatible drivers.
Used for smart driver detection during PXE boot.
"""
from sqlalchemy import Column, String, ForeignKey, DateTime, Text, Boolean
from sqlalchemy.sql import func
from ..core.database import Base


class HardwareCompatibility(Base):
    """
    Hardware to driver compatibility mapping.

    Stores relationships between hardware identifiers and driver packages.
    """
    __tablename__ = "hardware_compatibility"

    id = Column(String(50), primary_key=True)

    # Hardware identification
    vendor_id = Column(String(20), index=True)  # e.g., "8086" for Intel
    device_id = Column(String(20), index=True)  # e.g., "15B7" for specific device
    subsystem_vendor_id = Column(String(20), nullable=True)
    subsystem_device_id = Column(String(20), nullable=True)

    # Hardware details
    hardware_type = Column(String(50))  # "pci", "usb", "acpi", etc.
    device_class = Column(String(100))  # "Network", "Storage", "Graphics", etc.
    device_name = Column(String(255))  # Human-readable name
    manufacturer = Column(String(255))  # Manufacturer name

    # Driver mapping
    driver_id = Column(String(50), ForeignKey("driver_library.id"), nullable=True)

    # Metadata
    os_version = Column(String(50))  # Windows version compatibility
    architecture = Column(String(20))  # "x64", "x86", "ARM64"
    confidence_score = Column(String(10), default="high")  # "high", "medium", "low"
    verified = Column(Boolean, default=False)  # Manually verified compatibility

    # Detection patterns (for fuzzy matching)
    pnp_id_pattern = Column(Text, nullable=True)  # Regex pattern for PnP IDs
    wmi_query = Column(Text, nullable=True)  # WMI query for detection

    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Notes and metadata
    notes = Column(Text, nullable=True)
    source = Column(String(100), nullable=True)  # "manual", "pci_database", "usb_ids", etc.


class DetectedHardware(Base):
    """
    Hardware detected during PXE boot from devices.

    Stores hardware information sent by devices during imaging.
    """
    __tablename__ = "detected_hardware"

    id = Column(String(50), primary_key=True)
    device_mac = Column(String(17), ForeignKey("discovered_devices.mac_address"), index=True)
    job_id = Column(String(50), ForeignKey("jobs.id"), nullable=True, index=True)

    # Hardware identification
    vendor_id = Column(String(20))
    device_id = Column(String(20))
    subsystem_vendor_id = Column(String(20), nullable=True)
    subsystem_device_id = Column(String(20), nullable=True)

    # Hardware details
    hardware_type = Column(String(50))
    device_class = Column(String(100))
    device_name = Column(String(255))
    pnp_id = Column(String(255), nullable=True)  # Full PnP ID string

    # Matched driver (result of smart matching)
    matched_driver_id = Column(String(50), ForeignKey("driver_library.id"), nullable=True)
    match_confidence = Column(String(10))  # "high", "medium", "low", "none"
    match_method = Column(String(50))  # "exact", "fuzzy", "class_based", "manual"

    # Timestamps
    detected_at = Column(DateTime(timezone=True), server_default=func.now())

    # Raw data
    raw_data = Column(Text, nullable=True)  # JSON of full hardware info


def generate_hardware_id(vendor_id: str, device_id: str, subsys_vendor: str = None, subsys_device: str = None) -> str:
    """
    Generate a unique hardware ID from components.

    Format: VEN_{vendor}_DEV_{device}[_SUBSYS_{subsys_vendor}_{subsys_device}]
    """
    hw_id = f"VEN_{vendor_id.upper()}_DEV_{device_id.upper()}"
    if subsys_vendor and subsys_device:
        hw_id += f"_SUBSYS_{subsys_vendor.upper()}_{subsys_device.upper()}"
    return hw_id
