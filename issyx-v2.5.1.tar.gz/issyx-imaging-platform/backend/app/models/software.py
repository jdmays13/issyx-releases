from sqlalchemy import Column, String, BigInteger, DateTime, Text
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from ..core.database import Base


class SoftwareCatalog(Base):
    __tablename__ = "software_catalog"

    id = Column(String(50), primary_key=True)  # e.g., 'SW-001'
    name = Column(String(255), nullable=False)
    version = Column(String(100), nullable=False)
    file_path = Column(String(500))
    file_size = Column(BigInteger)
    hash_sha256 = Column(String(64), unique=True, nullable=True, index=True)  # SHA256 hash for duplicate detection
    description = Column(Text)
    install_params = Column(String(500))  # Silent install parameters like "/S", "/quiet", etc.
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    master_profiles = relationship(
        "MasterProfile",
        secondary="master_profile_software",
        back_populates="software"
    )


# Alias for backward compatibility
Software = SoftwareCatalog
