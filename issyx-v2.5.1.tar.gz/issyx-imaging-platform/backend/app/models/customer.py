from sqlalchemy import Column, String, Enum, DateTime
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import enum
from ..core.database import Base


class CustomerStatus(str, enum.Enum):
    ACTIVE = "Active"
    INACTIVE = "Inactive"


class Customer(Base):
    __tablename__ = "customers"

    id = Column(String(50), primary_key=True)  # e.g., 'C-001'
    name = Column(String(255), nullable=False)
    contact = Column(String(255))
    status = Column(Enum(CustomerStatus), default=CustomerStatus.ACTIVE)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    master_profiles = relationship("MasterProfile", back_populates="customer")
    jobs = relationship("Job", back_populates="customer")
