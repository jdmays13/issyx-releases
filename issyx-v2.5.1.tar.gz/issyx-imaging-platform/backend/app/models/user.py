from sqlalchemy import Column, String, Enum, ForeignKey, Boolean, DateTime, JSON
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import uuid
import enum
from ..core.database import Base


class UserStatus(str, enum.Enum):
    ACTIVE = "Active"
    PENDING = "Pending"
    DISABLED = "Disabled"


class ThemeMode(str, enum.Enum):
    LIGHT = "light"
    DARK = "dark"


class Role(Base):
    __tablename__ = "roles"

    id = Column(String(50), primary_key=True, default=lambda: f"R-{str(uuid.uuid4())[:8]}")
    name = Column(String(100), unique=True, nullable=False)
    permissions = Column(JSON, nullable=False)
    is_system = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    users = relationship("User", back_populates="role")


class User(Base):
    __tablename__ = "users"

    id = Column(String(50), primary_key=True, default=lambda: f"U-{str(uuid.uuid4())[:8]}")
    name = Column(String(255), nullable=False)
    title = Column(String(255))
    email = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    role_id = Column(String(50), ForeignKey("roles.id"), index=True)
    status = Column(Enum(UserStatus), default=UserStatus.PENDING)
    theme_mode = Column(Enum(ThemeMode), default=ThemeMode.LIGHT)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    role = relationship("Role", back_populates="users")
    created_jobs = relationship("Job", back_populates="creator")
