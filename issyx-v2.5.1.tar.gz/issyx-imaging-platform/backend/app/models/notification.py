"""
Notification Configuration and History Models

Manages notification preferences and tracks notification history.
Supports Email, Webhook (Slack, Teams, custom), and in-app notifications.
"""
from sqlalchemy import Column, String, Boolean, ForeignKey, DateTime, Text, JSON, Enum as SQLEnum
from sqlalchemy.sql import func
from enum import Enum
from ..core.database import Base


class NotificationType(str, Enum):
    """Type of notification"""
    EMAIL = "email"
    WEBHOOK = "webhook"
    SLACK = "slack"
    TEAMS = "teams"
    IN_APP = "in_app"


class NotificationEvent(str, Enum):
    """Events that trigger notifications"""
    JOB_STARTED = "job_started"
    JOB_COMPLETED = "job_completed"
    JOB_FAILED = "job_failed"
    DEVICE_DISCOVERED = "device_discovered"
    DEVICE_ASSIGNED = "device_assigned"
    DEVICE_IMAGING_COMPLETED = "device_imaging_completed"
    DEVICE_IMAGING_FAILED = "device_imaging_failed"
    WINDOWS_UPDATE_COMPLETED = "windows_update_completed"
    WINDOWS_UPDATE_FAILED = "windows_update_failed"
    SYSTEM_ERROR = "system_error"


class NotificationConfig(Base):
    """
    Notification configuration per user.
    Defines when and how users receive notifications.
    """
    __tablename__ = "notification_configs"

    id = Column(String(50), primary_key=True)
    user_id = Column(String(50), ForeignKey("users.id"), index=True)
    name = Column(String(255))

    # Notification channel settings
    email_enabled = Column(Boolean, default=True)
    email_address = Column(String(255), nullable=True)

    webhook_enabled = Column(Boolean, default=False)
    webhook_url = Column(String(1000), nullable=True)
    webhook_type = Column(String(50), default="custom")  # custom, slack, teams

    in_app_enabled = Column(Boolean, default=True)

    # Event subscriptions (JSON dict of event: bool)
    event_subscriptions = Column(JSON, default={
        "job_started": False,
        "job_completed": True,
        "job_failed": True,
        "device_discovered": False,
        "device_assigned": False,
        "device_imaging_completed": False,
        "device_imaging_failed": True,
        "windows_update_completed": False,
        "windows_update_failed": True,
        "system_error": True
    })

    # Filtering
    notify_only_own_jobs = Column(Boolean, default=False)
    notify_business_hours_only = Column(Boolean, default=False)
    business_hours_start = Column(String(5), default="09:00")  # HH:MM
    business_hours_end = Column(String(5), default="17:00")    # HH:MM

    # Rate limiting
    max_notifications_per_hour = Column(String(10), default=10)
    digest_mode = Column(Boolean, default=False)  # Group notifications
    digest_interval_minutes = Column(String(10), default=30)

    # Metadata
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class NotificationHistory(Base):
    """
    History of sent notifications.
    Tracks all notifications for audit and debugging.
    """
    __tablename__ = "notification_history"

    id = Column(String(50), primary_key=True)
    user_id = Column(String(50), ForeignKey("users.id"), index=True)
    config_id = Column(String(50), ForeignKey("notification_configs.id"), nullable=True)

    # Notification details
    notification_type = Column(SQLEnum(NotificationType))
    event_type = Column(SQLEnum(NotificationEvent))
    subject = Column(String(500))
    message = Column(Text)

    # Context
    job_id = Column(String(50), nullable=True, index=True)
    device_mac = Column(String(17), nullable=True)

    # Delivery status
    status = Column(String(50))  # "sent", "failed", "queued", "skipped"
    sent_at = Column(DateTime(timezone=True), server_default=func.now())
    delivered_at = Column(DateTime(timezone=True), nullable=True)
    error_message = Column(Text, nullable=True)

    # Tracking
    read_at = Column(DateTime(timezone=True), nullable=True)  # For in-app notifications
    clicked_at = Column(DateTime(timezone=True), nullable=True)

    # Context metadata (renamed from 'metadata' to avoid SQLAlchemy reserved name)
    context_metadata = Column(JSON, nullable=True)  # Additional context data
