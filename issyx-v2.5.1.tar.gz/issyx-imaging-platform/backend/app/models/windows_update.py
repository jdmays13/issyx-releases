"""
Windows Update Configuration Model

Manages Windows Update settings for imaging jobs.
Supports Offline, Online, and WSUS update modes.
"""
from sqlalchemy import Column, String, Boolean, Integer, Text, DateTime, Enum as SQLEnum
from sqlalchemy.sql import func
from enum import Enum
from ..core.database import Base


class WindowsUpdateMode(str, Enum):
    """Windows Update deployment mode"""
    OFFLINE = "Offline"  # Use pre-downloaded update packages
    ONLINE = "Online"    # Direct Windows Update
    WSUS = "WSUS"        # Windows Server Update Services


class WindowsUpdateConfig(Base):
    """
    Windows Update configuration settings.
    Can be global or per-profile.
    """
    __tablename__ = "windows_update_config"

    id = Column(String(50), primary_key=True)
    name = Column(String(255), nullable=False)
    mode = Column(SQLEnum(WindowsUpdateMode), default=WindowsUpdateMode.ONLINE)

    # WSUS Settings
    wsus_server_url = Column(String(500), nullable=True)
    wsus_server_port = Column(Integer, default=8530, nullable=True)
    wsus_use_ssl = Column(Boolean, default=True, nullable=True)
    wsus_target_group = Column(String(255), nullable=True)

    # Online Settings
    online_defer_upgrades = Column(Boolean, default=False)
    online_include_recommended = Column(Boolean, default=True)
    online_auto_reboot = Column(Boolean, default=True)
    online_reboot_delay_minutes = Column(Integer, default=15)

    # Offline Settings
    offline_package_path = Column(String(1000), nullable=True)  # Path to .cab or .msu files
    offline_apply_order = Column(Text, nullable=True)  # JSON list of update order

    # General Settings
    max_download_time_minutes = Column(Integer, default=120)
    max_install_time_minutes = Column(Integer, default=180)
    skip_on_timeout = Column(Boolean, default=False)
    retry_on_failure = Column(Boolean, default=True)
    max_retries = Column(Integer, default=3)

    # Filtering
    include_security_updates = Column(Boolean, default=True)
    include_critical_updates = Column(Boolean, default=True)
    include_driver_updates = Column(Boolean, default=False)
    include_feature_updates = Column(Boolean, default=False)
    exclude_preview_updates = Column(Boolean, default=True)

    # Metadata
    is_default = Column(Boolean, default=False)
    created_by = Column(String(50), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    notes = Column(Text, nullable=True)


class WindowsUpdateLog(Base):
    """
    Log of Windows Update operations during imaging.
    """
    __tablename__ = "windows_update_logs"

    id = Column(String(50), primary_key=True)
    job_id = Column(String(50), nullable=False, index=True)
    device_mac = Column(String(17), nullable=False, index=True)

    # Update details
    update_mode = Column(SQLEnum(WindowsUpdateMode))
    config_id = Column(String(50), nullable=True)

    # Status
    status = Column(String(50))  # "started", "downloading", "installing", "completed", "failed"
    updates_found = Column(Integer, default=0)
    updates_downloaded = Column(Integer, default=0)
    updates_installed = Column(Integer, default=0)
    updates_failed = Column(Integer, default=0)

    # Timing
    started_at = Column(DateTime(timezone=True), server_default=func.now())
    completed_at = Column(DateTime(timezone=True), nullable=True)
    duration_seconds = Column(Integer, nullable=True)

    # Details
    update_list = Column(Text, nullable=True)  # JSON list of updates
    error_message = Column(Text, nullable=True)
    retry_count = Column(Integer, default=0)

    # Metadata
    reboot_required = Column(Boolean, default=False)
    reboot_completed = Column(Boolean, default=False)
