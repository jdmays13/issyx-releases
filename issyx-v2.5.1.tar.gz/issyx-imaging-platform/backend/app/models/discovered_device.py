"""
Discovered Device Model

Tracks all devices that have been detected via PXE boot, regardless of imaging status.
Provides a history/inventory of all devices that have booted from the network.
"""
from sqlalchemy import Column, String, DateTime, Boolean
from sqlalchemy.sql import func
from ..core.database import Base


class DiscoveredDevice(Base):
    """
    Devices discovered via PXE/TFTP boot requests.
    Persists device information for inventory and history.
    """
    __tablename__ = "discovered_devices"

    mac_address = Column(String(17), primary_key=True)  # Primary key: MAC address
    hostname = Column(String(255))
    ip_address = Column(String(45))
    manufacturer = Column(String(255))  # Derived from MAC OUI lookup
    model = Column(String(255))  # If detectable from SMBIOS/DMI
    first_seen = Column(DateTime(timezone=True), server_default=func.now())
    last_seen = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    times_seen = Column(String(50), default=1)  # How many PXE boots detected
    is_active = Column(Boolean, default=True)  # Currently participating in a job
