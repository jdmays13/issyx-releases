from sqlalchemy import Column, String, BigInteger, DateTime
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from ..core.database import Base


class OperatingSystem(Base):
    __tablename__ = "operating_systems"

    id = Column(String(50), primary_key=True)  # e.g., 'OS-001'
    name = Column(String(255), nullable=False)
    version = Column(String(100), nullable=False)
    edition = Column(String(100), nullable=False)
    build = Column(String(100))
    file_path = Column(String(500))
    file_size = Column(BigInteger)
    hash_sha256 = Column(String(64), unique=True, nullable=True, index=True)  # SHA256 hash for duplicate detection
    architecture = Column(String(20), default="x64")  # x64, x86, ARM64
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    master_profiles = relationship("MasterProfile", back_populates="operating_system")
