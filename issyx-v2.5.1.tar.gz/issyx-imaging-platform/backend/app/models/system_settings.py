from sqlalchemy import Column, Integer, String, Boolean, DateTime
from sqlalchemy.sql import func
from ..core.database import Base


class SystemSettings(Base):
    __tablename__ = "system_settings"

    id = Column(Integer, primary_key=True, default=1)  # Singleton - only one row
    pxe_server_ip = Column(String(45))
    pxe_tftp_root = Column(String(500))
    use_custom_pxe_ip = Column(Boolean, default=False)
    use_custom_tftp_path = Column(Boolean, default=False)
    multicast_enabled = Column(Boolean, default=False)
    multicast_address = Column(String(45))
    winpe_display_enabled = Column(Boolean, default=False)
    winpe_api_endpoint = Column(String(255))

    # Upload paths
    upload_base_path = Column(String(500), default="/app/uploads")
    os_images_path = Column(String(500), default="/app/uploads/os_images")
    drivers_path = Column(String(500), default="/app/uploads/drivers")
    software_path = Column(String(500), default="/app/uploads/software")
    scripts_path = Column(String(500), default="/app/uploads/scripts")

    # Network interface selection
    selected_nic = Column(String(255))

    # Multicast range
    multicast_start_range = Column(String(45))
    multicast_end_range = Column(String(45))

    # Windows Update settings
    update_mode = Column(String(100))
    wsus_server = Column(String(255))

    # Branding
    logo_filename = Column(String(255))

    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
