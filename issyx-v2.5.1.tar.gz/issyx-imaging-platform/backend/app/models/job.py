from sqlalchemy import Column, String, Integer, ForeignKey, DateTime, Enum, Text, Boolean
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import enum
import uuid
from ..core.database import Base


class JobStatus(str, enum.Enum):
    SCHEDULED = "Scheduled"
    QUEUED = "Queued"
    RUNNING = "Running"
    SUCCEEDED = "Succeeded"
    FAILED = "Failed"
    CANCELLED = "Cancelled"


class ImagingMode(str, enum.Enum):
    UNICAST = "unicast"
    MULTICAST = "multicast"


class DeviceStatus(str, enum.Enum):
    QUEUED = "Queued"
    RUNNING = "Running"
    SUCCEEDED = "Succeeded"
    FAILED = "Failed"
    CANCELLED = "Cancelled"


class Job(Base):
    __tablename__ = "jobs"

    id = Column(String(50), primary_key=True)  # e.g., 'JOB-1042'
    customer_id = Column(String(50), ForeignKey("customers.id"), index=True)
    profile_id = Column(String(50), ForeignKey("master_profiles.id"))
    status = Column(Enum(JobStatus), default=JobStatus.QUEUED, index=True)
    imaging_mode = Column(Enum(ImagingMode), default=ImagingMode.UNICAST)
    total_devices = Column(Integer, default=0)
    succeeded = Column(Integer, default=0)
    failed = Column(Integer, default=0)
    in_progress = Column(Integer, default=0)
    started_at = Column(DateTime(timezone=True))
    completed_at = Column(DateTime(timezone=True))
    created_by = Column(String(50), ForeignKey("users.id"))
    created_at = Column(DateTime(timezone=True), server_default=func.now(), index=True)

    # Scheduling fields
    scheduled_for = Column(DateTime(timezone=True), index=True)  # When to execute
    is_recurring = Column(Boolean, default=False)  # Recurring job flag
    recurrence_pattern = Column(String(100))  # Cron pattern (e.g., "0 2 * * *")
    last_run_at = Column(DateTime(timezone=True))  # Last execution time
    next_run_at = Column(DateTime(timezone=True), index=True)  # Next scheduled run

    # Relationships
    customer = relationship("Customer", back_populates="jobs")
    profile = relationship("MasterProfile", back_populates="jobs")
    creator = relationship("User", back_populates="created_jobs")
    devices = relationship("JobDevice", back_populates="job", cascade="all, delete-orphan")


class JobDevice(Base):
    __tablename__ = "job_devices"

    id = Column(String(50), primary_key=True, default=lambda: str(uuid.uuid4()))
    job_id = Column(String(50), ForeignKey("jobs.id"), index=True)
    hostname = Column(String(255))
    ip_address = Column(String(45))
    mac_address = Column(String(17), nullable=False, unique=True, index=True)
    status = Column(Enum(DeviceStatus), default=DeviceStatus.QUEUED, index=True)
    progress = Column(Integer, default=0)
    current_step = Column(String(255))
    retries = Column(Integer, default=0)
    started_at = Column(DateTime(timezone=True))
    completed_at = Column(DateTime(timezone=True))
    duration = Column(String(50))
    error_message = Column(Text)
    logs = Column(Text)

    # Relationships
    job = relationship("Job", back_populates="devices")
