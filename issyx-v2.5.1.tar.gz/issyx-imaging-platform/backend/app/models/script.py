from sqlalchemy import Column, String, DateTime, Text, Enum, BigInteger
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import enum
from ..core.database import Base


class ScriptType(str, enum.Enum):
    POWERSHELL = "PowerShell"
    BATCH = "Batch"


class ScriptCategory(str, enum.Enum):
    PRE_IMAGING = "Pre-Imaging"
    POST_IMAGING = "Post-Imaging"


class ScriptsLibrary(Base):
    __tablename__ = "scripts_library"

    id = Column(String(50), primary_key=True)  # e.g., 'SCR-001'
    name = Column(String(255), nullable=False)
    type = Column(Enum(ScriptType), nullable=False)
    category = Column(Enum(ScriptCategory), nullable=False)
    description = Column(Text)
    file_path = Column(String(500))
    file_size = Column(BigInteger)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    master_profiles = relationship(
        "MasterProfile",
        secondary="master_profile_scripts",
        back_populates="scripts"
    )


# Alias for backward compatibility
Script = ScriptsLibrary
