from sqlalchemy import Column, String, Text, DateTime, JSON
from sqlalchemy.sql import func
from ..core.database import Base


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(String(50), primary_key=True)
    user_id = Column(String(50), nullable=False, index=True)
    user_email = Column(String(255), nullable=False)
    action = Column(String(50), nullable=False, index=True)  # CREATE, UPDATE, DELETE, LOGIN, etc.
    resource_type = Column(String(50), nullable=False, index=True)  # Customer, Job, User, etc.
    resource_id = Column(String(50), index=True)
    description = Column(Text)
    changes = Column(JSON)  # Store before/after values
    ip_address = Column(String(45))  # IPv6 support
    user_agent = Column(Text)
    timestamp = Column(DateTime(timezone=True), server_default=func.now(), index=True)

    def __repr__(self):
        return f"<AuditLog {self.user_email} {self.action} {self.resource_type}>"
