"""
System Health Monitoring API Routes

Endpoints for monitoring system health, worker status, and performance metrics.
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import Dict, List
from datetime import datetime, timedelta
from ..core.database import get_db
from ..core.security import get_current_user
from ..models.job import Job, JobDevice, JobStatus, DeviceStatus
from ..models.discovered_device import DiscoveredDevice
from ..models.notification import NotificationHistory
from ..models.windows_update import WindowsUpdateLog
from ..models.hardware_compatibility import DetectedHardware
import logging
import psutil
import platform

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/health", tags=["system-health"])


@router.get("/status")
async def get_system_health_status(
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Get overall system health status.

    Returns:
        - System uptime
        - CPU usage
        - Memory usage
        - Disk usage
        - Database connection status
        - Active jobs count
        - Worker status (future: actual worker health checks)
    """
    try:
        # System metrics
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')

        # Database metrics
        active_jobs = db.query(Job).filter(Job.status == JobStatus.RUNNING).count()
        queued_jobs = db.query(Job).filter(Job.status == JobStatus.QUEUED).count()

        total_devices = db.query(JobDevice).count()
        running_devices = db.query(JobDevice).filter(
            JobDevice.status == DeviceStatus.RUNNING
        ).count()

        # Recent activity
        last_24h = datetime.now() - timedelta(hours=24)
        jobs_last_24h = db.query(Job).filter(
            Job.created_at >= last_24h
        ).count()

        devices_discovered_24h = db.query(DiscoveredDevice).filter(
            DiscoveredDevice.first_seen >= last_24h
        ).count()

        return {
            "status": "healthy",
            "timestamp": datetime.now().isoformat(),
            "system": {
                "platform": platform.system(),
                "platform_version": platform.version(),
                "python_version": platform.python_version(),
                "uptime_seconds": int(datetime.now().timestamp() - psutil.boot_time())
            },
            "resources": {
                "cpu_percent": cpu_percent,
                "memory_percent": memory.percent,
                "memory_available_gb": round(memory.available / (1024**3), 2),
                "memory_total_gb": round(memory.total / (1024**3), 2),
                "disk_percent": disk.percent,
                "disk_free_gb": round(disk.free / (1024**3), 2),
                "disk_total_gb": round(disk.total / (1024**3), 2)
            },
            "jobs": {
                "active": active_jobs,
                "queued": queued_jobs,
                "total_devices": total_devices,
                "running_devices": running_devices,
                "jobs_last_24h": jobs_last_24h
            },
            "devices": {
                "discovered_last_24h": devices_discovered_24h
            },
            "workers": {
                "imaging_worker": "running",  # Future: actual worker health check
                "scheduler": "running"  # Future: actual scheduler health check
            }
        }

    except Exception as e:
        logger.error(f"Failed to get system health: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get system health: {str(e)}")


@router.get("/metrics/performance")
async def get_performance_metrics(
    hours: int = 24,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Get performance metrics for the specified time period.

    Metrics include:
    - Average job duration
    - Success/failure rates
    - Device imaging performance
    - Resource utilization trends
    """
    try:
        cutoff_time = datetime.now() - timedelta(hours=hours)

        # Job metrics
        completed_jobs = db.query(Job).filter(
            Job.completed_at >= cutoff_time,
            Job.status.in_([JobStatus.SUCCEEDED, JobStatus.FAILED])
        ).all()

        total_jobs = len(completed_jobs)
        succeeded_jobs = sum(1 for j in completed_jobs if j.status == JobStatus.SUCCEEDED)
        failed_jobs = sum(1 for j in completed_jobs if j.status == JobStatus.FAILED)

        # Calculate average duration
        avg_duration_seconds = 0
        if completed_jobs:
            durations = [
                (j.completed_at - j.created_at).total_seconds()
                for j in completed_jobs
                if j.created_at and j.completed_at
            ]
            if durations:
                avg_duration_seconds = sum(durations) / len(durations)

        # Device metrics
        device_stats = db.query(JobDevice).filter(
            JobDevice.completed_at >= cutoff_time
        ).all()

        total_devices = len(device_stats)
        succeeded_devices = sum(1 for d in device_stats if d.status == DeviceStatus.SUCCEEDED)
        failed_devices = sum(1 for d in device_stats if d.status == DeviceStatus.FAILED)

        # Calculate average device imaging time
        avg_device_duration_seconds = 0
        if device_stats:
            device_durations = [
                (d.completed_at - d.started_at).total_seconds()
                for d in device_stats
                if d.started_at and d.completed_at
            ]
            if device_durations:
                avg_device_duration_seconds = sum(device_durations) / len(device_durations)

        # Notification metrics
        notifications_sent = db.query(NotificationHistory).filter(
            NotificationHistory.sent_at >= cutoff_time
        ).count()

        notifications_delivered = db.query(NotificationHistory).filter(
            NotificationHistory.sent_at >= cutoff_time,
            NotificationHistory.status == "sent"
        ).count()

        # Windows Update metrics
        updates_applied = db.query(WindowsUpdateLog).filter(
            WindowsUpdateLog.started_at >= cutoff_time
        ).all()

        total_updates_installed = sum(log.updates_installed or 0 for log in updates_applied)
        total_updates_failed = sum(log.updates_failed or 0 for log in updates_applied)

        return {
            "period_hours": hours,
            "timestamp": datetime.now().isoformat(),
            "jobs": {
                "total": total_jobs,
                "succeeded": succeeded_jobs,
                "failed": failed_jobs,
                "success_rate": round((succeeded_jobs / total_jobs * 100) if total_jobs > 0 else 0, 2),
                "avg_duration_seconds": round(avg_duration_seconds, 2),
                "avg_duration_minutes": round(avg_duration_seconds / 60, 2)
            },
            "devices": {
                "total": total_devices,
                "succeeded": succeeded_devices,
                "failed": failed_devices,
                "success_rate": round((succeeded_devices / total_devices * 100) if total_devices > 0 else 0, 2),
                "avg_duration_seconds": round(avg_device_duration_seconds, 2),
                "avg_duration_minutes": round(avg_device_duration_seconds / 60, 2)
            },
            "notifications": {
                "sent": notifications_sent,
                "delivered": notifications_delivered,
                "delivery_rate": round((notifications_delivered / notifications_sent * 100) if notifications_sent > 0 else 0, 2)
            },
            "windows_updates": {
                "deployments": len(updates_applied),
                "updates_installed": total_updates_installed,
                "updates_failed": total_updates_failed
            }
        }

    except Exception as e:
        logger.error(f"Failed to get performance metrics: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get performance metrics: {str(e)}")


@router.get("/metrics/realtime")
async def get_realtime_metrics(
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Get real-time system metrics (current snapshot).

    Returns current state of jobs, devices, and system resources.
    """
    try:
        # Current system resources
        cpu_percent = psutil.cpu_percent(interval=0.5)
        memory = psutil.virtual_memory()

        # Current job/device state
        running_jobs = db.query(Job).filter(Job.status == JobStatus.RUNNING).all()
        running_devices = db.query(JobDevice).filter(JobDevice.status == DeviceStatus.RUNNING).all()

        # Active devices by job
        devices_by_job = {}
        for device in running_devices:
            if device.job_id not in devices_by_job:
                devices_by_job[device.job_id] = []
            devices_by_job[device.job_id].append({
                "mac_address": device.mac_address,
                "hostname": device.hostname,
                "progress": device.progress,
                "current_step": device.current_step
            })

        return {
            "timestamp": datetime.now().isoformat(),
            "system": {
                "cpu_percent": cpu_percent,
                "memory_percent": memory.percent,
                "memory_available_mb": round(memory.available / (1024**2), 2)
            },
            "jobs": {
                "running_count": len(running_jobs),
                "running_jobs": [
                    {
                        "id": job.id,
                        "name": job.name,
                        "total_devices": job.total_devices,
                        "succeeded": job.succeeded,
                        "failed": job.failed,
                        "in_progress": job.in_progress,
                        "progress_percent": round((job.succeeded + job.failed) / job.total_devices * 100) if job.total_devices > 0 else 0
                    }
                    for job in running_jobs
                ]
            },
            "devices": {
                "running_count": len(running_devices),
                "devices_by_job": devices_by_job
            }
        }

    except Exception as e:
        logger.error(f"Failed to get realtime metrics: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get realtime metrics: {str(e)}")


@router.get("/database/stats")
async def get_database_stats(
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Get database statistics and table counts.
    """
    try:
        return {
            "timestamp": datetime.now().isoformat(),
            "tables": {
                "jobs": db.query(Job).count(),
                "job_devices": db.query(JobDevice).count(),
                "discovered_devices": db.query(DiscoveredDevice).count(),
                "detected_hardware": db.query(DetectedHardware).count(),
                "notifications": db.query(NotificationHistory).count(),
                "windows_update_logs": db.query(WindowsUpdateLog).count()
            }
        }

    except Exception as e:
        logger.error(f"Failed to get database stats: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get database stats: {str(e)}")


@router.get("/alerts")
async def get_system_alerts(
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Get system health alerts and warnings.

    Checks for:
    - High CPU/memory usage
    - Failed jobs
    - Stuck devices
    - Low disk space
    """
    alerts = []

    try:
        # Check CPU usage
        cpu_percent = psutil.cpu_percent(interval=1)
        if cpu_percent > 90:
            alerts.append({
                "level": "critical",
                "category": "system",
                "message": f"CPU usage critical: {cpu_percent}%",
                "timestamp": datetime.now().isoformat()
            })
        elif cpu_percent > 75:
            alerts.append({
                "level": "warning",
                "category": "system",
                "message": f"CPU usage high: {cpu_percent}%",
                "timestamp": datetime.now().isoformat()
            })

        # Check memory usage
        memory = psutil.virtual_memory()
        if memory.percent > 90:
            alerts.append({
                "level": "critical",
                "category": "system",
                "message": f"Memory usage critical: {memory.percent}%",
                "timestamp": datetime.now().isoformat()
            })
        elif memory.percent > 75:
            alerts.append({
                "level": "warning",
                "category": "system",
                "message": f"Memory usage high: {memory.percent}%",
                "timestamp": datetime.now().isoformat()
            })

        # Check disk space
        disk = psutil.disk_usage('/')
        if disk.percent > 90:
            alerts.append({
                "level": "critical",
                "category": "system",
                "message": f"Disk space critical: {disk.percent}% used",
                "timestamp": datetime.now().isoformat()
            })
        elif disk.percent > 80:
            alerts.append({
                "level": "warning",
                "category": "system",
                "message": f"Disk space low: {disk.percent}% used",
                "timestamp": datetime.now().isoformat()
            })

        # Check for stuck devices (running for > 2 hours)
        two_hours_ago = datetime.now() - timedelta(hours=2)
        stuck_devices = db.query(JobDevice).filter(
            JobDevice.status == DeviceStatus.RUNNING,
            JobDevice.started_at < two_hours_ago
        ).all()

        if stuck_devices:
            alerts.append({
                "level": "warning",
                "category": "jobs",
                "message": f"{len(stuck_devices)} device(s) running for over 2 hours",
                "timestamp": datetime.now().isoformat(),
                "details": [
                    {
                        "mac": d.mac_address,
                        "job_id": d.job_id,
                        "started_at": d.started_at.isoformat()
                    }
                    for d in stuck_devices
                ]
            })

        # Check for recently failed jobs
        last_hour = datetime.now() - timedelta(hours=1)
        failed_jobs = db.query(Job).filter(
            Job.status == JobStatus.FAILED,
            Job.completed_at >= last_hour
        ).count()

        if failed_jobs > 0:
            alerts.append({
                "level": "warning",
                "category": "jobs",
                "message": f"{failed_jobs} job(s) failed in the last hour",
                "timestamp": datetime.now().isoformat()
            })

        return {
            "timestamp": datetime.now().isoformat(),
            "alert_count": len(alerts),
            "critical_count": sum(1 for a in alerts if a["level"] == "critical"),
            "warning_count": sum(1 for a in alerts if a["level"] == "warning"),
            "alerts": alerts
        }

    except Exception as e:
        logger.error(f"Failed to get system alerts: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get system alerts: {str(e)}")
