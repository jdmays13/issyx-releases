from fastapi import APIRouter, Depends, HTTPException, Query, UploadFile, File
from sqlalchemy.orm import Session
from typing import Optional, List
from ..core.database import get_db
from ..models.system_settings import SystemSettings
from ..routes.auth import get_current_user
from pydantic import BaseModel
import psutil
import socket
import os
import shutil
from pathlib import Path

router = APIRouter()


class SystemSettingsResponse(BaseModel):
    pxe_server_ip: Optional[str] = None
    pxe_tftp_root: Optional[str] = None
    use_custom_pxe_ip: bool = False
    use_custom_tftp_path: bool = False
    multicast_enabled: bool = False
    multicast_address: Optional[str] = None
    winpe_display_enabled: bool = False
    winpe_api_endpoint: Optional[str] = None

    # Upload paths
    os_images_path: Optional[str] = None
    drivers_path: Optional[str] = None
    software_path: Optional[str] = None
    scripts_path: Optional[str] = None

    # Network interface
    selected_nic: Optional[str] = None

    # Multicast range
    multicast_start_range: Optional[str] = None
    multicast_end_range: Optional[str] = None

    # Windows Update
    update_mode: Optional[str] = None
    wsus_server: Optional[str] = None

    # Branding
    logo_filename: Optional[str] = None

    class Config:
        from_attributes = True


class SystemSettingsUpdate(BaseModel):
    pxe_server_ip: Optional[str] = None
    pxe_tftp_root: Optional[str] = None
    use_custom_pxe_ip: Optional[bool] = None
    use_custom_tftp_path: Optional[bool] = None
    multicast_enabled: Optional[bool] = None
    multicast_address: Optional[str] = None
    winpe_display_enabled: Optional[bool] = None
    winpe_api_endpoint: Optional[str] = None

    # Upload paths
    os_images_path: Optional[str] = None
    drivers_path: Optional[str] = None
    software_path: Optional[str] = None
    scripts_path: Optional[str] = None

    # Network interface
    selected_nic: Optional[str] = None

    # Multicast range
    multicast_start_range: Optional[str] = None
    multicast_end_range: Optional[str] = None

    # Windows Update
    update_mode: Optional[str] = None
    wsus_server: Optional[str] = None

    # Branding
    logo_filename: Optional[str] = None


class NetworkInterface(BaseModel):
    name: str
    ip: str


class FolderItem(BaseModel):
    name: str
    path: str
    is_directory: bool
    size: Optional[int] = None
    modified: Optional[str] = None


class PathValidationRequest(BaseModel):
    path: str


class PathValidationResponse(BaseModel):
    valid: bool
    exists: bool
    is_directory: bool
    writable: bool
    error: Optional[str] = None


class TestConnectionRequest(BaseModel):
    connection_type: str  # 'pxe', 'tftp', 'path'
    host: Optional[str] = None
    port: Optional[int] = None
    path: Optional[str] = None


class TestConnectionResponse(BaseModel):
    success: bool
    message: str
    details: Optional[dict] = None


@router.get("/system-settings", response_model=SystemSettingsResponse)
async def get_system_settings(
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get system settings."""
    settings = db.query(SystemSettings).filter(SystemSettings.id == 1).first()
    if not settings:
        # Create default settings if not exist
        settings = SystemSettings(id=1)
        db.add(settings)
        db.commit()
        db.refresh(settings)
    return settings


@router.put("/system-settings", response_model=SystemSettingsResponse)
async def update_system_settings(
    settings_data: SystemSettingsUpdate,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Update system settings."""
    settings = db.query(SystemSettings).filter(SystemSettings.id == 1).first()
    if not settings:
        settings = SystemSettings(id=1)
        db.add(settings)

    # Update fields if provided
    if settings_data.pxe_server_ip is not None:
        settings.pxe_server_ip = settings_data.pxe_server_ip
    if settings_data.pxe_tftp_root is not None:
        settings.pxe_tftp_root = settings_data.pxe_tftp_root
    if settings_data.use_custom_pxe_ip is not None:
        settings.use_custom_pxe_ip = settings_data.use_custom_pxe_ip
    if settings_data.use_custom_tftp_path is not None:
        settings.use_custom_tftp_path = settings_data.use_custom_tftp_path
    if settings_data.multicast_enabled is not None:
        settings.multicast_enabled = settings_data.multicast_enabled
    if settings_data.multicast_address is not None:
        settings.multicast_address = settings_data.multicast_address
    if settings_data.winpe_display_enabled is not None:
        settings.winpe_display_enabled = settings_data.winpe_display_enabled
    if settings_data.winpe_api_endpoint is not None:
        settings.winpe_api_endpoint = settings_data.winpe_api_endpoint

    # Upload paths
    if settings_data.os_images_path is not None:
        settings.os_images_path = settings_data.os_images_path
    if settings_data.drivers_path is not None:
        settings.drivers_path = settings_data.drivers_path
    if settings_data.software_path is not None:
        settings.software_path = settings_data.software_path
    if settings_data.scripts_path is not None:
        settings.scripts_path = settings_data.scripts_path

    # Network interface
    if settings_data.selected_nic is not None:
        settings.selected_nic = settings_data.selected_nic

    # Multicast range
    if settings_data.multicast_start_range is not None:
        settings.multicast_start_range = settings_data.multicast_start_range
    if settings_data.multicast_end_range is not None:
        settings.multicast_end_range = settings_data.multicast_end_range

    # Windows Update
    if settings_data.update_mode is not None:
        settings.update_mode = settings_data.update_mode
    if settings_data.wsus_server is not None:
        settings.wsus_server = settings_data.wsus_server

    # Branding
    if settings_data.logo_filename is not None:
        settings.logo_filename = settings_data.logo_filename

    db.commit()
    db.refresh(settings)
    return settings


@router.get("/network-interfaces", response_model=List[NetworkInterface])
async def get_network_interfaces(
    current_user = Depends(get_current_user)
):
    """Get available network interfaces with their IP addresses.
    Returns the primary interface (with default route) first."""
    interfaces = []
    primary_interface = None

    # Try to detect the primary interface (the one with default route)
    try:
        import subprocess
        result = subprocess.run(
            ["ip", "route", "show", "default"],
            capture_output=True,
            text=True,
            timeout=5
        )
        if result.returncode == 0 and result.stdout:
            # Parse: "default via X.X.X.X dev eth0 ..."
            parts = result.stdout.split()
            if "dev" in parts:
                dev_idx = parts.index("dev")
                if dev_idx + 1 < len(parts):
                    primary_interface = parts[dev_idx + 1]
    except Exception:
        pass  # Fallback to no prioritization

    # Get all network interfaces
    all_interfaces = []
    for interface_name, addrs in psutil.net_if_addrs().items():
        for addr in addrs:
            # Only include IPv4 addresses
            if addr.family == socket.AF_INET:
                all_interfaces.append({
                    "name": interface_name,
                    "ip": addr.address
                })
                break  # Only take first IPv4 address per interface

    # Sort to put primary interface first
    if primary_interface:
        # Primary interface first, then others
        for iface in all_interfaces:
            if iface["name"] == primary_interface:
                interfaces.append(iface)
        for iface in all_interfaces:
            if iface["name"] != primary_interface:
                interfaces.append(iface)
    else:
        interfaces = all_interfaces

    return interfaces


@router.get("/browse-folders", response_model=List[FolderItem])
async def browse_folders(
    path: str = Query("/", description="Path to browse"),
    current_user = Depends(get_current_user)
):
    """
    Browse server folders for configuration.
    Returns list of folders and files in the specified path.

    Note: When running in Docker, this browses the Docker container's filesystem.
    Windows network paths (UNC paths) can be entered manually but may not be accessible
    from within the Docker container. For production deployments on Windows, consider
    mapping network shares as Docker volumes.
    """
    try:
        # Handle special path for listing Windows drives
        if path.lower() == "drives" or path == "":
            items = []
            # On Windows, list available drives
            if os.name == 'nt':
                import string
                for letter in string.ascii_uppercase:
                    drive = f"{letter}:\\"
                    if os.path.exists(drive):
                        items.append(FolderItem(
                            name=f"Drive {letter}:",
                            path=drive,
                            is_directory=True
                        ))
            else:
                # On Linux/Docker, show common root directories
                items.append(FolderItem(name="Root (/)", path="/", is_directory=True))
                if os.path.exists("/app"):
                    items.append(FolderItem(name="App (/app)", path="/app", is_directory=True))
            return items

        # Security: Convert to absolute path
        browse_path = Path(path).resolve()

        # Check if path exists
        if not browse_path.exists():
            raise HTTPException(
                status_code=404,
                detail=f"Path does not exist: {path}. Note: Windows network paths (\\\\SERVER\\Share) may not be accessible from Docker container."
            )

        # Check if it's a directory
        if not browse_path.is_dir():
            raise HTTPException(status_code=400, detail="Path is not a directory")

        items = []

        # Add parent directory option if not at root
        if browse_path.parent != browse_path:
            items.append(FolderItem(
                name="..",
                path=str(browse_path.parent),
                is_directory=True
            ))

        # List directory contents
        try:
            for item in sorted(browse_path.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower())):
                try:
                    stat_info = item.stat()
                    items.append(FolderItem(
                        name=item.name,
                        path=str(item),
                        is_directory=item.is_dir(),
                        size=stat_info.st_size if item.is_file() else None,
                        modified=str(stat_info.st_mtime)
                    ))
                except (PermissionError, OSError):
                    # Skip items we can't access
                    continue
        except PermissionError:
            raise HTTPException(status_code=403, detail="Permission denied")

        return items

    except Exception as e:
        if isinstance(e, HTTPException):
            raise e
        raise HTTPException(status_code=500, detail=f"Error browsing folder: {str(e)}")


@router.post("/validate-path", response_model=PathValidationResponse)
async def validate_path(
    request: PathValidationRequest,
    current_user = Depends(get_current_user)
):
    """Validate a file system path."""
    try:
        path_obj = Path(request.path).resolve()

        exists = path_obj.exists()
        is_directory = path_obj.is_dir() if exists else False
        writable = False
        error = None

        if exists and is_directory:
            # Test if writable
            try:
                test_file = path_obj / ".write_test"
                test_file.touch()
                test_file.unlink()
                writable = True
            except (PermissionError, OSError) as e:
                error = f"Path is not writable: {str(e)}"
        elif exists and not is_directory:
            error = "Path exists but is not a directory"
        elif not exists:
            error = "Path does not exist"

        return PathValidationResponse(
            valid=exists and is_directory and writable,
            exists=exists,
            is_directory=is_directory,
            writable=writable,
            error=error
        )
    except Exception as e:
        return PathValidationResponse(
            valid=False,
            exists=False,
            is_directory=False,
            writable=False,
            error=f"Error validating path: {str(e)}"
        )


@router.post("/test-connection", response_model=TestConnectionResponse)
async def test_connection(
    request: TestConnectionRequest,
    current_user = Depends(get_current_user)
):
    """Test connectivity to PXE/TFTP server or storage paths."""
    try:
        if request.connection_type == "path":
            # Test path accessibility
            if not request.path:
                return TestConnectionResponse(
                    success=False,
                    message="Path is required"
                )

            path_obj = Path(request.path).resolve()
            if not path_obj.exists():
                return TestConnectionResponse(
                    success=False,
                    message=f"Path does not exist: {request.path}"
                )

            if not path_obj.is_dir():
                return TestConnectionResponse(
                    success=False,
                    message="Path is not a directory"
                )

            # Test write access
            try:
                test_file = path_obj / ".connection_test"
                test_file.touch()
                test_file.unlink()

                return TestConnectionResponse(
                    success=True,
                    message="Path is accessible and writable",
                    details={"path": str(path_obj)}
                )
            except (PermissionError, OSError) as e:
                return TestConnectionResponse(
                    success=False,
                    message=f"Path exists but is not writable: {str(e)}"
                )

        elif request.connection_type == "pxe":
            # Test PXE/TFTP connectivity
            if not request.host:
                return TestConnectionResponse(
                    success=False,
                    message="Host is required for PXE test"
                )

            # Use socket connection test instead of ping
            # This avoids permission issues with raw sockets (ping requires cap_net_raw)
            try:
                # Test if we can reach the host by opening a socket connection
                # Try common ports: TFTP (69), HTTP (80), or just TCP connection
                test_ports = [69, 80, 22]  # TFTP, HTTP, SSH
                connected = False
                connected_port = None

                for port in test_ports:
                    try:
                        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        sock.settimeout(2)
                        result = sock.connect_ex((request.host, port))
                        sock.close()
                        if result == 0:
                            connected = True
                            connected_port = port
                            break
                    except Exception:
                        continue

                if connected:
                    return TestConnectionResponse(
                        success=True,
                        message=f"Successfully reached PXE server at {request.host}",
                        details={"host": request.host, "port": connected_port}
                    )

                # If no TCP ports responded, try UDP for TFTP
                try:
                    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                    sock.settimeout(2)
                    # Send empty packet to TFTP port
                    sock.sendto(b'\x00\x01test\x00octet\x00', (request.host, 69))
                    # If we get here without exception, network is reachable
                    sock.close()
                    return TestConnectionResponse(
                        success=True,
                        message=f"Successfully reached PXE server at {request.host}",
                        details={"host": request.host, "protocol": "UDP"}
                    )
                except socket.timeout:
                    # Timeout is OK - means network is reachable but no TFTP response
                    return TestConnectionResponse(
                        success=True,
                        message=f"Network reachable at {request.host} (TFTP may need configuration)",
                        details={"host": request.host, "protocol": "UDP"}
                    )
                except Exception as e:
                    return TestConnectionResponse(
                        success=False,
                        message=f"Cannot reach PXE server at {request.host}: {str(e)}"
                    )

            except Exception as e:
                return TestConnectionResponse(
                    success=False,
                    message=f"Connection test failed: {str(e)}"
                )

        elif request.connection_type == "tftp":
            # For TFTP, we'd need to actually test TFTP protocol
            # For now, just test basic connectivity
            if not request.host:
                return TestConnectionResponse(
                    success=False,
                    message="Host is required for TFTP test"
                )

            return TestConnectionResponse(
                success=True,
                message="TFTP test not fully implemented - check PXE connectivity instead",
                details={"host": request.host}
            )

        else:
            return TestConnectionResponse(
                success=False,
                message=f"Unknown connection type: {request.connection_type}"
            )

    except Exception as e:
        return TestConnectionResponse(
            success=False,
            message=f"Error testing connection: {str(e)}"
        )


@router.post("/upload-logo")
async def upload_logo(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Upload company logo for WinPE branding."""
    try:
        # Validate file type
        allowed_extensions = ['.png', '.jpg', '.jpeg', '.svg']
        file_ext = os.path.splitext(file.filename)[1].lower()

        if file_ext not in allowed_extensions:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid file type. Allowed types: {', '.join(allowed_extensions)}"
            )

        # Create uploads directory if it doesn't exist
        upload_dir = Path("/app/uploads/branding")
        upload_dir.mkdir(parents=True, exist_ok=True)

        # Generate unique filename
        filename = f"logo{file_ext}"
        file_path = upload_dir / filename

        # Save file
        with file_path.open("wb") as buffer:
            shutil.copyfileobj(file.file, buffer)

        # Update settings
        settings = db.query(SystemSettings).filter(SystemSettings.id == 1).first()
        if not settings:
            settings = SystemSettings(id=1)
            db.add(settings)

        settings.logo_filename = filename
        db.commit()

        return {
            "success": True,
            "filename": filename,
            "path": str(file_path),
            "message": "Logo uploaded successfully"
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error uploading logo: {str(e)}")
