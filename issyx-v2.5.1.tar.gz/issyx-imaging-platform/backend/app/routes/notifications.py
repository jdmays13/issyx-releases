"""
Notification API Routes

Endpoints for managing notification configurations and viewing notification history.
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
from pydantic import BaseModel, Field
from datetime import datetime
from ..core.database import get_db
from ..core.security import get_current_user
from ..models.notification import (
    NotificationConfig, NotificationHistory,
    NotificationType, NotificationEvent
)
from ..services.notification import NotificationService
import logging
import uuid

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/notifications", tags=["notifications"])


# Request/Response Models
class NotificationConfigCreate(BaseModel):
    """Request to create notification configuration"""
    # Email settings
    email_enabled: bool = False
    email_address: Optional[str] = None

    # Webhook settings
    webhook_enabled: bool = False
    webhook_url: Optional[str] = None
    webhook_type: Optional[str] = "custom"  # "custom", "slack", "teams"

    # In-app settings
    in_app_enabled: bool = True

    # Event subscriptions
    event_subscriptions: dict = Field(default_factory=dict)
    # Example: {"job_started": True, "job_completed": True, "job_failed": True}

    # Rate limiting
    max_notifications_per_hour: Optional[str] = "10"
    notify_business_hours_only: bool = False
    business_hours_start: str = "09:00"
    business_hours_end: str = "17:00"

    # Digest mode
    enable_digest: bool = False
    digest_frequency_hours: int = 24

    is_active: bool = True


class NotificationConfigResponse(BaseModel):
    """Response model for notification configuration"""
    id: str
    user_id: str
    email_enabled: bool
    email_address: Optional[str]
    webhook_enabled: bool
    webhook_url: Optional[str]
    in_app_enabled: bool
    event_subscriptions: dict
    is_active: bool
    created_at: str

    class Config:
        from_attributes = True


class NotificationHistoryResponse(BaseModel):
    """Response model for notification history"""
    id: str
    notification_type: str
    event_type: str
    subject: str
    message: str
    status: str
    delivered_at: Optional[str]
    read_at: Optional[str]
    job_id: Optional[str]
    device_mac: Optional[str]
    created_at: str

    class Config:
        from_attributes = True


class SendNotificationRequest(BaseModel):
    """Request to manually send a notification"""
    event_type: NotificationEvent
    subject: str
    message: str
    user_id: Optional[str] = None
    job_id: Optional[str] = None
    device_mac: Optional[str] = None
    metadata: Optional[dict] = None


# Notification Configuration Endpoints

@router.post("/configs", response_model=NotificationConfigResponse)
async def create_notification_config(
    config_data: NotificationConfigCreate,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Create notification configuration for current user"""
    try:
        user_id = current_user.id

        # Check if user already has a config
        existing = db.query(NotificationConfig).filter(
            NotificationConfig.user_id == user_id
        ).first()

        if existing:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="User already has a notification configuration. Use PUT to update."
            )

        config = NotificationConfig(
            id=str(uuid.uuid4()),
            user_id=user_id,
            **config_data.dict()
        )

        db.add(config)
        db.commit()
        db.refresh(config)

        logger.info(f"Created notification config for user {user_id}")

        return NotificationConfigResponse(
            id=config.id,
            user_id=config.user_id,
            email_enabled=config.email_enabled,
            email_address=config.email_address,
            webhook_enabled=config.webhook_enabled,
            webhook_url=config.webhook_url,
            in_app_enabled=config.in_app_enabled,
            event_subscriptions=config.event_subscriptions or {},
            is_active=config.is_active,
            created_at=config.created_at.isoformat() if config.created_at else ""
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating notification config: {e}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create notification configuration: {str(e)}"
        )


@router.get("/configs/me", response_model=NotificationConfigResponse)
async def get_my_notification_config(
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get notification configuration for current user"""
    try:
        user_id = current_user.id

        config = db.query(NotificationConfig).filter(
            NotificationConfig.user_id == user_id
        ).first()

        if not config:
            # Create default notification config for user
            config = NotificationConfig(
                id=str(uuid.uuid4()),
                user_id=user_id,
                email_enabled=False,
                webhook_enabled=False,
                in_app_enabled=True,
                event_subscriptions={},
                is_active=True
            )
            db.add(config)
            db.commit()
            db.refresh(config)
            logger.info(f"Created default notification config for user {user_id}")

        return NotificationConfigResponse(
            id=config.id,
            user_id=config.user_id,
            email_enabled=config.email_enabled,
            email_address=config.email_address,
            webhook_enabled=config.webhook_enabled,
            webhook_url=config.webhook_url,
            in_app_enabled=config.in_app_enabled,
            event_subscriptions=config.event_subscriptions or {},
            is_active=config.is_active,
            created_at=config.created_at.isoformat() if config.created_at else ""
        )

    except Exception as e:
        logger.error(f"Error getting notification config: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get notification configuration: {str(e)}"
        )


@router.put("/configs/me", response_model=NotificationConfigResponse)
async def update_my_notification_config(
    config_data: NotificationConfigCreate,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Update notification configuration for current user"""
    try:
        user_id = current_user.id

        config = db.query(NotificationConfig).filter(
            NotificationConfig.user_id == user_id
        ).first()

        if not config:
            # Create new config if doesn't exist
            config = NotificationConfig(
                id=str(uuid.uuid4()),
                user_id=user_id
            )
            db.add(config)

        # Update fields
        for key, value in config_data.dict().items():
            setattr(config, key, value)

        db.commit()
        db.refresh(config)

        logger.info(f"Updated notification config for user {user_id}")

        return NotificationConfigResponse(
            id=config.id,
            user_id=config.user_id,
            email_enabled=config.email_enabled,
            email_address=config.email_address,
            webhook_enabled=config.webhook_enabled,
            webhook_url=config.webhook_url,
            in_app_enabled=config.in_app_enabled,
            event_subscriptions=config.event_subscriptions or {},
            is_active=config.is_active,
            created_at=config.created_at.isoformat() if config.created_at else ""
        )

    except Exception as e:
        logger.error(f"Error updating notification config: {e}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update notification configuration: {str(e)}"
        )


@router.delete("/configs/me")
async def delete_my_notification_config(
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Delete notification configuration for current user"""
    try:
        user_id = current_user.id

        config = db.query(NotificationConfig).filter(
            NotificationConfig.user_id == user_id
        ).first()

        if not config:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="No notification configuration found"
            )

        db.delete(config)
        db.commit()

        logger.info(f"Deleted notification config for user {user_id}")

        return {"success": True, "message": "Notification configuration deleted"}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting notification config: {e}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete notification configuration: {str(e)}"
        )


# Notification History Endpoints

@router.get("/history", response_model=List[NotificationHistoryResponse])
async def get_my_notification_history(
    unread_only: bool = False,
    limit: int = 50,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get notification history for current user (in-app notifications)"""
    try:
        user_id = current_user.id

        service = NotificationService(db)
        notifications = await service.get_user_notifications(
            user_id=user_id,
            unread_only=unread_only,
            limit=limit
        )

        return [
            NotificationHistoryResponse(
                id=n.id,
                notification_type=n.notification_type.value,
                event_type=n.event_type.value,
                subject=n.subject,
                message=n.message,
                status=n.status,
                delivered_at=n.delivered_at.isoformat() if n.delivered_at else None,
                read_at=n.read_at.isoformat() if n.read_at else None,
                job_id=n.job_id,
                device_mac=n.device_mac,
                created_at=n.sent_at.isoformat() if n.sent_at else ""
            )
            for n in notifications
        ]

    except Exception as e:
        logger.error(f"Error getting notification history: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get notification history: {str(e)}"
        )


@router.post("/history/{notification_id}/read")
async def mark_notification_as_read(
    notification_id: str,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Mark a notification as read"""
    try:
        user_id = current_user.id

        service = NotificationService(db)
        await service.mark_as_read(notification_id=notification_id, user_id=user_id)

        logger.info(f"Notification {notification_id} marked as read by user {user_id}")

        return {"success": True, "message": "Notification marked as read"}

    except Exception as e:
        logger.error(f"Error marking notification as read: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to mark notification as read: {str(e)}"
        )


@router.post("/history/read-all")
async def mark_all_notifications_as_read(
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Mark all notifications as read for current user"""
    try:
        user_id = current_user.id

        # Get all unread in-app notifications
        notifications = db.query(NotificationHistory).filter(
            NotificationHistory.user_id == user_id,
            NotificationHistory.notification_type == NotificationType.IN_APP,
            NotificationHistory.read_at.is_(None)
        ).all()

        for notification in notifications:
            notification.read_at = datetime.now()

        db.commit()

        logger.info(f"Marked {len(notifications)} notifications as read for user {user_id}")

        return {
            "success": True,
            "message": f"Marked {len(notifications)} notifications as read"
        }

    except Exception as e:
        logger.error(f"Error marking all notifications as read: {e}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to mark notifications as read: {str(e)}"
        )


# Admin Endpoints

@router.post("/send")
async def send_notification(
    request: SendNotificationRequest,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Manually send a notification (admin only)"""
    try:
        # Check if user is admin
        if current_user.role.name not in ['Admin', 'Super Admin']:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only admins can manually send notifications"
            )

        service = NotificationService(db)
        notifications = await service.send_notification(
            event_type=request.event_type,
            subject=request.subject,
            message=request.message,
            user_id=request.user_id,
            job_id=request.job_id,
            device_mac=request.device_mac,
            metadata=request.metadata
        )

        logger.info(
            f"Admin {current_user.id} manually sent notification: "
            f"{len(notifications)} recipients"
        )

        return {
            "success": True,
            "message": f"Notification sent to {len(notifications)} users",
            "notification_count": len(notifications)
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error sending notification: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to send notification: {str(e)}"
        )


@router.get("/events")
async def get_notification_events(
    current_user = Depends(get_current_user)
):
    """Get list of available notification events"""
    return {
        "events": [
            {"value": event.value, "label": event.value.replace("_", " ").title()}
            for event in NotificationEvent
        ]
    }
