from fastapi import APIRouter, Depends, Request
from sqlalchemy.orm import Session
from sqlalchemy import desc
from typing import List, Optional
from datetime import datetime, timedelta
from pydantic import BaseModel
from ..core.database import get_db
from ..models.audit_log import AuditLog
from ..routes.auth import get_current_user
import uuid


router = APIRouter()


class AuditLogResponse(BaseModel):
    id: str
    user_id: str
    user_email: str
    action: str
    resource_type: str
    resource_id: Optional[str]
    description: str
    ip_address: Optional[str]
    timestamp: datetime

    class Config:
        from_attributes = True


async def log_audit_event(
    db: Session,
    user_id: str,
    user_email: str,
    action: str,
    resource_type: str,
    description: str,
    resource_id: Optional[str] = None,
    changes: Optional[dict] = None,
    ip_address: Optional[str] = None,
    user_agent: Optional[str] = None
):
    """Create an audit log entry."""
    audit_log = AuditLog(
        id=f"AUDIT-{uuid.uuid4()}",
        user_id=user_id,
        user_email=user_email,
        action=action,
        resource_type=resource_type,
        resource_id=resource_id,
        description=description,
        changes=changes,
        ip_address=ip_address,
        user_agent=user_agent
    )
    db.add(audit_log)
    db.commit()
    return audit_log


@router.get("/audit-logs", response_model=List[AuditLogResponse])
async def get_audit_logs(
    skip: int = 0,
    limit: int = 100,
    user_id: Optional[str] = None,
    action: Optional[str] = None,
    resource_type: Optional[str] = None,
    days: int = 30,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get audit logs with optional filtering."""
    # Start with base query
    query = db.query(AuditLog)

    # Filter by date range
    since_date = datetime.now() - timedelta(days=days)
    query = query.filter(AuditLog.timestamp >= since_date)

    # Apply filters
    if user_id:
        query = query.filter(AuditLog.user_id == user_id)
    if action:
        query = query.filter(AuditLog.action == action)
    if resource_type:
        query = query.filter(AuditLog.resource_type == resource_type)

    # Order by newest first and paginate
    logs = query.order_by(desc(AuditLog.timestamp)).offset(skip).limit(limit).all()
    return logs


@router.get("/audit-logs/user/{user_id}", response_model=List[AuditLogResponse])
async def get_user_audit_logs(
    user_id: str,
    limit: int = 50,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get audit logs for a specific user."""
    logs = db.query(AuditLog).filter(
        AuditLog.user_id == user_id
    ).order_by(desc(AuditLog.timestamp)).limit(limit).all()
    return logs


@router.get("/audit-logs/resource/{resource_type}/{resource_id}", response_model=List[AuditLogResponse])
async def get_resource_audit_logs(
    resource_type: str,
    resource_id: str,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get audit logs for a specific resource."""
    logs = db.query(AuditLog).filter(
        AuditLog.resource_type == resource_type,
        AuditLog.resource_id == resource_id
    ).order_by(desc(AuditLog.timestamp)).all()
    return logs
