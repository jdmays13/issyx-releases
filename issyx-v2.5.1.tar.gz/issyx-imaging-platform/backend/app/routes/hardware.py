"""
Hardware Detection and Driver Smart Matching API Routes

Endpoints for hardware detection, compatibility mapping, and intelligent driver matching.
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
from pydantic import BaseModel, Field
from ..core.database import get_db
from ..core.security import get_current_user
from ..models.hardware_compatibility import HardwareCompatibility, DetectedHardware
from ..services.driver_smart_match import DriverSmartMatcher
import logging

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/hardware", tags=["hardware"])


# Request/Response Models
class HardwareInfo(BaseModel):
    """Hardware information from device"""
    vendor_id: str
    device_id: str
    subsystem_vendor_id: Optional[str] = None
    subsystem_device_id: Optional[str] = None
    hardware_type: str = "pci"
    device_class: Optional[str] = None
    device_name: Optional[str] = None
    pnp_id: Optional[str] = None
    os_version: Optional[str] = None
    architecture: str = "x64"


class HardwareDetectionRequest(BaseModel):
    """Request from device with detected hardware"""
    device_mac: str
    job_id: Optional[str] = None
    hardware: List[HardwareInfo]


class HardwareDetectionResponse(BaseModel):
    """Response after hardware detection"""
    device_mac: str
    detected_count: int
    matched_drivers: List[dict]
    message: str


class CompatibilityMappingRequest(BaseModel):
    """Request to add hardware-driver compatibility mapping"""
    vendor_id: str
    device_id: str
    driver_id: str
    subsystem_vendor_id: Optional[str] = None
    subsystem_device_id: Optional[str] = None
    hardware_type: str = "pci"
    device_class: Optional[str] = None
    device_name: Optional[str] = None
    manufacturer: Optional[str] = None
    os_version: Optional[str] = None
    architecture: str = "x64"
    verified: bool = False
    confidence_score: str = "high"
    notes: Optional[str] = None


class DriverMatchRequest(BaseModel):
    """Request to match hardware to driver"""
    vendor_id: str
    device_id: str
    subsystem_vendor_id: Optional[str] = None
    subsystem_device_id: Optional[str] = None
    device_class: Optional[str] = None
    os_version: Optional[str] = None
    architecture: str = "x64"


@router.post("/detect", response_model=HardwareDetectionResponse)
async def detect_hardware(
    request: HardwareDetectionRequest,
    db = Depends(get_db)
):
    """
    Receive hardware detection from a device.

    Called during PXE boot when device sends hardware information.
    Performs smart driver matching and returns matched drivers.

    Public endpoint (no auth) - called from PXE environment.
    """
    try:
        matcher = DriverSmartMatcher(db)

        # Convert Pydantic models to dicts
        hardware_info = [hw.dict() for hw in request.hardware]

        # Record hardware and perform smart matching
        detected_records = await matcher.record_detected_hardware(
            device_mac=request.device_mac,
            hardware_info=hardware_info,
            job_id=request.job_id
        )

        # Get matched drivers
        drivers = matcher.get_drivers_for_device(
            device_mac=request.device_mac,
            confidence_threshold="medium"
        )

        matched_drivers = [
            {
                "id": driver.id,
                "name": driver.name,
                "version": driver.version,
                "manufacturer": driver.manufacturer
            }
            for driver in drivers
        ]

        logger.info(
            f"Hardware detection from {request.device_mac}: "
            f"{len(detected_records)} devices, {len(matched_drivers)} drivers matched"
        )

        return HardwareDetectionResponse(
            device_mac=request.device_mac,
            detected_count=len(detected_records),
            matched_drivers=matched_drivers,
            message=f"Detected {len(detected_records)} hardware components, matched {len(matched_drivers)} drivers"
        )

    except Exception as e:
        logger.error(f"Error detecting hardware: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to detect hardware: {str(e)}"
        )


@router.post("/match")
async def match_driver(
    request: DriverMatchRequest,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Match a single hardware component to a driver.

    Returns best matching driver based on hardware IDs.
    """
    try:
        matcher = DriverSmartMatcher(db)

        driver, confidence, method = matcher.match_hardware_to_driver(
            vendor_id=request.vendor_id,
            device_id=request.device_id,
            device_class=request.device_class,
            subsystem_vendor_id=request.subsystem_vendor_id,
            subsystem_device_id=request.subsystem_device_id,
            os_version=request.os_version,
            architecture=request.architecture
        )

        if driver:
            return {
                "matched": True,
                "driver": {
                    "id": driver.id,
                    "name": driver.name,
                    "version": driver.version,
                    "manufacturer": driver.manufacturer
                },
                "confidence": confidence,
                "match_method": method
            }
        else:
            return {
                "matched": False,
                "driver": None,
                "confidence": "none",
                "match_method": "no_match",
                "message": f"No driver found for {request.vendor_id}:{request.device_id}"
            }

    except Exception as e:
        logger.error(f"Error matching driver: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to match driver: {str(e)}"
        )


@router.post("/compatibility")
async def add_compatibility_mapping(
    request: CompatibilityMappingRequest,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Add a hardware-to-driver compatibility mapping.

    Builds the compatibility database for smart driver detection.
    """
    try:
        matcher = DriverSmartMatcher(db)

        compat = await matcher.add_compatibility_mapping(
            vendor_id=request.vendor_id,
            device_id=request.device_id,
            driver_id=request.driver_id,
            subsystem_vendor_id=request.subsystem_vendor_id,
            subsystem_device_id=request.subsystem_device_id,
            hardware_type=request.hardware_type,
            device_class=request.device_class,
            device_name=request.device_name,
            manufacturer=request.manufacturer,
            os_version=request.os_version,
            architecture=request.architecture,
            verified=request.verified,
            confidence_score=request.confidence_score,
            notes=request.notes,
            source="api"
        )

        return {
            "success": True,
            "message": "Compatibility mapping added",
            "mapping_id": compat.id
        }

    except Exception as e:
        logger.error(f"Error adding compatibility mapping: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to add compatibility mapping: {str(e)}"
        )


@router.get("/compatibility")
async def list_compatibility_mappings(
    vendor_id: Optional[str] = None,
    device_class: Optional[str] = None,
    architecture: str = "x64",
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    List hardware compatibility mappings.

    Optionally filter by vendor ID or device class.
    """
    try:
        query = db.query(HardwareCompatibility).filter(
            HardwareCompatibility.architecture == architecture
        )

        if vendor_id:
            query = query.filter(HardwareCompatibility.vendor_id == vendor_id.upper())

        if device_class:
            query = query.filter(HardwareCompatibility.device_class == device_class)

        mappings = query.limit(100).all()

        return {
            "count": len(mappings),
            "mappings": [
                {
                    "id": m.id,
                    "vendor_id": m.vendor_id,
                    "device_id": m.device_id,
                    "device_class": m.device_class,
                    "device_name": m.device_name,
                    "driver_id": m.driver_id,
                    "confidence_score": m.confidence_score,
                    "verified": m.verified
                }
                for m in mappings
            ]
        }

    except Exception as e:
        logger.error(f"Error listing compatibility mappings: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list compatibility mappings: {str(e)}"
        )


@router.get("/detected")
async def list_all_detected_hardware(
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    List all detected hardware from all devices.

    Returns hardware components grouped by device MAC address.
    """
    try:
        detected = db.query(DetectedHardware).all()

        # Group by device MAC
        devices_map = {}
        for d in detected:
            if d.device_mac not in devices_map:
                devices_map[d.device_mac] = []
            devices_map[d.device_mac].append({
                "vendor_id": d.vendor_id,
                "device_id": d.device_id,
                "device_class": d.device_class,
                "device_name": d.device_name,
                "matched_driver_id": d.matched_driver_id,
                "match_confidence": d.match_confidence,
                "match_method": d.match_method,
                "detected_at": d.detected_at.isoformat() if d.detected_at else None
            })

        return {
            "total_hardware_count": len(detected),
            "device_count": len(devices_map),
            "devices": [
                {
                    "device_mac": mac,
                    "hardware_count": len(hardware),
                    "hardware": hardware
                }
                for mac, hardware in devices_map.items()
            ]
        }

    except Exception as e:
        logger.error(f"Error listing all detected hardware: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list detected hardware: {str(e)}"
        )


@router.get("/detected/{device_mac}")
async def get_detected_hardware(
    device_mac: str,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Get hardware detected from a specific device.

    Returns all hardware components and matched drivers.
    """
    try:
        detected = db.query(DetectedHardware).filter(
            DetectedHardware.device_mac == device_mac
        ).all()

        return {
            "device_mac": device_mac,
            "hardware_count": len(detected),
            "hardware": [
                {
                    "vendor_id": d.vendor_id,
                    "device_id": d.device_id,
                    "device_class": d.device_class,
                    "device_name": d.device_name,
                    "matched_driver_id": d.matched_driver_id,
                    "match_confidence": d.match_confidence,
                    "match_method": d.match_method,
                    "detected_at": d.detected_at.isoformat() if d.detected_at else None
                }
                for d in detected
            ]
        }

    except Exception as e:
        logger.error(f"Error getting detected hardware: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get detected hardware: {str(e)}"
        )
