"""
Windows Update API Routes

Endpoints for managing Windows Update configurations and monitoring update deployment.
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
from pydantic import BaseModel, Field
from ..core.database import get_db
from ..core.security import get_current_user
from ..models.windows_update import WindowsUpdateConfig, WindowsUpdateLog, WindowsUpdateMode
from ..services.windows_update import WindowsUpdateService
import logging
import uuid

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/windows-update", tags=["windows-update"])


# Request/Response Models
class WindowsUpdateConfigCreate(BaseModel):
    """Request to create Windows Update configuration"""
    name: str
    mode: WindowsUpdateMode = WindowsUpdateMode.ONLINE

    # WSUS Settings
    wsus_server_url: Optional[str] = None
    wsus_server_port: int = 8530
    wsus_use_ssl: bool = True
    wsus_target_group: Optional[str] = None

    # Online Settings
    online_defer_upgrades: bool = False
    online_include_recommended: bool = True
    online_auto_reboot: bool = True
    online_reboot_delay_minutes: int = 15

    # Offline Settings
    offline_package_path: Optional[str] = None
    offline_apply_order: Optional[str] = None

    # General Settings
    max_download_time_minutes: int = 120
    max_install_time_minutes: int = 180
    skip_on_timeout: bool = False
    retry_on_failure: bool = True
    max_retries: int = 3

    # Filtering
    include_security_updates: bool = True
    include_critical_updates: bool = True
    include_driver_updates: bool = False
    include_feature_updates: bool = False
    exclude_preview_updates: bool = True

    is_default: bool = False
    notes: Optional[str] = None


class WindowsUpdateConfigResponse(BaseModel):
    """Response model for Windows Update configuration"""
    id: str
    name: str
    mode: str
    is_default: bool
    created_at: str

    class Config:
        from_attributes = True


@router.post("/configs", response_model=WindowsUpdateConfigResponse)
async def create_update_config(
    config_data: WindowsUpdateConfigCreate,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Create a new Windows Update configuration"""
    try:
        # If setting as default, unset other defaults
        if config_data.is_default:
            db.query(WindowsUpdateConfig).update({"is_default": False})

        config = WindowsUpdateConfig(
            id=str(uuid.uuid4()),
            created_by=current_user.id,
            **config_data.dict()
        )

        db.add(config)
        db.commit()
        db.refresh(config)

        logger.info(f"Created Windows Update config: {config.name} ({config.mode})")

        return WindowsUpdateConfigResponse(
            id=config.id,
            name=config.name,
            mode=config.mode.value,
            is_default=config.is_default,
            created_at=config.created_at.isoformat() if config.created_at else ""
        )

    except Exception as e:
        logger.error(f"Error creating Windows Update config: {e}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create configuration: {str(e)}"
        )


@router.get("/configs", response_model=List[WindowsUpdateConfigResponse])
async def list_update_configs(
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """List all Windows Update configurations"""
    try:
        configs = db.query(WindowsUpdateConfig).all()

        return [
            WindowsUpdateConfigResponse(
                id=c.id,
                name=c.name,
                mode=c.mode.value,
                is_default=c.is_default,
                created_at=c.created_at.isoformat() if c.created_at else ""
            )
            for c in configs
        ]

    except Exception as e:
        logger.error(f"Error listing Windows Update configs: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list configurations: {str(e)}"
        )


@router.get("/configs/{config_id}")
async def get_update_config(
    config_id: str,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get a specific Windows Update configuration"""
    try:
        config = db.query(WindowsUpdateConfig).filter(
            WindowsUpdateConfig.id == config_id
        ).first()

        if not config:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Configuration {config_id} not found"
            )

        return config

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting Windows Update config: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get configuration: {str(e)}"
        )


@router.put("/configs/{config_id}")
async def update_config(
    config_id: str,
    config_data: WindowsUpdateConfigCreate,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Update a Windows Update configuration"""
    try:
        config = db.query(WindowsUpdateConfig).filter(
            WindowsUpdateConfig.id == config_id
        ).first()

        if not config:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Configuration {config_id} not found"
            )

        # If setting as default, unset other defaults
        if config_data.is_default and not config.is_default:
            db.query(WindowsUpdateConfig).filter(
                WindowsUpdateConfig.id != config_id
            ).update({"is_default": False})

        # Update fields
        for key, value in config_data.dict().items():
            setattr(config, key, value)

        db.commit()
        db.refresh(config)

        logger.info(f"Updated Windows Update config: {config.name}")

        return config

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating Windows Update config: {e}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update configuration: {str(e)}"
        )


@router.delete("/configs/{config_id}")
async def delete_config(
    config_id: str,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Delete a Windows Update configuration"""
    try:
        config = db.query(WindowsUpdateConfig).filter(
            WindowsUpdateConfig.id == config_id
        ).first()

        if not config:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Configuration {config_id} not found"
            )

        if config.is_default:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Cannot delete default configuration"
            )

        db.delete(config)
        db.commit()

        logger.info(f"Deleted Windows Update config: {config.name}")

        return {"success": True, "message": f"Configuration {config_id} deleted"}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting Windows Update config: {e}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete configuration: {str(e)}"
        )


@router.get("/logs")
async def get_update_logs(
    job_id: Optional[str] = None,
    device_mac: Optional[str] = None,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get Windows Update logs filtered by job or device"""
    try:
        service = WindowsUpdateService(db)
        logs = await service.get_update_status(job_id=job_id, device_mac=device_mac)

        return {
            "count": len(logs),
            "logs": [
                {
                    "id": log.id,
                    "job_id": log.job_id,
                    "device_mac": log.device_mac,
                    "mode": log.update_mode.value if log.update_mode else None,
                    "status": log.status,
                    "updates_found": log.updates_found,
                    "updates_installed": log.updates_installed,
                    "updates_failed": log.updates_failed,
                    "started_at": log.started_at.isoformat() if log.started_at else None,
                    "completed_at": log.completed_at.isoformat() if log.completed_at else None,
                    "duration_seconds": log.duration_seconds,
                    "reboot_required": log.reboot_required,
                    "error_message": log.error_message
                }
                for log in logs
            ]
        }

    except Exception as e:
        logger.error(f"Error getting Windows Update logs: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get logs: {str(e)}"
        )


@router.post("/logs/{log_id}/retry")
async def retry_update(
    log_id: str,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Retry a failed Windows Update operation"""
    try:
        service = WindowsUpdateService(db)
        log = await service.retry_failed_updates(log_id)

        return {
            "success": True,
            "message": "Windows Update retry initiated",
            "log_id": log.id,
            "status": log.status
        }

    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        logger.error(f"Error retrying Windows Update: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to retry update: {str(e)}"
        )
