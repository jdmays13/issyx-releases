from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime
from ..core.database import get_db
from ..models.job import Job, JobDevice, JobStatus, DeviceStatus, ImagingMode
from ..routes.auth import get_current_user
from ..services.scheduler import schedule_job, cancel_scheduled_job, reschedule_job
from pydantic import BaseModel

router = APIRouter()


class JobResponse(BaseModel):
    id: str
    customer_id: str = None
    profile_id: str = None
    status: str
    imaging_mode: str = None
    total_devices: int

    class Config:
        from_attributes = True


class JobCreate(BaseModel):
    id: str
    customer_id: str
    profile_id: str
    total_devices: int = 0
    scheduled_for: Optional[datetime] = None
    is_recurring: Optional[bool] = False
    recurrence_pattern: Optional[str] = None


class JobUpdate(BaseModel):
    customer_id: Optional[str] = None
    profile_id: Optional[str] = None
    status: Optional[str] = None
    scheduled_for: Optional[datetime] = None
    is_recurring: Optional[bool] = None
    recurrence_pattern: Optional[str] = None


class JobDeviceCreate(BaseModel):
    mac_address: str
    hostname: Optional[str] = None
    ip_address: Optional[str] = None


@router.get("/jobs", response_model=List[JobResponse])
async def get_jobs(
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get all jobs."""
    return db.query(Job).all()


@router.get("/jobs/scheduled", response_model=List[JobResponse])
async def get_scheduled_jobs(
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get all scheduled jobs (not yet executed)."""
    return db.query(Job).filter(Job.status == JobStatus.SCHEDULED).all()


@router.get("/jobs/recurring", response_model=List[JobResponse])
async def get_recurring_jobs(
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get all recurring jobs."""
    return db.query(Job).filter(Job.is_recurring == True).all()


@router.post("/jobs", response_model=JobResponse)
async def create_job(
    job_data: JobCreate,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Create a new job."""
    # Check if job ID already exists
    existing = db.query(Job).filter(Job.id == job_data.id).first()
    if existing:
        raise HTTPException(status_code=400, detail="Job ID already exists")

    # Determine initial status based on scheduling
    if job_data.scheduled_for and job_data.scheduled_for > datetime.now():
        initial_status = JobStatus.SCHEDULED
    else:
        initial_status = JobStatus.QUEUED

    # Determine imaging mode based on device count
    # If 2 or more devices, use multicast for efficiency
    # If 1 device, use unicast (direct HTTP)
    imaging_mode = ImagingMode.MULTICAST if job_data.total_devices >= 2 else ImagingMode.UNICAST

    # Create new job
    new_job = Job(
        id=job_data.id,
        customer_id=job_data.customer_id,
        profile_id=job_data.profile_id,
        status=initial_status,
        imaging_mode=imaging_mode,
        total_devices=job_data.total_devices,
        created_by=current_user.id,
        scheduled_for=job_data.scheduled_for,
        is_recurring=job_data.is_recurring or False,
        recurrence_pattern=job_data.recurrence_pattern
    )

    # Set next_run_at for scheduled jobs
    if job_data.scheduled_for:
        new_job.next_run_at = job_data.scheduled_for

    db.add(new_job)
    db.commit()
    db.refresh(new_job)

    # Schedule the job if it has a scheduled_for time
    if new_job.status == JobStatus.SCHEDULED:
        await schedule_job(new_job, db)

    return new_job


@router.put("/jobs/{job_id}", response_model=JobResponse)
async def update_job(
    job_id: str,
    job_data: JobUpdate,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Update a job."""
    job = db.query(Job).filter(Job.id == job_id).first()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    # Update fields if provided
    if job_data.customer_id is not None:
        job.customer_id = job_data.customer_id
    if job_data.profile_id is not None:
        job.profile_id = job_data.profile_id
    if job_data.scheduled_for is not None:
        job.scheduled_for = job_data.scheduled_for
        job.next_run_at = job_data.scheduled_for
    if job_data.is_recurring is not None:
        job.is_recurring = job_data.is_recurring
    if job_data.recurrence_pattern is not None:
        job.recurrence_pattern = job_data.recurrence_pattern
    if job_data.status is not None:
        job.status = JobStatus(job_data.status)

        # Update timestamps based on status
        if job_data.status == JobStatus.RUNNING and not job.started_at:
            job.started_at = datetime.now()
        elif job_data.status in [JobStatus.SUCCEEDED, JobStatus.FAILED, JobStatus.CANCELLED]:
            if not job.completed_at:
                job.completed_at = datetime.now()

    db.commit()
    db.refresh(job)

    # Reschedule if scheduling-related fields changed
    if (job_data.scheduled_for is not None or
        job_data.is_recurring is not None or
        job_data.recurrence_pattern is not None):
        if job.status == JobStatus.SCHEDULED:
            await reschedule_job(job, db)
        else:
            # Job status changed away from SCHEDULED - cancel schedule
            await cancel_scheduled_job(job.id)

    return job


@router.delete("/jobs/{job_id}")
async def delete_job(
    job_id: str,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Delete/cancel a job."""
    job = db.query(Job).filter(Job.id == job_id).first()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    # Cancel scheduled job if it exists
    if job.status == JobStatus.SCHEDULED:
        await cancel_scheduled_job(job.id)

    # If job is running, cancel it instead of deleting
    if job.status in [JobStatus.RUNNING, JobStatus.QUEUED]:
        job.status = JobStatus.CANCELLED
        job.completed_at = datetime.now()
        db.commit()
        return {"message": "Job cancelled successfully"}

    # Delete the job (cascade will delete related devices)
    db.delete(job)
    db.commit()
    return {"message": "Job deleted successfully"}


@router.post("/jobs/{job_id}/devices")
async def add_devices_to_job(
    job_id: str,
    devices: List[JobDeviceCreate],
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Add devices to a job."""
    job = db.query(Job).filter(Job.id == job_id).first()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    # Add devices
    for device_data in devices:
        device = JobDevice(
            job_id=job_id,
            mac_address=device_data.mac_address,
            hostname=device_data.hostname,
            ip_address=device_data.ip_address,
            status=DeviceStatus.QUEUED
        )
        db.add(device)

    # Update total devices count
    job.total_devices = len(job.devices) + len(devices)

    db.commit()
    return {"message": f"Added {len(devices)} devices to job"}


@router.get("/jobs/{job_id}/devices")
async def get_job_devices(
    job_id: str,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get all devices for a job."""
    job = db.query(Job).filter(Job.id == job_id).first()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    return job.devices


@router.get("/jobs/analytics/summary")
async def get_jobs_analytics_summary(
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Get analytics summary for all jobs.

    Returns:
    - Total jobs count
    - Jobs by status breakdown
    - Total devices imaged
    - Success rate
    - Average imaging time
    - Jobs over time (last 30 days)
    """
    from sqlalchemy import func
    from datetime import datetime, timedelta

    all_jobs = db.query(Job).all()

    # Basic counts
    total_jobs = len(all_jobs)
    jobs_by_status = {
        "Queued": len([j for j in all_jobs if j.status == JobStatus.QUEUED]),
        "Running": len([j for j in all_jobs if j.status == JobStatus.RUNNING]),
        "Succeeded": len([j for j in all_jobs if j.status == JobStatus.SUCCEEDED]),
        "Failed": len([j for j in all_jobs if j.status == JobStatus.FAILED]),
        "Scheduled": len([j for j in all_jobs if j.status == JobStatus.SCHEDULED]),
    }

    # Device statistics
    total_devices = sum(j.total_devices for j in all_jobs)
    total_succeeded = sum(j.succeeded for j in all_jobs)
    total_failed = sum(j.failed for j in all_jobs)

    success_rate = 0
    if total_devices > 0:
        success_rate = round((total_succeeded / total_devices) * 100, 2)

    # Average imaging time (only for completed jobs)
    completed_jobs = [j for j in all_jobs if j.status in [JobStatus.SUCCEEDED, JobStatus.FAILED] and j.started_at and j.completed_at]
    avg_duration_seconds = 0
    if completed_jobs:
        total_seconds = sum((j.completed_at - j.started_at).total_seconds() for j in completed_jobs)
        avg_duration_seconds = total_seconds / len(completed_jobs)

    # Jobs over last 30 days
    thirty_days_ago = datetime.now() - timedelta(days=30)
    recent_jobs = [j for j in all_jobs if j.created_at and j.created_at >= thirty_days_ago]

    # Group by day
    jobs_by_day = {}
    for job in recent_jobs:
        day_key = job.created_at.strftime('%Y-%m-%d')
        jobs_by_day[day_key] = jobs_by_day.get(day_key, 0) + 1

    return {
        "total_jobs": total_jobs,
        "jobs_by_status": jobs_by_status,
        "total_devices": total_devices,
        "total_succeeded": total_succeeded,
        "total_failed": total_failed,
        "success_rate": success_rate,
        "avg_duration_seconds": int(avg_duration_seconds),
        "jobs_over_time": jobs_by_day,
        "completed_jobs_count": len(completed_jobs),
    }


@router.get("/jobs/analytics/performance")
async def get_jobs_performance_metrics(
    days: int = 30,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Get performance metrics for jobs over specified time period.

    Returns detailed performance analytics including:
    - Average devices per job
    - Fastest/slowest jobs
    - Peak imaging times
    - Failure analysis
    """
    from datetime import datetime, timedelta

    cutoff_date = datetime.now() - timedelta(days=days)
    recent_jobs = db.query(Job).filter(Job.created_at >= cutoff_date).all()

    if not recent_jobs:
        return {
            "message": "No jobs found in the specified time period",
            "days": days
        }

    # Calculate metrics
    completed_jobs = [j for j in recent_jobs if j.status in [JobStatus.SUCCEEDED, JobStatus.FAILED] and j.started_at and j.completed_at]

    avg_devices_per_job = sum(j.total_devices for j in recent_jobs) / len(recent_jobs) if recent_jobs else 0

    # Fastest and slowest jobs
    fastest_job = None
    slowest_job = None
    if completed_jobs:
        job_durations = [(j, (j.completed_at - j.started_at).total_seconds()) for j in completed_jobs]
        job_durations.sort(key=lambda x: x[1])

        fastest_job = {
            "job_id": job_durations[0][0].id,
            "duration_seconds": int(job_durations[0][1]),
            "devices": job_durations[0][0].total_devices
        }
        slowest_job = {
            "job_id": job_durations[-1][0].id,
            "duration_seconds": int(job_durations[-1][1]),
            "devices": job_durations[-1][0].total_devices
        }

    # Failure analysis
    failed_jobs = [j for j in recent_jobs if j.status == JobStatus.FAILED]
    failure_rate = (len(failed_jobs) / len(recent_jobs)) * 100 if recent_jobs else 0

    # Most common failure reasons (from device errors)
    failure_reasons = {}
    for job in failed_jobs:
        for device in job.devices:
            if device.status == DeviceStatus.FAILED and device.error_message:
                failure_reasons[device.error_message] = failure_reasons.get(device.error_message, 0) + 1

    return {
        "time_period_days": days,
        "total_jobs": len(recent_jobs),
        "completed_jobs": len(completed_jobs),
        "avg_devices_per_job": round(avg_devices_per_job, 2),
        "fastest_job": fastest_job,
        "slowest_job": slowest_job,
        "failure_rate": round(failure_rate, 2),
        "failed_jobs_count": len(failed_jobs),
        "common_failure_reasons": dict(sorted(failure_reasons.items(), key=lambda x: x[1], reverse=True)[:10])
    }


@router.get("/jobs/export/csv")
async def export_jobs_csv(
    status: Optional[str] = None,
    customer_id: Optional[str] = None,
    days: Optional[int] = None,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Export jobs to CSV format with optional filtering.
    """
    from datetime import datetime, timedelta
    from io import StringIO
    import csv
    from fastapi.responses import StreamingResponse

    # Build query with filters
    query = db.query(Job)

    if status:
        query = query.filter(Job.status == status)

    if customer_id:
        query = query.filter(Job.customer_id == customer_id)

    if days:
        cutoff_date = datetime.now() - timedelta(days=days)
        query = query.filter(Job.created_at >= cutoff_date)

    jobs = query.all()

    # Create CSV
    output = StringIO()
    writer = csv.writer(output)

    # Header
    writer.writerow([
        'Job ID', 'Customer ID', 'Profile ID', 'Status',
        'Total Devices', 'Succeeded', 'Failed', 'In Progress',
        'Created At', 'Started At', 'Completed At', 'Duration'
    ])

    # Data rows
    for job in jobs:
        duration = ""
        if job.started_at and job.completed_at:
            duration = str(job.completed_at - job.started_at)

        writer.writerow([
            job.id,
            job.customer_id or '',
            job.profile_id or '',
            job.status.value if job.status else '',
            job.total_devices or 0,
            job.succeeded or 0,
            job.failed or 0,
            job.in_progress or 0,
            job.created_at.isoformat() if job.created_at else '',
            job.started_at.isoformat() if job.started_at else '',
            job.completed_at.isoformat() if job.completed_at else '',
            duration
        ])

    output.seek(0)

    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename=jobs_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"}
    )
