from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional, Dict, Any
from ..core.database import get_db
from ..models.master_profile import MasterProfile, DriverMode, WindowsUpdates
from ..routes.auth import get_current_user
from pydantic import BaseModel

router = APIRouter()


class MasterProfileResponse(BaseModel):
    id: str
    name: str
    customer_id: str = None

    class Config:
        from_attributes = True


class MasterProfileCreate(BaseModel):
    id: str
    name: str
    customer_id: str
    os_id: Optional[str] = None
    driver_mode: str = "smart"  # smart = hardware compatibility, all = all drivers
    windows_updates: str = "offline"
    system_config: Optional[Dict[str, Any]] = None
    task_sequence: Optional[List[Dict[str, Any]]] = None


class MasterProfileUpdate(BaseModel):
    name: Optional[str] = None
    customer_id: Optional[str] = None
    os_id: Optional[str] = None
    driver_mode: Optional[str] = None
    windows_updates: Optional[str] = None
    system_config: Optional[Dict[str, Any]] = None
    task_sequence: Optional[List[Dict[str, Any]]] = None


@router.get("/master-profiles", response_model=List[MasterProfileResponse])
async def get_master_profiles(
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get all master profiles."""
    return db.query(MasterProfile).all()


@router.post("/master-profiles", response_model=MasterProfileResponse)
async def create_master_profile(
    profile_data: MasterProfileCreate,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Create a new master profile."""
    # Check if profile ID already exists
    existing = db.query(MasterProfile).filter(MasterProfile.id == profile_data.id).first()
    if existing:
        raise HTTPException(status_code=400, detail="Profile ID already exists")

    # Create new profile
    new_profile = MasterProfile(
        id=profile_data.id,
        name=profile_data.name,
        customer_id=profile_data.customer_id,
        os_id=profile_data.os_id,
        driver_mode=DriverMode(profile_data.driver_mode),
        windows_updates=WindowsUpdates(profile_data.windows_updates),
        system_config=profile_data.system_config,
        task_sequence=profile_data.task_sequence
    )

    db.add(new_profile)
    db.commit()
    db.refresh(new_profile)
    return new_profile


@router.put("/master-profiles/{profile_id}", response_model=MasterProfileResponse)
async def update_master_profile(
    profile_id: str,
    profile_data: MasterProfileUpdate,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Update a master profile."""
    profile = db.query(MasterProfile).filter(MasterProfile.id == profile_id).first()
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    # Update fields if provided
    if profile_data.name is not None:
        profile.name = profile_data.name
    if profile_data.customer_id is not None:
        profile.customer_id = profile_data.customer_id
    if profile_data.os_id is not None:
        profile.os_id = profile_data.os_id
    if profile_data.driver_mode is not None:
        profile.driver_mode = DriverMode(profile_data.driver_mode)
    if profile_data.windows_updates is not None:
        profile.windows_updates = WindowsUpdates(profile_data.windows_updates)
    if profile_data.system_config is not None:
        profile.system_config = profile_data.system_config
    if profile_data.task_sequence is not None:
        profile.task_sequence = profile_data.task_sequence

    db.commit()
    db.refresh(profile)
    return profile


@router.delete("/master-profiles/{profile_id}")
async def delete_master_profile(
    profile_id: str,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Delete a master profile."""
    profile = db.query(MasterProfile).filter(MasterProfile.id == profile_id).first()
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    # Check if profile is in use by any jobs
    if profile.jobs:
        raise HTTPException(
            status_code=400,
            detail=f"Cannot delete profile. It is in use by {len(profile.jobs)} job(s)"
        )

    db.delete(profile)
    db.commit()
    return {"message": "Profile deleted successfully"}


# Software management endpoints

class ProfileSoftwareItem(BaseModel):
    software_id: str
    install_order: int


class ProfileSoftwareUpdate(BaseModel):
    software_list: List[ProfileSoftwareItem]


@router.get("/master-profiles/{profile_id}/software")
async def get_profile_software(
    profile_id: str,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get all software assigned to a profile with install order."""
    from sqlalchemy import select
    from ..models.master_profile import master_profile_software
    from ..models.software import SoftwareCatalog

    # Query software with install order
    stmt = (
        select(SoftwareCatalog, master_profile_software.c.install_order)
        .join(master_profile_software, SoftwareCatalog.id == master_profile_software.c.software_id)
        .where(master_profile_software.c.profile_id == profile_id)
        .order_by(master_profile_software.c.install_order)
    )

    result = db.execute(stmt).all()

    return [
        {
            "id": software.id,
            "name": software.name,
            "version": software.version,
            "file_path": software.file_path,
            "file_size": software.file_size,
            "description": software.description,
            "install_params": software.install_params,
            "install_order": install_order
        }
        for software, install_order in result
    ]


@router.put("/master-profiles/{profile_id}/software")
async def update_profile_software(
    profile_id: str,
    software_update: ProfileSoftwareUpdate,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Update the software list for a profile with install order."""
    from ..models.master_profile import master_profile_software

    # Check if profile exists
    profile = db.query(MasterProfile).filter(MasterProfile.id == profile_id).first()
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    # Delete existing software assignments
    db.execute(
        master_profile_software.delete().where(
            master_profile_software.c.profile_id == profile_id
        )
    )

    # Insert new software assignments with install order
    for item in software_update.software_list:
        db.execute(
            master_profile_software.insert().values(
                profile_id=profile_id,
                software_id=item.software_id,
                install_order=item.install_order
            )
        )

    db.commit()

    return {"message": "Profile software updated successfully"}
