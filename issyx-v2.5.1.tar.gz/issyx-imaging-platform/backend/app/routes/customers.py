from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from ..core.database import get_db
from ..models.customer import Customer
from ..routes.auth import get_current_user
from pydantic import BaseModel

router = APIRouter()


class CustomerCreate(BaseModel):
    id: str
    name: str
    contact: str = None
    status: str = "Active"


class CustomerUpdate(BaseModel):
    name: str
    contact: str = None
    status: str = "Active"

    class Config:
        extra = "ignore"  # Ignore extra fields like 'id'


class CustomerResponse(BaseModel):
    id: str
    name: str
    contact: str = None
    status: str

    class Config:
        from_attributes = True


@router.get("/customers", response_model=List[CustomerResponse])
async def get_customers(
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get all customers."""
    customers = db.query(Customer).all()
    return customers


@router.post("/customers", response_model=CustomerResponse, status_code=status.HTTP_201_CREATED)
async def create_customer(
    customer: CustomerCreate,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Create a new customer."""
    # Check if customer ID already exists
    existing = db.query(Customer).filter(Customer.id == customer.id).first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Customer ID already exists"
        )

    new_customer = Customer(**customer.model_dump())
    db.add(new_customer)
    db.commit()
    db.refresh(new_customer)
    return new_customer


@router.get("/customers/{customer_id}", response_model=CustomerResponse)
async def get_customer(
    customer_id: str,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get a specific customer."""
    customer = db.query(Customer).filter(Customer.id == customer_id).first()
    if not customer:
        raise HTTPException(status_code=404, detail="Customer not found")
    return customer


@router.put("/customers/{customer_id}", response_model=CustomerResponse)
async def update_customer(
    customer_id: str,
    customer: CustomerUpdate,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Update a customer."""
    db_customer = db.query(Customer).filter(Customer.id == customer_id).first()
    if not db_customer:
        raise HTTPException(status_code=404, detail="Customer not found")

    for key, value in customer.model_dump().items():
        setattr(db_customer, key, value)

    db.commit()
    db.refresh(db_customer)
    return db_customer


@router.delete("/customers/{customer_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_customer(
    customer_id: str,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Delete a customer."""
    customer = db.query(Customer).filter(Customer.id == customer_id).first()
    if not customer:
        raise HTTPException(status_code=404, detail="Customer not found")

    db.delete(customer)
    db.commit()
    return None
