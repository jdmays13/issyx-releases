from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional
from ..core.database import get_db
from ..models.driver import DriverLibrary
from ..routes.auth import get_current_user
from pydantic import BaseModel
import uuid

router = APIRouter()


class DriverResponse(BaseModel):
    id: str
    name: str
    version: str
    manufacturer: str = None
    category: str = None

    class Config:
        from_attributes = True


class DriverCreate(BaseModel):
    name: str
    version: str
    manufacturer: str
    category: Optional[str] = None
    hw_id: Optional[str] = None


@router.get("/drivers", response_model=List[DriverResponse])
async def get_drivers(
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get all drivers from library."""
    return db.query(DriverLibrary).all()


@router.post("/drivers", response_model=DriverResponse)
async def create_driver(
    driver_data: DriverCreate,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Create a new driver entry. File must be uploaded separately via /upload/driver/{driver_id}."""
    new_driver = DriverLibrary(
        id=f"DRV-{str(uuid.uuid4())[:8]}",
        name=driver_data.name,
        version=driver_data.version,
        manufacturer=driver_data.manufacturer,
        category=driver_data.category,
        hw_id=driver_data.hw_id,
        file_path=None,  # Will be set when file is uploaded
        file_size=None,
        hash_sha256=None
    )

    db.add(new_driver)
    db.commit()
    db.refresh(new_driver)
    return new_driver


@router.delete("/drivers/{driver_id}")
async def delete_driver(
    driver_id: str,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Delete a driver and its associated file."""
    from pathlib import Path
    import logging

    logger = logging.getLogger(__name__)

    driver = db.query(DriverLibrary).filter(DriverLibrary.id == driver_id).first()
    if not driver:
        raise HTTPException(status_code=404, detail="Driver not found")

    # Delete physical file if it exists
    if driver.file_path:
        try:
            file_path = Path(driver.file_path)
            if file_path.exists():
                file_path.unlink()
                logger.info(f"Deleted driver file: {driver.file_path}")
        except Exception as e:
            logger.error(f"Failed to delete driver file {driver.file_path}: {str(e)}")
            # Continue with database deletion even if file deletion fails

    db.delete(driver)
    db.commit()
    return {"message": "Driver deleted successfully"}
