from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends
from typing import Dict, Set
import json
import asyncio
from ..core.redis_client import redis_store

router = APIRouter()

# Store active WebSocket connections by user ID
active_connections: Dict[str, Set[WebSocket]] = {}

# Job update TTL: 24 hours (86400 seconds)
JOB_UPDATE_TTL = 86400


class ConnectionManager:
    def __init__(self):
        self.active_connections: Dict[str, Set[WebSocket]] = {}

    async def connect(self, websocket: WebSocket, user_id: str):
        await websocket.accept()
        if user_id not in self.active_connections:
            self.active_connections[user_id] = set()
        self.active_connections[user_id].add(websocket)

    def disconnect(self, websocket: WebSocket, user_id: str):
        if user_id in self.active_connections:
            self.active_connections[user_id].discard(websocket)
            if not self.active_connections[user_id]:
                del self.active_connections[user_id]

    async def send_personal_message(self, message: dict, user_id: str):
        """Send message to all connections for a specific user"""
        if user_id in self.active_connections:
            disconnected = set()
            for connection in self.active_connections[user_id]:
                try:
                    await connection.send_json(message)
                except Exception:
                    disconnected.add(connection)

            # Clean up disconnected clients
            for connection in disconnected:
                self.disconnect(connection, user_id)

    async def broadcast(self, message: dict):
        """Broadcast message to all connected clients"""
        for user_id in list(self.active_connections.keys()):
            await self.send_personal_message(message, user_id)


manager = ConnectionManager()


@router.websocket("/ws/{client_id}")
async def websocket_endpoint(websocket: WebSocket, client_id: str):
    """
    WebSocket endpoint for real-time updates.
    Client should send authentication token after connecting.
    """
    await websocket.accept()
    user_id = None

    try:
        # Wait for authentication message
        auth_data = await websocket.receive_json()

        if auth_data.get('type') != 'auth' or 'token' not in auth_data:
            await websocket.send_json({
                'type': 'error',
                'message': 'Authentication required'
            })
            await websocket.close()
            return

        # Validate JWT token and get user_id
        from ..core.security import decode_access_token
        from ..core.database import get_db
        from ..models import User

        token = auth_data['token']
        payload = decode_access_token(token)

        if payload is None:
            await websocket.send_json({
                'type': 'error',
                'message': 'Invalid or expired token'
            })
            await websocket.close()
            return

        # Extract user email from token
        email = payload.get("sub")
        if not email:
            await websocket.send_json({
                'type': 'error',
                'message': 'Invalid token payload'
            })
            await websocket.close()
            return

        # Verify user exists in database
        db = next(get_db())
        try:
            user = db.query(User).filter(User.email == email).first()
            if not user:
                await websocket.send_json({
                    'type': 'error',
                    'message': 'User not found'
                })
                await websocket.close()
                return

            user_id = user.id
        finally:
            db.close()

        # Add to active connections
        if user_id not in manager.active_connections:
            manager.active_connections[user_id] = set()
        manager.active_connections[user_id].add(websocket)

        # Send connection confirmation
        await websocket.send_json({
            'type': 'connected',
            'message': 'WebSocket connection established',
            'user_id': user_id
        })

        # Keep connection alive and handle incoming messages
        while True:
            try:
                data = await websocket.receive_json()

                # Handle ping/pong for keepalive
                if data.get('type') == 'ping':
                    await websocket.send_json({'type': 'pong'})

                # Handle subscription to specific job updates
                elif data.get('type') == 'subscribe_job':
                    job_id = data.get('job_id')
                    # Send current job status if available from Redis
                    job_update = await redis_store.get(f"job:{job_id}")
                    if job_update:
                        await websocket.send_json({
                            'type': 'job_update',
                            'data': job_update
                        })

            except WebSocketDisconnect:
                break
            except Exception as e:
                print(f"WebSocket error: {e}")
                break

    except WebSocketDisconnect:
        pass
    except Exception as e:
        print(f"WebSocket connection error: {e}")
    finally:
        # Clean up connection
        if user_id and user_id in manager.active_connections:
            manager.active_connections[user_id].discard(websocket)
            if not manager.active_connections[user_id]:
                del manager.active_connections[user_id]


async def broadcast_job_update(job_id: str, status: str, progress: int, message: str = None):
    """
    Broadcast job update to all connected clients.
    This should be called from job processing logic.
    """
    update = {
        'type': 'job_update',
        'data': {
            'job_id': job_id,
            'status': status,
            'progress': progress,
            'message': message,
            'timestamp': asyncio.get_event_loop().time()
        }
    }

    # Store update in Redis with TTL
    await redis_store.set(f"job:{job_id}", update['data'], expire=JOB_UPDATE_TTL)

    # Broadcast to all connected clients
    await manager.broadcast(update)


async def send_job_update_to_user(user_id: str, job_id: str, status: str, progress: int, message: str = None):
    """
    Send job update to a specific user.
    """
    update = {
        'type': 'job_update',
        'data': {
            'job_id': job_id,
            'status': status,
            'progress': progress,
            'message': message,
            'timestamp': asyncio.get_event_loop().time()
        }
    }

    # Store update in Redis with TTL
    await redis_store.set(f"job:{job_id}", update['data'], expire=JOB_UPDATE_TTL)

    # Send to specific user
    await manager.send_personal_message(update, user_id)


# Health check endpoint for WebSocket
@router.get("/ws/health")
async def websocket_health():
    """Check WebSocket service health"""
    return {
        "status": "healthy",
        "active_connections": sum(len(conns) for conns in manager.active_connections.values()),
        "active_users": len(manager.active_connections)
    }
