from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional
from ..core.database import get_db
from ..models.user import User, Role, UserStatus
from ..routes.auth import get_current_user, get_password_hash
from pydantic import BaseModel, EmailStr

router = APIRouter()


class UserListResponse(BaseModel):
    id: str
    name: str
    email: str
    role_id: str = None
    status: str

    class Config:
        from_attributes = True


class UserCreate(BaseModel):
    name: str
    email: EmailStr
    password: str
    role_id: str
    title: Optional[str] = None


class UserUpdate(BaseModel):
    name: Optional[str] = None
    email: Optional[EmailStr] = None
    role_id: Optional[str] = None
    title: Optional[str] = None
    password: Optional[str] = None


class UserStatusUpdate(BaseModel):
    status: str


@router.get("/users", response_model=List[UserListResponse])
async def get_users(
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get all users."""
    return db.query(User).all()


@router.post("/users", response_model=UserListResponse)
async def create_user(
    user_data: UserCreate,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Create a new user."""
    # Check if email already exists
    existing = db.query(User).filter(User.email == user_data.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")

    # Hash password
    password_hash = get_password_hash(user_data.password)

    # Create new user
    new_user = User(
        name=user_data.name,
        email=user_data.email,
        password_hash=password_hash,
        role_id=user_data.role_id,
        title=user_data.title,
        status=UserStatus.ACTIVE
    )

    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return new_user


@router.put("/users/{user_id}", response_model=UserListResponse)
async def update_user(
    user_id: str,
    user_data: UserUpdate,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Update a user."""
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    # Update fields if provided
    if user_data.name is not None:
        user.name = user_data.name
    if user_data.email is not None:
        # Check if new email is already taken
        existing = db.query(User).filter(User.email == user_data.email, User.id != user_id).first()
        if existing:
            raise HTTPException(status_code=400, detail="Email already registered")
        user.email = user_data.email
    if user_data.role_id is not None:
        user.role_id = user_data.role_id
    if user_data.title is not None:
        user.title = user_data.title
    if user_data.password is not None:
        user.password_hash = get_password_hash(user_data.password)

    db.commit()
    db.refresh(user)
    return user


@router.patch("/users/{user_id}/status")
async def update_user_status(
    user_id: str,
    status_data: UserStatusUpdate,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Update user status (enable/disable)."""
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    # Don't allow users to disable themselves
    if user.id == current_user.id:
        raise HTTPException(status_code=400, detail="Cannot change your own status")

    user.status = UserStatus(status_data.status)
    db.commit()
    db.refresh(user)
    return {"message": f"User status updated to {status_data.status}"}


@router.delete("/users/{user_id}")
async def delete_user(
    user_id: str,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Delete a user."""
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    # Don't allow users to delete themselves
    if user.id == current_user.id:
        raise HTTPException(status_code=400, detail="Cannot delete yourself")

    # Check if user has created any jobs
    if user.created_jobs:
        raise HTTPException(
            status_code=400,
            detail=f"Cannot delete user. They have created {len(user.created_jobs)} job(s)"
        )

    db.delete(user)
    db.commit()
    return {"message": "User deleted successfully"}


@router.get("/roles")
async def get_roles(
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get all roles."""
    return db.query(Role).all()
