"""
Device Discovery API Routes

Endpoints for PXE boot device registration, auto-assignment, and manual assignment.
"""
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import PlainTextResponse
from sqlalchemy.orm import Session
from typing import List, Optional
from pydantic import BaseModel, Field
from ..core.database import get_db
from ..core.security import get_current_user
from ..models.discovered_device import DiscoveredDevice
from ..models.job import JobDevice, Job, JobStatus, DeviceStatus
from ..services.device_discovery import register_device, manually_assign_device
from ..routes.websocket import broadcast_job_update
from datetime import datetime
import logging

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/devices", tags=["devices"])


# Request/Response Models
class DeviceRegistrationRequest(BaseModel):
    """Request payload for device registration (from PXE boot)"""
    mac_address: str = Field(..., description="MAC address of the device")
    ip_address: str = Field(..., description="IP address assigned via DHCP")
    hostname: Optional[str] = Field(None, description="Device hostname if available")
    manufacturer: Optional[str] = Field(None, description="Manufacturer from MAC OUI lookup")
    model: Optional[str] = Field(None, description="Device model if detectable")


class DeviceRegistrationResponse(BaseModel):
    """Response after device registration"""
    device: dict
    assigned_to_job: Optional[str]
    assignment_status: str  # "auto", "manual_required", "queued", "already_assigned"
    message: str


class ManualAssignmentRequest(BaseModel):
    """Request to manually assign a device to a job"""
    job_id: str = Field(..., description="Job ID to assign device to")


class DiscoveredDeviceResponse(BaseModel):
    """Response model for discovered device"""
    mac_address: str
    hostname: Optional[str]
    ip_address: str
    manufacturer: Optional[str]
    model: Optional[str]
    first_seen: str
    last_seen: str
    times_seen: str
    is_active: bool


# Public endpoint (no auth required) - called by PXE boot scripts
@router.post("/register", response_model=DeviceRegistrationResponse)
async def register_pxe_device(
    request: DeviceRegistrationRequest,
    db = Depends(get_db)
):
    """
    Register a device detected via PXE boot.

    This endpoint is called by the PXE boot environment when a device
    boots from the network. It handles device inventory and auto-assignment.

    **Auto-Assignment Logic:**
    - If exactly 1 job is RUNNING → auto-assign device to that job
    - If multiple jobs are RUNNING → hold for manual assignment
    - If no jobs are RUNNING → hold device, notify admins
    """
    try:
        result = await register_device(
            mac_address=request.mac_address,
            ip_address=request.ip_address,
            hostname=request.hostname,
            manufacturer=request.manufacturer,
            model=request.model,
            db=db
        )

        # Format response
        device_dict = {
            "mac_address": result["device"].mac_address,
            "hostname": result["device"].hostname,
            "ip_address": result["device"].ip_address,
            "manufacturer": result["device"].manufacturer,
            "model": result["device"].model,
            "last_seen": result["device"].last_seen.isoformat() if result["device"].last_seen else None
        }

        # Create appropriate message
        status_messages = {
            "auto": f"Device automatically assigned to job {result['assigned_to_job']}",
            "manual_required": f"Device registered - manual assignment required (multiple jobs running)",
            "queued": "Device registered - no jobs currently running",
            "already_assigned": f"Device already assigned to job {result['assigned_to_job']}"
        }

        return DeviceRegistrationResponse(
            device=device_dict,
            assigned_to_job=result["assigned_to_job"],
            assignment_status=result["assignment_status"],
            message=status_messages[result["assignment_status"]]
        )

    except Exception as e:
        logger.error(f"Error registering device: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to register device: {str(e)}"
        )


@router.post("/{mac_address}/assign")
async def assign_device_to_job(
    mac_address: str,
    request: ManualAssignmentRequest,
    db = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """
    Manually assign an unassigned device to a specific job.

    Used when multiple jobs are running and device couldn't be auto-assigned.
    Requires authentication.
    """
    try:
        job_device = await manually_assign_device(
            mac_address=mac_address,
            job_id=request.job_id,
            db=db
        )

        return {
            "success": True,
            "message": f"Device {mac_address} assigned to job {request.job_id}",
            "device": {
                "id": job_device.id,
                "job_id": job_device.job_id,
                "mac_address": job_device.mac_address,
                "hostname": job_device.hostname,
                "status": job_device.status.value
            }
        }

    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        logger.error(f"Error assigning device {mac_address} to job {request.job_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to assign device: {str(e)}"
        )


@router.get("", response_model=List[DiscoveredDeviceResponse])
async def list_discovered_devices(
    active_only: bool = False,
    db = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """
    List all discovered devices (inventory/history).

    Query Parameters:
    - active_only: If true, only return devices currently active in jobs
    """
    try:
        query = db.query(DiscoveredDevice)

        if active_only:
            query = query.filter(DiscoveredDevice.is_active == True)

        devices = query.order_by(DiscoveredDevice.last_seen.desc()).all()

        return [
            DiscoveredDeviceResponse(
                mac_address=d.mac_address,
                hostname=d.hostname,
                ip_address=d.ip_address,
                manufacturer=d.manufacturer,
                model=d.model,
                first_seen=d.first_seen.isoformat() if d.first_seen else None,
                last_seen=d.last_seen.isoformat() if d.last_seen else None,
                times_seen=d.times_seen,
                is_active=d.is_active
            )
            for d in devices
        ]

    except Exception as e:
        logger.error(f"Error listing devices: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to retrieve devices: {str(e)}"
        )


@router.get("/unassigned")
async def list_unassigned_devices(
    db = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """
    List devices that have been discovered but not yet assigned to a job.

    Returns devices that are in discovered_devices but NOT in job_devices.
    Useful for showing devices waiting for manual assignment.
    """
    try:
        # Get all discovered devices
        discovered = db.query(DiscoveredDevice).all()

        # Get all assigned MAC addresses
        assigned_macs = {jd.mac_address for jd in db.query(JobDevice.mac_address).all()}

        # Filter to unassigned only
        unassigned = [
            {
                "mac_address": d.mac_address,
                "hostname": d.hostname,
                "ip_address": d.ip_address,
                "manufacturer": d.manufacturer,
                "model": d.model,
                "last_seen": d.last_seen.isoformat() if d.last_seen else None
            }
            for d in discovered
            if d.mac_address not in assigned_macs
        ]

        return {
            "count": len(unassigned),
            "devices": unassigned
        }

    except Exception as e:
        logger.error(f"Error listing unassigned devices: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to retrieve unassigned devices: {str(e)}"
        )


@router.delete("/{mac_address}")
async def delete_discovered_device(
    mac_address: str,
    db = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """
    Delete a discovered device from inventory.

    Note: This only removes from discovered_devices table.
    If device is assigned to a job, remove from job first.
    """
    try:
        # Check if device exists
        device = db.query(DiscoveredDevice).filter(
            DiscoveredDevice.mac_address == mac_address
        ).first()

        if not device:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Device {mac_address} not found"
            )

        # Check if device is assigned to a job
        job_assignment = db.query(JobDevice).filter(
            JobDevice.mac_address == mac_address
        ).first()

        if job_assignment:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Device is assigned to job {job_assignment.job_id}. Remove from job first."
            )

        # Delete device
        db.delete(device)
        db.commit()

        logger.info(f"Deleted discovered device: {mac_address}")

        return {
            "success": True,
            "message": f"Device {mac_address} deleted from inventory"
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting device {mac_address}: {e}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete device: {str(e)}"
        )


@router.get("/boot-config/{mac_address}", response_class=PlainTextResponse)
async def get_boot_config(
    mac_address: str,
    db = Depends(get_db)
):
    """
    iPXE boot configuration endpoint.

    Returns iPXE script based on device assignment status:
    - If assigned to a job: Boot into WinPE and start imaging
    - If not assigned: Display waiting screen or local boot

    This endpoint is called by iPXE during network boot.
    No authentication required (called by boot environment).
    """
    try:
        # Normalize MAC address (remove separators, lowercase)
        mac_normalized = mac_address.replace(":", "").replace("-", "").lower()

        # Check if device is assigned to a job
        job_device = db.query(JobDevice).filter(
            JobDevice.mac_address == mac_address
        ).first()

        if not job_device:
            # Device not assigned - show waiting screen or boot locally
            logger.info(f"Boot request from unassigned device: {mac_address}")
            return f"""#!ipxe
# Device {mac_address} - Not Assigned
echo
echo ========================================
echo Issyx Imaging Platform
echo ========================================
echo
echo MAC Address: {mac_address}
echo Status: Waiting for job assignment
echo
echo This device has been detected but not assigned to an imaging job.
echo Please assign this device in the web interface.
echo
echo Press any key to boot from local disk...
prompt --timeout 30000
exit
"""

        # Get job details
        job = db.query(Job).filter(Job.id == job_device.job_id).first()

        if not job:
            logger.error(f"Job {job_device.job_id} not found for device {mac_address}")
            return f"""#!ipxe
echo ERROR: Job not found
echo Please contact administrator
sleep 10
exit
"""

        # Check if job is running
        if job.status != JobStatus.RUNNING:
            logger.warning(f"Device {mac_address} assigned to non-running job {job.id}")
            return f"""#!ipxe
# Device {mac_address} - Job Not Running
echo
echo ========================================
echo Issyx Imaging Platform
echo ========================================
echo
echo MAC Address: {mac_address}
echo Job: {job.id}
echo Status: Job is {job.status.value}
echo
echo This job is not currently running.
echo
echo Press any key to boot from local disk...
prompt --timeout 30000
exit
"""

        # Job is running - boot into WinPE
        # Get API base URL from environment or config
        from ..core.config import settings
        api_base_url = settings.BACKEND_CORS_ORIGINS[0] if settings.BACKEND_CORS_ORIGINS else "http://localhost:8000"

        logger.info(f"Booting device {mac_address} into WinPE for job {job.id}")

        return f"""#!ipxe
# Issyx Imaging Platform - WinPE Boot
# Device: {mac_address}
# Job: {job.id}

echo ========================================
echo Issyx Imaging Platform
echo ========================================
echo
echo MAC Address: {mac_address}
echo Job ID: {job.id}
echo Profile: {job.profile_id}
echo
echo Loading WinPE environment...
echo

# Get DHCP IP address
dhcp

# Download and boot WinPE
echo Downloading WinPE kernel...
kernel {api_base_url}/api/v1/boot/wimboot
echo Downloading WinPE image...
initrd {api_base_url}/api/v1/boot/winpe.wim
echo Booting...
boot
"""

    except Exception as e:
        logger.error(f"Error generating boot config for {mac_address}: {e}")
        return f"""#!ipxe
echo ERROR: Failed to generate boot configuration
echo {str(e)}
sleep 10
exit
"""


@router.get("/{mac_address}/imaging-instructions")
async def get_imaging_instructions(
    mac_address: str,
    db = Depends(get_db)
):
    """
    Get imaging instructions for a device (called by WinPE client).

    Returns:
    - OS information (download URL, version, etc.)
    - Driver list to inject
    - Software packages to install
    - Scripts to execute
    - Computer naming template

    No authentication required (called by WinPE environment).
    """
    try:
        # Get job device
        job_device = db.query(JobDevice).filter(
            JobDevice.mac_address == mac_address
        ).first()

        if not job_device:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Device {mac_address} not assigned to any job"
            )

        # Get job and profile
        job = db.query(Job).filter(Job.id == job_device.job_id).first()

        if not job or not job.profile:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Job or profile not found"
            )

        profile = job.profile

        # Build instructions response
        instructions = {
            "device": {
                "mac_address": mac_address,
                "hostname": job_device.hostname,
                "job_id": job.id
            },
            "profile": {
                "id": profile.id,
                "name": profile.name,
                "driver_mode": profile.driver_mode.value if profile.driver_mode else "smart"
            },
            "os": {
                "id": profile.os_id,
                "name": profile.operating_system.name if profile.operating_system else None,
                "version": profile.operating_system.version if profile.operating_system else None,
                "edition": profile.operating_system.edition if profile.operating_system else None,
                "architecture": profile.operating_system.architecture if profile.operating_system else None,
                "download_url": f"/api/v1/boot/os-images/{profile.os_id}/install.wim"
            },
            "drivers": [],
            "software": [],
            "scripts": [],
            "system_config": profile.system_config or {}
        }

        # Get drivers based on mode
        if profile.driver_mode and profile.driver_mode.value == "smart":
            # Use smart driver matching
            try:
                from ..services.driver_smart_match import DriverSmartMatcher
                matcher = DriverSmartMatcher(db)
                matched_drivers = matcher.get_drivers_for_device(
                    device_mac=mac_address,
                    confidence_threshold="medium"
                )

                instructions["drivers"] = [
                    {
                        "id": d.id,
                        "name": d.name,
                        "version": d.version,
                        "manufacturer": d.manufacturer,
                        "download_url": f"/api/v1/boot/drivers/{d.id}/{d.filename or 'driver.zip'}"
                    }
                    for d in matched_drivers
                ]
            except Exception as e:
                logger.error(f"Smart driver matching failed: {e}")
                instructions["drivers"] = []

        elif profile.driver_profile and profile.driver_profile.drivers:
            # Use profile drivers
            instructions["drivers"] = [
                {
                    "id": d.id,
                    "name": d.name,
                    "version": d.version,
                    "manufacturer": d.manufacturer,
                    "download_url": f"/api/v1/boot/drivers/{d.id}/{d.filename or 'driver.zip'}"
                }
                for d in profile.driver_profile.drivers
            ]

        # Get software packages (ordered by install_order)
        from sqlalchemy import select
        from ..models.master_profile import master_profile_software
        from ..models.software import SoftwareCatalog

        stmt = (
            select(SoftwareCatalog, master_profile_software.c.install_order)
            .join(master_profile_software, SoftwareCatalog.id == master_profile_software.c.software_id)
            .where(master_profile_software.c.profile_id == profile.id)
            .order_by(master_profile_software.c.install_order)
        )

        result = db.execute(stmt).all()
        instructions["software"] = [
            {
                "id": row[0].id,
                "name": row[0].name,
                "version": row[0].version,
                "package_type": row[0].package_type,
                "install_params": row[0].install_params,
                "install_order": row[1],
                "download_url": f"/api/v1/boot/software/{row[0].id}/{row[0].filename or 'package.exe'}"
            }
            for row in result
        ]

        # Get scripts (ordered by execution_order)
        from ..models.master_profile import master_profile_scripts
        from ..models.scripts import ScriptsLibrary

        stmt = (
            select(ScriptsLibrary, master_profile_scripts.c.execution_phase, master_profile_scripts.c.execution_order)
            .join(master_profile_scripts, ScriptsLibrary.id == master_profile_scripts.c.script_id)
            .where(master_profile_scripts.c.profile_id == profile.id)
            .order_by(master_profile_scripts.c.execution_order)
        )

        result = db.execute(stmt).all()
        instructions["scripts"] = [
            {
                "id": row[0].id,
                "name": row[0].name,
                "script_type": row[0].script_type,
                "execution_phase": row[1].value if row[1] else "post",
                "execution_order": row[2],
                "content": row[0].script_content
            }
            for row in result
        ]

        logger.info(
            f"Provided imaging instructions to {mac_address}: "
            f"OS={profile.os_id}, Drivers={len(instructions['drivers'])}, "
            f"Software={len(instructions['software'])}, Scripts={len(instructions['scripts'])}"
        )

        return instructions

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting imaging instructions for {mac_address}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get imaging instructions: {str(e)}"
        )


class DeviceProgressUpdate(BaseModel):
    """Request model for device progress updates from WinPE client"""
    progress: int = Field(..., ge=0, le=100, description="Progress percentage (0-100)")
    current_step: str = Field(..., description="Current step description")
    status: str = Field(default="Running", description="Device status (Running, Succeeded, Failed)")


@router.post("/{mac_address}/progress")
async def update_device_progress(
    mac_address: str,
    update: DeviceProgressUpdate,
    db = Depends(get_db)
):
    """
    Update device progress (called by WinPE client).

    The WinPE client calls this endpoint periodically to report:
    - Current progress percentage
    - Current step being executed
    - Status (Running, Succeeded, Failed)

    No authentication required (called by WinPE environment).
    """
    try:
        # Get job device
        job_device = db.query(JobDevice).filter(
            JobDevice.mac_address == mac_address
        ).first()

        if not job_device:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Device {mac_address} not found"
            )

        # Update device progress
        job_device.progress = update.progress
        job_device.current_step = update.current_step

        # Update status if changed
        if update.status == "Succeeded":
            job_device.status = DeviceStatus.SUCCEEDED
            if not job_device.completed_at:
                job_device.completed_at = datetime.now()
        elif update.status == "Failed":
            job_device.status = DeviceStatus.FAILED
            if not job_device.completed_at:
                job_device.completed_at = datetime.now()
        elif update.status == "Running":
            job_device.status = DeviceStatus.RUNNING
            if not job_device.started_at:
                job_device.started_at = datetime.now()

        db.commit()

        # Broadcast progress update via WebSocket
        job = db.query(Job).filter(Job.id == job_device.job_id).first()
        if job:
            await broadcast_job_update(
                job_id=job.id,
                status=job.status.value,
                progress=job_device.progress,
                message=f"Device {job_device.hostname or mac_address}: {update.current_step}"
            )

        logger.info(
            f"Progress update from {mac_address}: {update.progress}% - {update.current_step} ({update.status})"
        )

        return {
            "success": True,
            "message": "Progress updated",
            "device": {
                "mac_address": mac_address,
                "progress": job_device.progress,
                "current_step": job_device.current_step,
                "status": job_device.status.value
            }
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating progress for {mac_address}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update progress: {str(e)}"
        )
