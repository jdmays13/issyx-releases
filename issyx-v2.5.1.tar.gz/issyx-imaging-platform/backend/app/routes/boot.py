"""
Boot File Serving API Routes

Endpoints for serving iPXE boot files, WinPE images, and OS installation files.
"""
from fastapi import APIRouter, HTTPException, status
from fastapi.responses import FileResponse, StreamingResponse, Response
from pathlib import Path
import logging
import os

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/boot", tags=["boot"])

# Boot files directory - configurable via environment
BOOT_FILES_DIR = Path(os.getenv("BOOT_FILES_DIR", "C:/IssyxImaging/BootFiles"))
WINPE_DIR = BOOT_FILES_DIR / "winpe"
OS_IMAGES_DIR = Path(os.getenv("OS_IMAGES_DIR", "C:/IssyxImaging/OSImages"))


@router.get("/wimboot")
async def get_wimboot():
    """
    Serve wimboot bootloader for iPXE.

    wimboot is a tiny bootloader that can boot Windows PE from iPXE.
    Download from: https://git.ipxe.org/releases/wimboot/wimboot-latest.zip
    """
    wimboot_path = BOOT_FILES_DIR / "wimboot"

    if not wimboot_path.exists():
        logger.error(f"wimboot not found at {wimboot_path}")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"wimboot not found. Please download from https://git.ipxe.org/releases/wimboot/ and place at {wimboot_path}"
        )

    return FileResponse(
        wimboot_path,
        media_type="application/octet-stream",
        filename="wimboot"
    )


@router.get("/winpe.wim")
async def get_winpe_wim():
    """
    Serve WinPE WIM image for network boot.

    This should be a custom WinPE image created with Windows ADK that includes:
    - PowerShell client script
    - Network drivers
    - DISM tools
    """
    winpe_path = WINPE_DIR / "boot.wim"

    if not winpe_path.exists():
        logger.error(f"WinPE image not found at {winpe_path}")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"WinPE image not found at {winpe_path}. Please create a custom WinPE image using Windows ADK."
        )

    # Stream large WIM files in chunks
    def iterfile():
        with open(winpe_path, mode="rb") as file_like:
            yield from file_like

    return StreamingResponse(
        iterfile(),
        media_type="application/octet-stream",
        headers={
            "Content-Disposition": f"attachment; filename=winpe.wim",
            "Content-Length": str(winpe_path.stat().st_size)
        }
    )


@router.get("/bcd")
async def get_bcd():
    """
    Serve Boot Configuration Data (BCD) file for WinPE.

    This is generated when creating WinPE with Windows ADK.
    """
    bcd_path = WINPE_DIR / "BCD"

    if not bcd_path.exists():
        logger.error(f"BCD file not found at {bcd_path}")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"BCD file not found at {bcd_path}"
        )

    return FileResponse(
        bcd_path,
        media_type="application/octet-stream",
        filename="BCD"
    )


@router.get("/boot.sdi")
async def get_boot_sdi():
    """
    Serve boot.sdi file required for WinPE boot.

    This is found in Windows ADK or existing WinPE media.
    """
    sdi_path = WINPE_DIR / "boot.sdi"

    if not sdi_path.exists():
        logger.error(f"boot.sdi not found at {sdi_path}")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"boot.sdi not found at {sdi_path}"
        )

    return FileResponse(
        sdi_path,
        media_type="application/octet-stream",
        filename="boot.sdi"
    )


@router.get("/os-images/{os_id}/{filename}")
async def get_os_image(os_id: str, filename: str):
    """
    Serve OS installation WIM files to WinPE clients.

    Path structure: /OS_IMAGES_DIR/{os_id}/{filename}
    Example: /api/v1/boot/os-images/OS-001/install.wim

    Security: Validate filename to prevent directory traversal.
    """
    # Validate filename (prevent directory traversal)
    if ".." in filename or "/" in filename or "\\" in filename:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid filename"
        )

    os_image_path = OS_IMAGES_DIR / os_id / filename

    if not os_image_path.exists():
        logger.error(f"OS image not found: {os_image_path}")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"OS image not found: {os_id}/{filename}"
        )

    # Check if file is within allowed directory (security)
    try:
        os_image_path.resolve().relative_to(OS_IMAGES_DIR.resolve())
    except ValueError:
        logger.error(f"Path traversal attempt: {os_image_path}")
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied"
        )

    # Stream large WIM files
    def iterfile():
        with open(os_image_path, mode="rb") as file_like:
            # Stream in 10MB chunks
            chunk_size = 10 * 1024 * 1024
            while True:
                chunk = file_like.read(chunk_size)
                if not chunk:
                    break
                yield chunk

    return StreamingResponse(
        iterfile(),
        media_type="application/octet-stream",
        headers={
            "Content-Disposition": f"attachment; filename={filename}",
            "Content-Length": str(os_image_path.stat().st_size)
        }
    )


@router.get("/drivers/{driver_id}/{filename}")
async def get_driver_package(driver_id: str, filename: str):
    """
    Serve driver packages to WinPE clients for injection.

    Path structure: /DRIVERS_DIR/{driver_id}/{filename}
    """
    # Validate filename
    if ".." in filename or "/" in filename or "\\" in filename:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid filename"
        )

    drivers_dir = Path(os.getenv("DRIVERS_DIR", "C:/IssyxImaging/Drivers"))
    driver_path = drivers_dir / driver_id / filename

    if not driver_path.exists():
        logger.error(f"Driver package not found: {driver_path}")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Driver package not found: {driver_id}/{filename}"
        )

    # Security check
    try:
        driver_path.resolve().relative_to(drivers_dir.resolve())
    except ValueError:
        logger.error(f"Path traversal attempt: {driver_path}")
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied"
        )

    return FileResponse(
        driver_path,
        media_type="application/octet-stream",
        filename=filename
    )


@router.get("/software/{software_id}/{filename}")
async def get_software_package(software_id: str, filename: str):
    """
    Serve software installation packages to WinPE clients.

    Path structure: /SOFTWARE_DIR/{software_id}/{filename}
    """
    # Validate filename
    if ".." in filename or "/" in filename or "\\" in filename:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid filename"
        )

    software_dir = Path(os.getenv("SOFTWARE_DIR", "C:/IssyxImaging/Software"))
    software_path = software_dir / software_id / filename

    if not software_path.exists():
        logger.error(f"Software package not found: {software_path}")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Software package not found: {software_id}/{filename}"
        )

    # Security check
    try:
        software_path.resolve().relative_to(software_dir.resolve())
    except ValueError:
        logger.error(f"Path traversal attempt: {software_path}")
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied"
        )

    def iterfile():
        with open(software_path, mode="rb") as file_like:
            chunk_size = 5 * 1024 * 1024  # 5MB chunks
            while True:
                chunk = file_like.read(chunk_size)
                if not chunk:
                    break
                yield chunk

    return StreamingResponse(
        iterfile(),
        media_type="application/octet-stream",
        headers={
            "Content-Disposition": f"attachment; filename={filename}",
            "Content-Length": str(software_path.stat().st_size)
        }
    )


@router.get("/winpe-client.ps1")
async def get_winpe_client():
    """
    Serve the WinPE PowerShell client script.

    This script is downloaded by WinPE during boot and executes the imaging process.
    It communicates with the Issyx API to get instructions and report progress.
    """
    # Client script is in backend/resources/
    client_path = Path(__file__).parent.parent.parent / "resources" / "winpe-client.ps1"

    if not client_path.exists():
        logger.error(f"WinPE client script not found at {client_path}")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="WinPE client script not found"
        )

    return FileResponse(
        client_path,
        media_type="text/plain",
        filename="winpe-client.ps1",
        headers={
            "Content-Type": "text/plain; charset=utf-8"
        }
    )


@router.get("/startnet.cmd")
async def get_startnet_cmd():
    """
    Serve the WinPE startup script.

    This script runs when WinPE boots and downloads/executes the PowerShell client.
    It's customized to point to the correct API server.
    """
    # Generate dynamic startnet.cmd based on system settings
    # For now, return a template that WinPE will use

    startnet_content = """@echo off
echo ==========================================
echo Issyx Imaging Platform - WinPE Client
echo ==========================================
echo.

REM Initialize network
wpeinit

REM Wait for network to be ready
echo Waiting for network...
ping -n 5 127.0.0.1 > nul

REM Get API server from DHCP (next-server option)
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /i "Default Gateway"') do set GATEWAY=%%a
set GATEWAY=%GATEWAY: =%

REM Download PowerShell client
echo Downloading imaging client from server...
powershell -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'http://%GATEWAY%:8000/api/v1/boot/winpe-client.ps1' -OutFile 'X:\\client.ps1'"

REM Run the client - it will auto-detect API and job assignment
echo Starting imaging process...
powershell -ExecutionPolicy Bypass -File X:\\client.ps1

echo.
echo Imaging process complete.
pause
"""

    return Response(
        content=startnet_content,
        media_type="text/plain",
        headers={
            "Content-Disposition": "attachment; filename=startnet.cmd"
        }
    )


@router.get("/health")
async def boot_health_check():
    """
    Health check endpoint to verify boot file directories exist.
    """
    checks = {
        "boot_files_dir": BOOT_FILES_DIR.exists(),
        "winpe_dir": WINPE_DIR.exists(),
        "os_images_dir": OS_IMAGES_DIR.exists(),
        "wimboot_exists": (BOOT_FILES_DIR / "wimboot").exists(),
        "winpe_wim_exists": (WINPE_DIR / "boot.wim").exists(),
    }

    all_healthy = all(checks.values())

    return {
        "status": "healthy" if all_healthy else "degraded",
        "checks": checks,
        "directories": {
            "boot_files": str(BOOT_FILES_DIR),
            "winpe": str(WINPE_DIR),
            "os_images": str(OS_IMAGES_DIR),
        }
    }
