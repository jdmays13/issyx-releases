"""
Bulk Operations API Routes

Endpoints for performing bulk actions on jobs, devices, drivers, software, and other resources.
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
from pydantic import BaseModel
from ..core.database import get_db
from ..core.security import get_current_user
from ..models.job import Job, JobDevice, JobStatus, DeviceStatus
from ..models.driver import Driver
from ..models.software import Software
from ..models.script import Script
from ..models.discovered_device import DiscoveredDevice
from ..models.notification import NotificationEvent
from ..services.notification import NotificationService
import logging

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/bulk", tags=["bulk-operations"])


# Request Models
class BulkJobActionRequest(BaseModel):
    """Request to perform bulk action on jobs"""
    job_ids: List[str]
    action: str  # "delete", "cancel", "restart", "export"


class BulkDeviceActionRequest(BaseModel):
    """Request to perform bulk action on devices"""
    device_macs: List[str]
    action: str  # "delete", "deactivate", "assign_to_job"
    job_id: Optional[str] = None  # Required for "assign_to_job"


class BulkResourceActionRequest(BaseModel):
    """Request to perform bulk action on resources (drivers, software, scripts)"""
    resource_ids: List[str]
    action: str  # "delete", "activate", "deactivate"
    resource_type: str  # "driver", "software", "script"


class BulkAssignDevicesRequest(BaseModel):
    """Request to bulk assign devices to a job"""
    device_macs: List[str]
    job_id: str


# Job Bulk Operations
@router.post("/jobs")
async def bulk_job_action(
    request: BulkJobActionRequest,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Perform bulk action on multiple jobs.

    Supported actions:
    - delete: Delete jobs (only if in QUEUED, SUCCEEDED, or FAILED status)
    - cancel: Cancel running jobs
    - restart: Restart failed jobs
    - export: Export job data (returns job summaries)
    """
    try:
        if not request.job_ids:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No job IDs provided"
            )

        jobs = db.query(Job).filter(Job.id.in_(request.job_ids)).all()

        if not jobs:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="No jobs found with provided IDs"
            )

        results = {
            "action": request.action,
            "total_requested": len(request.job_ids),
            "processed": 0,
            "failed": 0,
            "errors": []
        }

        if request.action == "delete":
            # Delete jobs (only if in terminal state)
            for job in jobs:
                if job.status not in [JobStatus.QUEUED, JobStatus.SUCCEEDED, JobStatus.FAILED]:
                    results["errors"].append(f"Job {job.id} cannot be deleted (status: {job.status.value})")
                    results["failed"] += 1
                    continue

                try:
                    # Delete associated job devices
                    db.query(JobDevice).filter(JobDevice.job_id == job.id).delete()
                    db.delete(job)
                    results["processed"] += 1
                except Exception as e:
                    logger.error(f"Failed to delete job {job.id}: {e}")
                    results["errors"].append(f"Job {job.id}: {str(e)}")
                    results["failed"] += 1

            db.commit()

        elif request.action == "cancel":
            # Cancel running jobs
            for job in jobs:
                if job.status != JobStatus.RUNNING:
                    results["errors"].append(f"Job {job.id} is not running (status: {job.status.value})")
                    results["failed"] += 1
                    continue

                try:
                    job.status = JobStatus.CANCELLED
                    # Mark all running/queued devices as cancelled
                    db.query(JobDevice).filter(
                        JobDevice.job_id == job.id,
                        JobDevice.status.in_([DeviceStatus.RUNNING, DeviceStatus.QUEUED])
                    ).update({
                        "status": DeviceStatus.FAILED,
                        "error_message": "Job cancelled by user"
                    })
                    results["processed"] += 1
                except Exception as e:
                    logger.error(f"Failed to cancel job {job.id}: {e}")
                    results["errors"].append(f"Job {job.id}: {str(e)}")
                    results["failed"] += 1

            db.commit()

        elif request.action == "restart":
            # Restart failed jobs
            for job in jobs:
                if job.status != JobStatus.FAILED:
                    results["errors"].append(f"Job {job.id} is not failed (status: {job.status.value})")
                    results["failed"] += 1
                    continue

                try:
                    job.status = JobStatus.RUNNING
                    # Reset failed devices to queued
                    db.query(JobDevice).filter(
                        JobDevice.job_id == job.id,
                        JobDevice.status == DeviceStatus.FAILED
                    ).update({
                        "status": DeviceStatus.QUEUED,
                        "retries": 0,
                        "error_message": None
                    })
                    results["processed"] += 1
                except Exception as e:
                    logger.error(f"Failed to restart job {job.id}: {e}")
                    results["errors"].append(f"Job {job.id}: {str(e)}")
                    results["failed"] += 1

            db.commit()

        elif request.action == "export":
            # Export job data
            results["data"] = [
                {
                    "id": job.id,
                    "name": job.name,
                    "status": job.status.value,
                    "customer_id": job.customer_id,
                    "total_devices": job.total_devices,
                    "succeeded": job.succeeded,
                    "failed": job.failed,
                    "created_at": job.created_at.isoformat() if job.created_at else None
                }
                for job in jobs
            ]
            results["processed"] = len(jobs)

        else:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Unknown action: {request.action}"
            )

        logger.info(
            f"Bulk job action '{request.action}' by user {current_user.id}: "
            f"{results['processed']} processed, {results['failed']} failed"
        )

        return results

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Bulk job action failed: {e}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Bulk operation failed: {str(e)}"
        )


# Device Bulk Operations
@router.post("/devices")
async def bulk_device_action(
    request: BulkDeviceActionRequest,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Perform bulk action on multiple devices.

    Supported actions:
    - delete: Delete discovered devices
    - deactivate: Mark devices as inactive
    - assign_to_job: Assign devices to a job
    """
    try:
        if not request.device_macs:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No device MAC addresses provided"
            )

        devices = db.query(DiscoveredDevice).filter(
            DiscoveredDevice.mac_address.in_(request.device_macs)
        ).all()

        if not devices:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="No devices found with provided MAC addresses"
            )

        results = {
            "action": request.action,
            "total_requested": len(request.device_macs),
            "processed": 0,
            "failed": 0,
            "errors": []
        }

        if request.action == "delete":
            # Delete devices
            for device in devices:
                try:
                    db.delete(device)
                    results["processed"] += 1
                except Exception as e:
                    logger.error(f"Failed to delete device {device.mac_address}: {e}")
                    results["errors"].append(f"Device {device.mac_address}: {str(e)}")
                    results["failed"] += 1

            db.commit()

        elif request.action == "deactivate":
            # Deactivate devices
            for device in devices:
                try:
                    device.is_active = False
                    results["processed"] += 1
                except Exception as e:
                    logger.error(f"Failed to deactivate device {device.mac_address}: {e}")
                    results["errors"].append(f"Device {device.mac_address}: {str(e)}")
                    results["failed"] += 1

            db.commit()

        elif request.action == "assign_to_job":
            # Assign devices to job
            if not request.job_id:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="job_id is required for assign_to_job action"
                )

            job = db.query(Job).filter(Job.id == request.job_id).first()
            if not job:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Job {request.job_id} not found"
                )

            if job.status not in [JobStatus.QUEUED, JobStatus.RUNNING]:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Job {request.job_id} is not in a valid state for device assignment"
                )

            from ..services.device_discovery import manually_assign_device

            for device in devices:
                try:
                    await manually_assign_device(
                        mac_address=device.mac_address,
                        job_id=request.job_id,
                        db=db
                    )
                    results["processed"] += 1
                except Exception as e:
                    logger.error(f"Failed to assign device {device.mac_address}: {e}")
                    results["errors"].append(f"Device {device.mac_address}: {str(e)}")
                    results["failed"] += 1

        else:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Unknown action: {request.action}"
            )

        logger.info(
            f"Bulk device action '{request.action}' by user {current_user.id}: "
            f"{results['processed']} processed, {results['failed']} failed"
        )

        return results

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Bulk device action failed: {e}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Bulk operation failed: {str(e)}"
        )


# Resource Bulk Operations (Drivers, Software, Scripts)
@router.post("/resources")
async def bulk_resource_action(
    request: BulkResourceActionRequest,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Perform bulk action on resources (drivers, software, scripts).

    Supported actions:
    - delete: Delete resources
    - activate: Mark resources as active
    - deactivate: Mark resources as inactive
    """
    try:
        if not request.resource_ids:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No resource IDs provided"
            )

        # Get model based on resource type
        model_map = {
            "driver": Driver,
            "software": Software,
            "script": Script
        }

        model = model_map.get(request.resource_type)
        if not model:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Unknown resource type: {request.resource_type}"
            )

        resources = db.query(model).filter(model.id.in_(request.resource_ids)).all()

        if not resources:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"No {request.resource_type}s found with provided IDs"
            )

        results = {
            "action": request.action,
            "resource_type": request.resource_type,
            "total_requested": len(request.resource_ids),
            "processed": 0,
            "failed": 0,
            "errors": []
        }

        if request.action == "delete":
            # Delete resources
            for resource in resources:
                try:
                    db.delete(resource)
                    results["processed"] += 1
                except Exception as e:
                    logger.error(f"Failed to delete {request.resource_type} {resource.id}: {e}")
                    results["errors"].append(f"{request.resource_type} {resource.id}: {str(e)}")
                    results["failed"] += 1

            db.commit()

        elif request.action in ["activate", "deactivate"]:
            # Toggle active status
            is_active = (request.action == "activate")

            for resource in resources:
                try:
                    if hasattr(resource, 'is_active'):
                        resource.is_active = is_active
                        results["processed"] += 1
                    else:
                        results["errors"].append(
                            f"{request.resource_type} {resource.id} does not support active/inactive status"
                        )
                        results["failed"] += 1
                except Exception as e:
                    logger.error(f"Failed to {request.action} {request.resource_type} {resource.id}: {e}")
                    results["errors"].append(f"{request.resource_type} {resource.id}: {str(e)}")
                    results["failed"] += 1

            db.commit()

        else:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Unknown action: {request.action}"
            )

        logger.info(
            f"Bulk {request.resource_type} action '{request.action}' by user {current_user.id}: "
            f"{results['processed']} processed, {results['failed']} failed"
        )

        return results

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Bulk resource action failed: {e}")
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Bulk operation failed: {str(e)}"
        )


# Convenience endpoint for bulk device assignment
@router.post("/devices/assign")
async def bulk_assign_devices(
    request: BulkAssignDevicesRequest,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """
    Bulk assign discovered devices to a job.

    This is a convenience endpoint for the common operation of assigning
    multiple unassigned devices to a job.
    """
    return await bulk_device_action(
        BulkDeviceActionRequest(
            device_macs=request.device_macs,
            action="assign_to_job",
            job_id=request.job_id
        ),
        db=db,
        current_user=current_user
    )
