from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel, EmailStr
from typing import Optional
from ..core.database import get_db
from ..core.security import get_password_hash
from ..models.user import User, UserStatus
from ..models.system_settings import SystemSettings

router = APIRouter()


class SetupStatusResponse(BaseModel):
    is_setup_complete: bool
    has_admin_user: bool
    has_system_settings: bool


class SetupRequest(BaseModel):
    # Server Configuration
    serverName: str
    serverDescription: Optional[str] = ""

    # Storage Configuration
    imageStorage: str
    driverStorage: str
    softwareStorage: Optional[str] = ""
    backupStorage: Optional[str] = ""

    # DHCP Configuration (new simplified format)
    useExternalDhcp: bool = True  # True = use existing DHCP server, False = built-in (future)

    # Legacy Network Configuration (kept for backwards compatibility)
    serverIP: Optional[str] = None
    pxeSubnet: Optional[str] = ""
    dhcpRangeStart: Optional[str] = ""
    dhcpRangeEnd: Optional[str] = ""

    # Admin User
    adminEmail: EmailStr
    adminPassword: str
    adminPasswordConfirm: str
    adminFullName: Optional[str] = ""


class SetupResponse(BaseModel):
    success: bool
    message: str


@router.get("/setup/status", response_model=SetupStatusResponse)
async def get_setup_status(db: Session = Depends(get_db)):
    """
    Check if initial setup has been completed.
    Setup is complete if:
    1. At least one admin user exists
    2. System settings have been configured (PXE server IP is set)
    """
    # Check for admin users
    admin_count = db.query(User).join(User.role).filter(
        User.role.has(name="Admin")
    ).count()

    has_admin = admin_count > 0

    # Check system settings
    settings = db.query(SystemSettings).first()
    has_settings = settings is not None and bool(settings.pxe_server_ip)

    # Setup is complete if both conditions are met
    is_complete = has_admin and has_settings

    return SetupStatusResponse(
        is_setup_complete=is_complete,
        has_admin_user=has_admin,
        has_system_settings=has_settings
    )


def get_server_ip():
    """Auto-detect the server's IP address"""
    import socket
    try:
        # Create a socket to determine the outbound IP
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


@router.post("/setup", response_model=SetupResponse)
async def complete_setup(setup_data: SetupRequest, db: Session = Depends(get_db)):
    """
    Complete initial setup:
    1. Create admin user
    2. Configure system settings
    """
    # Verify passwords match
    if setup_data.adminPassword != setup_data.adminPasswordConfirm:
        raise HTTPException(status_code=400, detail="Passwords do not match")

    # Check if admin already exists
    existing_admin = db.query(User).join(User.role).filter(
        User.role.has(name="Admin")
    ).first()

    if existing_admin:
        raise HTTPException(
            status_code=400,
            detail="Setup has already been completed. An admin user already exists."
        )

    # Check if email is already in use
    existing_email = db.query(User).filter(User.email == setup_data.adminEmail).first()
    if existing_email:
        raise HTTPException(status_code=400, detail="Email already in use")

    try:
        # 1. Create admin user
        # Get Admin role ID
        from ..models.user import Role
        admin_role = db.query(Role).filter(Role.name == "Admin").first()

        if not admin_role:
            raise HTTPException(
                status_code=500,
                detail="Admin role not found. Please run database initialization first."
            )

        # Generate user ID
        user_count = db.query(User).count()
        user_id = f"U-{str(user_count + 1).zfill(3)}"

        # Create admin user
        admin_user = User(
            id=user_id,
            name=setup_data.adminFullName or setup_data.adminEmail.split("@")[0],
            email=setup_data.adminEmail,
            password_hash=get_password_hash(setup_data.adminPassword),
            role_id=admin_role.id,
            title="System Administrator",
            status=UserStatus.ACTIVE
        )

        db.add(admin_user)

        # 2. Update system settings
        settings = db.query(SystemSettings).first()

        if not settings:
            # Create settings if they don't exist
            settings = SystemSettings(id=1)
            db.add(settings)

        # Update PXE server IP - auto-detect if not provided
        if setup_data.serverIP:
            settings.pxe_server_ip = setup_data.serverIP
            settings.use_custom_pxe_ip = True
        else:
            # Auto-detect server IP
            settings.pxe_server_ip = get_server_ip()
            settings.use_custom_pxe_ip = False

        # Store DHCP configuration preference
        # useExternalDhcp = True means user will configure their own DHCP server
        # This is stored for reference but doesn't change server behavior (yet)

        db.commit()

        return SetupResponse(
            success=True,
            message=f"Setup completed successfully. Admin user '{setup_data.adminEmail}' created."
        )

    except HTTPException:
        db.rollback()
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Setup failed: {str(e)}")
