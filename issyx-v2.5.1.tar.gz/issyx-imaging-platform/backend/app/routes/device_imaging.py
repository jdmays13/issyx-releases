"""
Device Imaging API Endpoints

Provides endpoints for WinPE devices to:
1. Get imaging instructions (next step)
2. Report progress updates
3. Upload logs and completion status

These endpoints are called by the PowerShell client running in WinPE.
"""
from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session
from typing import Optional
from datetime import datetime
from pydantic import BaseModel
from ..core.database import get_db
from ..models.job import Job, JobDevice, DeviceStatus, JobStatus
from ..services.imaging_instructions import DeviceInstructionGenerator
from ..routes.websocket import broadcast_job_update
import logging

logger = logging.getLogger(__name__)

router = APIRouter()


class DeviceProgressUpdate(BaseModel):
    """Progress update from device"""
    progress: int  # 0-100
    current_step: str
    status: Optional[str] = None  # running, succeeded, failed
    log_output: Optional[str] = None
    error_message: Optional[str] = None


class DeviceCompletionReport(BaseModel):
    """Final completion report from device"""
    status: str  # succeeded or failed
    total_time_seconds: int
    log: Optional[str] = None
    error_message: Optional[str] = None


@router.get("/jobs/{job_id}/devices/{mac_address}/instructions")
async def get_device_instructions(
    job_id: str,
    mac_address: str,
    request: Request,
    db: Session = Depends(get_db)
):
    """
    Get next imaging instructions for a device.

    Called by WinPE PowerShell client to get the next step to execute.

    Args:
        job_id: Job ID (e.g., "JOB-1042")
        mac_address: Device MAC address (e.g., "00:11:22:33:44:55")

    Returns:
        Instruction dict with step info and actions to execute,
        or {"complete": true} if imaging is done.

    Example response:
    {
        "step": 2,
        "step_name": "Deploy OS",
        "progress_start": 5,
        "progress_end": 30,
        "actions": [
            {
                "type": "download",
                "url": "http://api:8000/api/v1/boot/os-images/OS-001/install.wim",
                "destination": "X:\\install.wim",
                "timeout_seconds": 1800
            },
            {
                "type": "dism_apply_image",
                "image_file": "X:\\install.wim",
                "target_drive": "C:\\",
                "timeout_seconds": 1800
            }
        ]
    }
    """
    # Find the job
    job = db.query(Job).filter(Job.id == job_id).first()
    if not job:
        raise HTTPException(status_code=404, detail=f"Job {job_id} not found")

    # Find the device
    device = db.query(JobDevice).filter(
        JobDevice.job_id == job_id,
        JobDevice.mac_address == mac_address
    ).first()

    if not device:
        raise HTTPException(
            status_code=404,
            detail=f"Device {mac_address} not found in job {job_id}"
        )

    # Generate API base URL from request
    # e.g., "http://10.0.0.1:8000"
    api_base_url = f"{request.url.scheme}://{request.url.netloc}"

    # Generate next instruction
    instruction_generator = DeviceInstructionGenerator(db)

    try:
        next_instruction = instruction_generator.generate_next_instruction(
            job=job,
            device=device,
            api_base_url=api_base_url
        )

        if next_instruction is None:
            # Imaging complete
            return {"complete": True}

        return next_instruction

    except Exception as e:
        logger.error(f"Error generating instructions for device {mac_address}: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Error generating instructions: {str(e)}"
        )


@router.post("/jobs/{job_id}/devices/{mac_address}/progress")
async def update_device_progress(
    job_id: str,
    mac_address: str,
    progress_update: DeviceProgressUpdate,
    db: Session = Depends(get_db)
):
    """
    Update device imaging progress.

    Called by WinPE PowerShell client every 5-10 seconds to report progress.

    Args:
        job_id: Job ID
        mac_address: Device MAC address
        progress_update: Progress update data

    Returns:
        Success message
    """
    # Find the device
    device = db.query(JobDevice).filter(
        JobDevice.job_id == job_id,
        JobDevice.mac_address == mac_address
    ).first()

    if not device:
        raise HTTPException(
            status_code=404,
            detail=f"Device {mac_address} not found in job {job_id}"
        )

    # Update device progress
    device.progress = progress_update.progress
    device.current_step = progress_update.current_step

    if progress_update.status:
        try:
            device.status = DeviceStatus(progress_update.status.title())
        except ValueError:
            logger.warning(f"Invalid status value: {progress_update.status}")

    if progress_update.error_message:
        device.error_message = progress_update.error_message

    # Append log output if provided
    if progress_update.log_output:
        if device.logs:
            device.logs += f"\n{progress_update.log_output}"
        else:
            device.logs = progress_update.log_output

    # If device just started, set started_at
    if device.status == DeviceStatus.RUNNING and not device.started_at:
        device.started_at = datetime.now()

        # Update job counters
        job = db.query(Job).filter(Job.id == job_id).first()
        if job:
            job.in_progress += 1

    db.commit()
    db.refresh(device)

    # Broadcast update via WebSocket
    job = db.query(Job).filter(Job.id == job_id).first()
    if job:
        await broadcast_job_update(
            job_id=job.id,
            status=job.status.value,
            progress=_calculate_job_progress(job),
            message=f"Device {device.hostname or device.mac_address}: {device.current_step}"
        )

    return {
        "message": "Progress updated successfully",
        "device_progress": device.progress,
        "current_step": device.current_step
    }


@router.post("/jobs/{job_id}/devices/{mac_address}/complete")
async def mark_device_complete(
    job_id: str,
    mac_address: str,
    completion_report: DeviceCompletionReport,
    db: Session = Depends(get_db)
):
    """
    Mark device imaging as complete.

    Called by WinPE PowerShell client when imaging finishes (success or failure).

    Args:
        job_id: Job ID
        mac_address: Device MAC address
        completion_report: Final completion data

    Returns:
        Success message
    """
    # Find the device
    device = db.query(JobDevice).filter(
        JobDevice.job_id == job_id,
        JobDevice.mac_address == mac_address
    ).first()

    if not device:
        raise HTTPException(
            status_code=404,
            detail=f"Device {mac_address} not found in job {job_id}"
        )

    # Update device status
    try:
        device.status = DeviceStatus(completion_report.status.title())
    except ValueError:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid status: {completion_report.status}"
        )

    device.completed_at = datetime.now()
    device.progress = 100 if device.status == DeviceStatus.SUCCEEDED else device.progress

    # Calculate duration
    if device.started_at:
        duration_seconds = (device.completed_at - device.started_at).total_seconds()
        hours = int(duration_seconds // 3600)
        minutes = int((duration_seconds % 3600) // 60)
        seconds = int(duration_seconds % 60)
        device.duration = f"{hours:02d}:{minutes:02d}:{seconds:02d}"
    else:
        device.duration = "00:00:00"

    # Set final logs
    if completion_report.log:
        device.logs = completion_report.log

    # Set error message if failed
    if completion_report.error_message:
        device.error_message = completion_report.error_message

    # Update job counters
    job = db.query(Job).filter(Job.id == job_id).first()
    if not job:
        raise HTTPException(status_code=404, detail=f"Job {job_id} not found")

    # Decrement in_progress
    if job.in_progress > 0:
        job.in_progress -= 1

    # Increment succeeded or failed
    if device.status == DeviceStatus.SUCCEEDED:
        job.succeeded += 1
        device.current_step = "Imaging completed successfully"
    elif device.status == DeviceStatus.FAILED:
        job.failed += 1
        device.current_step = f"Imaging failed: {device.error_message or 'Unknown error'}"

    # Check if job is complete
    total_completed = job.succeeded + job.failed
    if total_completed >= job.total_devices:
        # Job is complete
        if job.failed > 0:
            job.status = JobStatus.FAILED
        else:
            job.status = JobStatus.SUCCEEDED

        job.completed_at = datetime.now()

    db.commit()
    db.refresh(device)
    db.refresh(job)

    # Broadcast completion via WebSocket
    await broadcast_job_update(
        job_id=job.id,
        status=job.status.value,
        progress=_calculate_job_progress(job),
        message=f"Device {device.hostname or device.mac_address} imaging {device.status.value.lower()}"
    )

    return {
        "message": f"Device marked as {device.status.value}",
        "device_status": device.status.value,
        "job_status": job.status.value,
        "job_progress": _calculate_job_progress(job)
    }


@router.get("/jobs/{job_id}/devices/{mac_address}/status")
async def get_device_status(
    job_id: str,
    mac_address: str,
    db: Session = Depends(get_db)
):
    """
    Get current device status.

    Useful for device to check if job has been cancelled, etc.

    Returns:
        Device status information
    """
    device = db.query(JobDevice).filter(
        JobDevice.job_id == job_id,
        JobDevice.mac_address == mac_address
    ).first()

    if not device:
        raise HTTPException(
            status_code=404,
            detail=f"Device {mac_address} not found in job {job_id}"
        )

    job = db.query(Job).filter(Job.id == job_id).first()
    if not job:
        raise HTTPException(status_code=404, detail=f"Job {job_id} not found")

    return {
        "device_status": device.status.value,
        "device_progress": device.progress,
        "current_step": device.current_step,
        "job_status": job.status.value,
        "should_continue": job.status in [JobStatus.RUNNING, JobStatus.QUEUED]
    }


def _calculate_job_progress(job: Job) -> int:
    """Calculate overall job progress percentage"""
    if job.total_devices == 0:
        return 0

    # Get all devices for this job
    total_progress = 0
    devices = job.devices

    for device in devices:
        total_progress += (device.progress or 0)

    return int(total_progress / job.total_devices)
