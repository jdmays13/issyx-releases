from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional
from ..core.database import get_db
from ..models.script import ScriptsLibrary
from ..routes.auth import get_current_user
from pydantic import BaseModel
import uuid

router = APIRouter()


class ScriptResponse(BaseModel):
    id: str
    name: str
    type: str
    category: str
    description: Optional[str] = None
    file_path: Optional[str] = None
    file_size: Optional[int] = None

    class Config:
        from_attributes = True


class ScriptCreate(BaseModel):
    name: str
    type: str
    category: str
    description: Optional[str] = None
    content: Optional[str] = None


class ScriptUpdate(BaseModel):
    name: Optional[str] = None
    type: Optional[str] = None
    category: Optional[str] = None
    description: Optional[str] = None
    content: Optional[str] = None


class ScriptDetailResponse(BaseModel):
    id: str
    name: str
    type: str
    category: str
    description: Optional[str] = None
    file_path: Optional[str] = None
    file_size: Optional[int] = None
    content: Optional[str] = None

    class Config:
        from_attributes = True


@router.get("/scripts", response_model=List[ScriptResponse])
async def get_scripts(
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get all scripts from library."""
    return db.query(ScriptsLibrary).all()


@router.get("/scripts/{script_id}", response_model=ScriptDetailResponse)
async def get_script(
    script_id: str,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get a single script with its content."""
    from pathlib import Path

    script = db.query(ScriptsLibrary).filter(ScriptsLibrary.id == script_id).first()
    if not script:
        raise HTTPException(status_code=404, detail="Script not found")

    # Read script content from file if it exists
    content = None
    if script.file_path:
        try:
            file_path = Path(script.file_path)
            if file_path.exists():
                content = file_path.read_text(encoding='utf-8')
        except Exception as e:
            import logging
            logger = logging.getLogger(__name__)
            logger.error(f"Failed to read script file {script.file_path}: {str(e)}")

    return ScriptDetailResponse(
        id=script.id,
        name=script.name,
        type=script.type,
        category=script.category,
        description=script.description,
        file_path=script.file_path,
        file_size=script.file_size,
        content=content
    )


@router.post("/scripts", response_model=ScriptResponse)
async def create_script(
    script_data: ScriptCreate,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Create a new script entry with optional inline content."""
    from pathlib import Path
    import logging

    logger = logging.getLogger(__name__)

    new_script = ScriptsLibrary(
        id=f"SCR-{str(uuid.uuid4())[:8]}",
        name=script_data.name,
        type=script_data.type,
        category=script_data.category,
        description=script_data.description,
        file_path=None  # Will be set if content is provided
    )

    # If content is provided, save it to a file
    if script_data.content:
        try:
            # Create scripts directory if it doesn't exist
            scripts_dir = Path("/app/data/scripts")
            scripts_dir.mkdir(parents=True, exist_ok=True)

            # Determine file extension based on script type
            ext = ".ps1" if script_data.type == "PowerShell" else ".bat"

            # Create file path
            file_path = scripts_dir / f"{new_script.id}{ext}"

            # Write content to file
            file_path.write_text(script_data.content, encoding='utf-8')

            # Update script with file info
            new_script.file_path = str(file_path)
            new_script.file_size = file_path.stat().st_size

            logger.info(f"Created script file: {file_path}")
        except Exception as e:
            logger.error(f"Failed to create script file: {str(e)}")
            raise HTTPException(status_code=500, detail="Failed to save script content")

    db.add(new_script)
    db.commit()
    db.refresh(new_script)
    return new_script


@router.put("/scripts/{script_id}", response_model=ScriptResponse)
async def update_script(
    script_id: str,
    script_data: ScriptUpdate,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Update a script's metadata and/or content."""
    from pathlib import Path
    import logging

    logger = logging.getLogger(__name__)

    script = db.query(ScriptsLibrary).filter(ScriptsLibrary.id == script_id).first()
    if not script:
        raise HTTPException(status_code=404, detail="Script not found")

    # Update metadata fields
    update_data = script_data.model_dump(exclude_unset=True, exclude={'content'})
    for key, value in update_data.items():
        setattr(script, key, value)

    # Update content if provided
    if script_data.content is not None:
        if script.file_path:
            try:
                file_path = Path(script.file_path)
                file_path.write_text(script_data.content, encoding='utf-8')
                # Update file size
                script.file_size = file_path.stat().st_size
                logger.info(f"Updated script content: {script.file_path}")
            except Exception as e:
                logger.error(f"Failed to update script file {script.file_path}: {str(e)}")
                raise HTTPException(status_code=500, detail="Failed to update script content")
        else:
            raise HTTPException(status_code=400, detail="Script has no associated file")

    db.commit()
    db.refresh(script)
    return script


@router.delete("/scripts/{script_id}")
async def delete_script(
    script_id: str,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Delete a script and its associated file."""
    from pathlib import Path
    import logging

    logger = logging.getLogger(__name__)

    script = db.query(ScriptsLibrary).filter(ScriptsLibrary.id == script_id).first()
    if not script:
        raise HTTPException(status_code=404, detail="Script not found")

    # Check if script is in use by any master profiles
    if script.master_profiles:
        raise HTTPException(
            status_code=400,
            detail=f"Cannot delete script. It is in use by {len(script.master_profiles)} profile(s)"
        )

    # Delete physical file if it exists
    if script.file_path:
        try:
            file_path = Path(script.file_path)
            if file_path.exists():
                file_path.unlink()
                logger.info(f"Deleted script file: {script.file_path}")
        except Exception as e:
            logger.error(f"Failed to delete script file {script.file_path}: {str(e)}")
            # Continue with database deletion even if file deletion fails

    db.delete(script)
    db.commit()
    return {"message": "Script deleted successfully"}
