from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional
from ..core.database import get_db
from ..models.software import SoftwareCatalog
from ..routes.auth import get_current_user
from pydantic import BaseModel
import uuid

router = APIRouter()


class SoftwareResponse(BaseModel):
    id: str
    name: str
    version: str
    file_path: Optional[str] = None
    file_size: Optional[int] = None
    description: Optional[str] = None
    install_params: Optional[str] = None

    class Config:
        from_attributes = True


class SoftwareCreate(BaseModel):
    name: str
    version: str
    description: Optional[str] = None
    install_params: Optional[str] = None


class SoftwareUpdate(BaseModel):
    name: Optional[str] = None
    version: Optional[str] = None
    description: Optional[str] = None
    install_params: Optional[str] = None


class HashCheckRequest(BaseModel):
    hash: str


@router.post("/software/check-duplicate")
async def check_software_duplicate(
    request: HashCheckRequest,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Check if a software package with this hash already exists."""
    existing_software = db.query(SoftwareCatalog).filter(
        SoftwareCatalog.hash_sha256 == request.hash
    ).first()

    if existing_software:
        return {
            "duplicate": True,
            "existing": {
                "id": existing_software.id,
                "name": existing_software.name,
                "version": existing_software.version,
                "description": existing_software.description,
                "hash": existing_software.hash_sha256
            }
        }

    return {"duplicate": False}


@router.get("/software", response_model=List[SoftwareResponse])
async def get_software(
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get all software from catalog."""
    return db.query(SoftwareCatalog).all()


@router.post("/software", response_model=SoftwareResponse)
async def create_software(
    software_data: SoftwareCreate,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Create a new software entry. File must be uploaded separately via /upload/software/{software_id}."""
    # Create new software
    new_software = SoftwareCatalog(
        id=f"SW-{str(uuid.uuid4())[:8]}",
        name=software_data.name,
        version=software_data.version,
        description=software_data.description,
        file_path=None,  # Will be set when file is uploaded
        file_size=None
    )

    db.add(new_software)
    db.commit()
    db.refresh(new_software)
    return new_software


@router.put("/software/{software_id}", response_model=SoftwareResponse)
async def update_software(
    software_id: str,
    software_data: SoftwareUpdate,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Update a software package."""
    software = db.query(SoftwareCatalog).filter(SoftwareCatalog.id == software_id).first()
    if not software:
        raise HTTPException(status_code=404, detail="Software not found")

    # Update only provided fields
    update_data = software_data.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(software, key, value)

    db.commit()
    db.refresh(software)
    return software


@router.delete("/software/{software_id}")
async def delete_software(
    software_id: str,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Delete a software package."""
    software = db.query(SoftwareCatalog).filter(SoftwareCatalog.id == software_id).first()
    if not software:
        raise HTTPException(status_code=404, detail="Software not found")

    # Check if software is in use by any master profiles
    if software.master_profiles:
        raise HTTPException(
            status_code=400,
            detail=f"Cannot delete software. It is in use by {len(software.master_profiles)} profile(s)"
        )

    # Delete physical file if it exists
    from pathlib import Path
    import logging

    logger = logging.getLogger(__name__)

    if software.file_path:
        try:
            file_path = Path(software.file_path)
            if file_path.exists():
                file_path.unlink()
                logger.info(f"Deleted software file: {software.file_path}")
        except Exception as e:
            logger.error(f"Failed to delete software file {software.file_path}: {str(e)}")
            # Continue with database deletion even if file deletion fails

    db.delete(software)
    db.commit()
    return {"message": "Software deleted successfully"}
