from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, Request
from sqlalchemy.orm import Session
from typing import Optional
import aiofiles
import asyncio
import hashlib
import os
from pathlib import Path
from ..core.database import get_db
from ..routes.auth import get_current_user
from ..models.operating_system import OperatingSystem
from ..models.driver import DriverLibrary
from ..models.software import SoftwareCatalog
from ..models.script import ScriptsLibrary
from ..models.system_settings import SystemSettings
from ..core.redis_client import redis_store
import uuid
import json
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

router = APIRouter()

# Upload session TTL: 1 hour (3600 seconds)
UPLOAD_SESSION_TTL = 3600


def get_upload_paths(db: Session):
    """Get upload paths from system settings, with fallback to defaults."""
    settings = db.query(SystemSettings).first()
    if not settings:
        # Return default paths if no settings exist
        return {
            "base": Path("/app/uploads"),
            "os_images": Path("/app/uploads/os_images"),
            "drivers": Path("/app/uploads/drivers"),
            "software": Path("/app/uploads/software"),
            "scripts": Path("/app/uploads/scripts"),
            "temp": Path("/app/uploads/temp")
        }

    base_path = Path(settings.upload_base_path or "/app/uploads")
    return {
        "base": base_path,
        "os_images": Path(settings.os_images_path or base_path / "os_images"),
        "drivers": Path(settings.drivers_path or base_path / "drivers"),
        "software": Path(settings.software_path or base_path / "software"),
        "scripts": Path(settings.scripts_path or base_path / "scripts"),
        "temp": base_path / "temp"
    }


def ensure_upload_directories(paths: dict):
    """Ensure all upload directories exist."""
    for path in paths.values():
        path.mkdir(parents=True, exist_ok=True)


async def calculate_file_hash(file_path: Path) -> str:
    """Calculate SHA256 hash of a file."""
    sha256_hash = hashlib.sha256()
    async with aiofiles.open(file_path, "rb") as f:
        while chunk := await f.read(8192):
            sha256_hash.update(chunk)
    return sha256_hash.hexdigest()


async def save_upload_file(upload_file: UploadFile, destination: Path) -> tuple[int, str]:
    """Save uploaded file and return size and hash."""
    file_size = 0
    async with aiofiles.open(destination, 'wb') as out_file:
        while content := await upload_file.read(1024 * 1024):  # Read 1MB at a time
            file_size += len(content)
            await out_file.write(content)

    file_hash = await calculate_file_hash(destination)
    return file_size, file_hash


# ========== CHUNKED UPLOAD ENDPOINTS ==========

@router.post("/upload/chunked/init")
async def init_chunked_upload(
    request: Request,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Initialize a chunked upload session."""

    # Parse form data manually
    form_data = await request.form()

    filename = form_data.get("filename")
    total_size = form_data.get("total_size")
    total_chunks = form_data.get("total_chunks")
    resource_type = form_data.get("resource_type")
    resource_id = form_data.get("resource_id")

    logger.info(f"Init chunked upload: filename={filename}, size={total_size}, chunks={total_chunks}, type={resource_type}, id={resource_id}")

    # Convert string values to integers
    try:
        total_size_int = int(total_size)
        total_chunks_int = int(total_chunks)
    except (ValueError, TypeError) as e:
        raise HTTPException(status_code=422, detail=f"Invalid numeric values: {str(e)}")

    upload_id = str(uuid.uuid4())

    # Get configured upload paths
    paths = get_upload_paths(db)
    ensure_upload_directories(paths)

    # Create temp directory for this upload
    upload_temp_dir = paths["temp"] / upload_id
    upload_temp_dir.mkdir(parents=True, exist_ok=True)

    # Store upload session info in Redis
    session_data = {
        "upload_id": upload_id,
        "filename": filename,
        "total_size": total_size_int,
        "total_chunks": total_chunks_int,
        "resource_type": resource_type,
        "resource_id": resource_id,
        "uploaded_chunks": [],
        "temp_dir": str(upload_temp_dir),
        "status": "in_progress",
        "created_at": datetime.now().isoformat(),
        "user_id": current_user.id
    }

    success = await redis_store.set(f"upload:{upload_id}", session_data, expire=UPLOAD_SESSION_TTL)
    if not success:
        logger.error(f"Failed to store upload session in Redis: {upload_id}")
        raise HTTPException(status_code=500, detail="Failed to initialize upload session")

    return {
        "upload_id": upload_id,
        "message": "Upload session initialized"
    }


@router.post("/upload/chunked/chunk")
async def upload_chunk(
    upload_id: str = Form(...),
    chunk_index: int = Form(...),
    chunk: UploadFile = File(...),
    current_user = Depends(get_current_user)
):
    """Upload a single chunk."""
    # Retrieve session from Redis
    session = await redis_store.get(f"upload:{upload_id}")
    if not session:
        raise HTTPException(status_code=404, detail="Upload session not found")

    # Verify user owns this upload session
    if session["user_id"] != current_user.id:
        raise HTTPException(status_code=403, detail="Unauthorized")

    # Save chunk to temp directory
    chunk_path = Path(session["temp_dir"]) / f"chunk_{chunk_index}"

    try:
        async with aiofiles.open(chunk_path, 'wb') as out_file:
            while content := await chunk.read(1024 * 1024):
                await out_file.write(content)

        # Track uploaded chunk using Redis Set for atomic operations (allows parallel uploads)
        await redis_store._ensure_client()
        chunks_key = f"upload:{upload_id}:chunks"

        # Atomically add chunk index to set (must convert to string for decode_responses=True)
        await redis_store.client.sadd(chunks_key, str(chunk_index))
        await redis_store.client.expire(chunks_key, UPLOAD_SESSION_TTL)

        # Get session for progress calculation
        session = await redis_store.get(f"upload:{upload_id}")
        if not session:
            raise HTTPException(status_code=404, detail="Upload session not found")

        # Get count of uploaded chunks
        uploaded_count = await redis_store.client.scard(chunks_key)
        progress = (uploaded_count / session["total_chunks"]) * 100

        return {
            "upload_id": upload_id,
            "chunk_index": chunk_index,
            "progress": round(progress, 2),
            "uploaded_chunks": uploaded_count,
            "total_chunks": session["total_chunks"]
        }
    except Exception as e:
        import traceback
        logger.error(f"Chunk upload error: {str(e)}")
        logger.error(traceback.format_exc())
        raise HTTPException(status_code=500, detail=f"Chunk upload failed: {str(e)}")


@router.post("/upload/chunked/complete")
async def complete_chunked_upload(
    upload_id: str = Form(...),
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Complete chunked upload by assembling chunks and updating database."""
    # Retrieve session from Redis
    session = await redis_store.get(f"upload:{upload_id}")
    if not session:
        raise HTTPException(status_code=404, detail="Upload session not found")

    # Verify user owns this upload session
    if session["user_id"] != current_user.id:
        raise HTTPException(status_code=403, detail="Unauthorized")

    # Verify all chunks are uploaded using Redis Set
    await redis_store._ensure_client()
    chunks_key = f"upload:{upload_id}:chunks"
    uploaded_chunks = await redis_store.client.smembers(chunks_key)
    uploaded_chunks_list = [int(c) for c in uploaded_chunks]

    if len(uploaded_chunks_list) != session["total_chunks"]:
        error_msg = f"Missing chunks for upload {upload_id}: Expected {session['total_chunks']}, got {len(uploaded_chunks_list)}, uploaded: {sorted(uploaded_chunks_list)}"
        logger.error(error_msg)
        raise HTTPException(
            status_code=400,
            detail=f"Missing chunks. Expected {session['total_chunks']}, got {len(uploaded_chunks_list)}. Uploaded: {sorted(uploaded_chunks_list)}"
        )

    temp_dir = Path(session["temp_dir"])
    resource_type = session["resource_type"]
    resource_id = session["resource_id"]
    filename = session["filename"]

    # Get configured upload paths
    paths = get_upload_paths(db)
    ensure_upload_directories(paths)

    # Determine final destination
    if resource_type == "os":
        final_dir = paths["os_images"]
        file_extension = Path(filename).suffix
        final_filename = f"{resource_id}_{uuid.uuid4()}{file_extension}"
    elif resource_type == "driver":
        final_dir = paths["drivers"]
        final_filename = f"{resource_id}_{uuid.uuid4()}.zip"
    elif resource_type == "software":
        final_dir = paths["software"]
        file_extension = Path(filename).suffix
        final_filename = f"{resource_id}_{uuid.uuid4()}{file_extension}"
    elif resource_type == "script":
        final_dir = paths["scripts"]
        file_extension = Path(filename).suffix
        final_filename = f"{resource_id}_{uuid.uuid4()}{file_extension}"
    else:
        raise HTTPException(status_code=400, detail="Invalid resource type")

    final_path = final_dir / final_filename

    try:
        # Assemble chunks in order and calculate hash simultaneously for better performance
        hash_obj = hashlib.sha256()
        file_size = 0

        async with aiofiles.open(final_path, 'wb') as final_file:
            for i in range(session["total_chunks"]):
                chunk_path = temp_dir / f"chunk_{i}"
                if not chunk_path.exists():
                    raise HTTPException(status_code=500, detail=f"Chunk {i} is missing")

                # Use larger buffer (10MB) for faster I/O
                async with aiofiles.open(chunk_path, 'rb') as chunk_file:
                    while content := await chunk_file.read(10 * 1024 * 1024):
                        await final_file.write(content)
                        hash_obj.update(content)
                        file_size += len(content)

        # Hash was calculated during assembly - no need to re-read file
        file_hash = hash_obj.hexdigest()

        # Update database based on resource type
        if resource_type == "os":
            record = db.query(OperatingSystem).filter(OperatingSystem.id == resource_id).first()
        elif resource_type == "driver":
            record = db.query(DriverLibrary).filter(DriverLibrary.id == resource_id).first()
        elif resource_type == "software":
            record = db.query(SoftwareCatalog).filter(SoftwareCatalog.id == resource_id).first()
        elif resource_type == "script":
            record = db.query(ScriptsLibrary).filter(ScriptsLibrary.id == resource_id).first()
        else:
            record = None

        if not record:
            # Clean up file
            final_path.unlink()
            raise HTTPException(status_code=404, detail=f"{resource_type.capitalize()} not found")

        # Check for duplicate hash before updating
        if hasattr(record, 'hash_sha256'):
            # Check if this hash already exists for a different record
            if resource_type == "os":
                existing = db.query(OperatingSystem).filter(
                    OperatingSystem.hash_sha256 == file_hash,
                    OperatingSystem.id != resource_id
                ).first()
            elif resource_type == "driver":
                existing = db.query(DriverLibrary).filter(
                    DriverLibrary.hash_sha256 == file_hash,
                    DriverLibrary.id != resource_id
                ).first()
            elif resource_type == "software":
                existing = db.query(SoftwareCatalog).filter(
                    SoftwareCatalog.hash_sha256 == file_hash,
                    SoftwareCatalog.id != resource_id
                ).first()
            else:
                existing = None

            if existing:
                # Duplicate found - clean up uploaded file and temp directory
                final_path.unlink()
                for chunk_file in temp_dir.glob("chunk_*"):
                    chunk_file.unlink()
                temp_dir.rmdir()
                await redis_store.delete(f"upload:{upload_id}")
                await redis_store._ensure_client()
                await redis_store.client.delete(chunks_key)

                # Return error with details about existing file
                raise HTTPException(
                    status_code=409,
                    detail=f"Duplicate file detected. This file already exists as '{existing.name}' (ID: {existing.id})"
                )

        # Update record
        record.file_path = str(final_path)
        record.file_size = file_size
        if hasattr(record, 'hash_sha256'):
            record.hash_sha256 = file_hash

        # Extract and update metadata for OS images
        if resource_type == "os":
            from ..utils.os_metadata import parse_os_metadata_from_filename
            metadata = parse_os_metadata_from_filename(filename)

            # Update OS metadata if extracted successfully
            if metadata.get("version") and metadata["version"] != "N/A":
                record.version = metadata["version"]
            if metadata.get("edition") and metadata["edition"] != "N/A":
                record.edition = metadata["edition"]
            if metadata.get("build") and metadata["build"] != "N/A":
                record.build = metadata["build"]
            # Update name with extracted metadata if better than current
            if metadata.get("name") and metadata["name"] != "N/A" and metadata["name"] != filename:
                record.name = metadata["name"]

        db.commit()
        db.refresh(record)

        # Clean up temp directory
        for chunk_file in temp_dir.glob("chunk_*"):
            chunk_file.unlink()
        temp_dir.rmdir()

        # Clean up Redis keys
        await redis_store.delete(f"upload:{upload_id}")
        await redis_store._ensure_client()
        await redis_store.client.delete(chunks_key)

        return {
            "message": "Upload completed successfully",
            "upload_id": upload_id,
            "resource_id": resource_id,
            "filename": final_filename,
            "size": file_size,
            "hash": file_hash
        }
    except Exception as e:
        # Clean up on error
        if final_path.exists():
            final_path.unlink()
        raise HTTPException(status_code=500, detail=f"Upload completion failed: {str(e)}")


@router.post("/upload/operating-system/{os_id}")
async def upload_operating_system(
    os_id: str,
    file: UploadFile = File(...),
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Upload an operating system image (WIM/ISO file)."""
    # Validate file type
    if not file.filename.lower().endswith(('.wim', '.iso', '.esd')):
        raise HTTPException(status_code=400, detail="Invalid file type. Only WIM, ISO, and ESD files are allowed.")

    # Get OS record
    os_record = db.query(OperatingSystem).filter(OperatingSystem.id == os_id).first()
    if not os_record:
        raise HTTPException(status_code=404, detail="Operating system not found")

    # Get configured upload paths
    paths = get_upload_paths(db)
    ensure_upload_directories(paths)

    # Generate unique filename
    file_extension = Path(file.filename).suffix
    unique_filename = f"{os_id}_{uuid.uuid4()}{file_extension}"
    file_path = paths["os_images"] / unique_filename

    # Save file
    try:
        file_size, file_hash = await save_upload_file(file, file_path)

        # Update database
        os_record.file_path = str(file_path)
        os_record.file_size = file_size
        os_record.hash_sha256 = file_hash

        db.commit()
        db.refresh(os_record)

        return {
            "message": "File uploaded successfully",
            "os_id": os_id,
            "filename": unique_filename,
            "size": file_size,
            "hash": file_hash
        }
    except Exception as e:
        # Clean up file if database update fails
        if file_path.exists():
            file_path.unlink()
        raise HTTPException(status_code=500, detail=f"Upload failed: {str(e)}")


@router.post("/upload/driver/{driver_id}")
async def upload_driver(
    driver_id: str,
    file: UploadFile = File(...),
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Upload a driver package (ZIP file)."""
    if not file.filename.lower().endswith('.zip'):
        raise HTTPException(status_code=400, detail="Invalid file type. Only ZIP files are allowed.")

    driver_record = db.query(DriverLibrary).filter(DriverLibrary.id == driver_id).first()
    if not driver_record:
        raise HTTPException(status_code=404, detail="Driver not found")

    # Get configured upload paths
    paths = get_upload_paths(db)
    ensure_upload_directories(paths)

    unique_filename = f"{driver_id}_{uuid.uuid4()}.zip"
    file_path = paths["drivers"] / unique_filename

    try:
        file_size, file_hash = await save_upload_file(file, file_path)

        driver_record.file_path = str(file_path)
        driver_record.file_size = file_size
        driver_record.hash_sha256 = file_hash

        db.commit()
        db.refresh(driver_record)

        return {
            "message": "Driver uploaded successfully",
            "driver_id": driver_id,
            "filename": unique_filename,
            "size": file_size,
            "hash": file_hash
        }
    except Exception as e:
        if file_path.exists():
            file_path.unlink()
        raise HTTPException(status_code=500, detail=f"Upload failed: {str(e)}")


@router.post("/upload/software/{software_id}")
async def upload_software(
    software_id: str,
    file: UploadFile = File(...),
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Upload a software package (EXE, MSI, MSIX)."""
    allowed_extensions = ('.exe', '.msi', '.msix', '.appx', '.zip')
    if not file.filename.lower().endswith(allowed_extensions):
        raise HTTPException(
            status_code=400,
            detail=f"Invalid file type. Allowed: {', '.join(allowed_extensions)}"
        )

    software_record = db.query(SoftwareCatalog).filter(SoftwareCatalog.id == software_id).first()
    if not software_record:
        raise HTTPException(status_code=404, detail="Software not found")

    # Get configured upload paths
    paths = get_upload_paths(db)
    ensure_upload_directories(paths)

    file_extension = Path(file.filename).suffix
    unique_filename = f"{software_id}_{uuid.uuid4()}{file_extension}"
    file_path = paths["software"] / unique_filename

    try:
        file_size, file_hash = await save_upload_file(file, file_path)

        software_record.file_path = str(file_path)
        software_record.file_size = file_size

        db.commit()
        db.refresh(software_record)

        return {
            "message": "Software uploaded successfully",
            "software_id": software_id,
            "filename": unique_filename,
            "size": file_size,
            "hash": file_hash
        }
    except Exception as e:
        if file_path.exists():
            file_path.unlink()
        raise HTTPException(status_code=500, detail=f"Upload failed: {str(e)}")


@router.post("/upload/script/{script_id}")
async def upload_script(
    script_id: str,
    file: UploadFile = File(...),
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Upload a script file (PS1, BAT, CMD)."""
    allowed_extensions = ('.ps1', '.bat', '.cmd', '.sh')
    if not file.filename.lower().endswith(allowed_extensions):
        raise HTTPException(
            status_code=400,
            detail=f"Invalid file type. Allowed: {', '.join(allowed_extensions)}"
        )

    script_record = db.query(ScriptsLibrary).filter(ScriptsLibrary.id == script_id).first()
    if not script_record:
        raise HTTPException(status_code=404, detail="Script not found")

    # Get configured upload paths
    paths = get_upload_paths(db)
    ensure_upload_directories(paths)

    file_extension = Path(file.filename).suffix
    unique_filename = f"{script_id}_{uuid.uuid4()}{file_extension}"
    file_path = paths["scripts"] / unique_filename

    try:
        file_size, file_hash = await save_upload_file(file, file_path)

        script_record.file_path = str(file_path)

        db.commit()
        db.refresh(script_record)

        return {
            "message": "Script uploaded successfully",
            "script_id": script_id,
            "filename": unique_filename,
            "size": file_size,
            "hash": file_hash
        }
    except Exception as e:
        if file_path.exists():
            file_path.unlink()
        raise HTTPException(status_code=500, detail=f"Upload failed: {str(e)}")


@router.get("/upload/progress/{upload_id}")
async def get_upload_progress(
    upload_id: str,
    current_user = Depends(get_current_user)
):
    """Get upload progress for a chunked upload."""
    # Retrieve session from Redis
    session = await redis_store.get(f"upload:{upload_id}")
    if not session:
        raise HTTPException(status_code=404, detail="Upload session not found")

    # Verify user owns this upload session
    if session["user_id"] != current_user.id:
        raise HTTPException(status_code=403, detail="Unauthorized")

    progress = (len(session["uploaded_chunks"]) / session["total_chunks"]) * 100

    return {
        "upload_id": upload_id,
        "progress": round(progress, 2),
        "status": session["status"],
        "uploaded_chunks": len(session["uploaded_chunks"]),
        "total_chunks": session["total_chunks"],
        "filename": session["filename"]
    }
