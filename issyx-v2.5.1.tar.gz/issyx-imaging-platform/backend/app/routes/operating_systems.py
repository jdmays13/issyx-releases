from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from sqlalchemy.orm import Session
from typing import List, Optional
from ..core.database import get_db
from ..models.operating_system import OperatingSystem
from ..routes.auth import get_current_user
from pydantic import BaseModel
import uuid

router = APIRouter()


class OSResponse(BaseModel):
    id: str
    name: str
    version: str
    edition: str
    build: str = None

    class Config:
        from_attributes = True


class OSCreate(BaseModel):
    name: str
    version: str
    edition: str
    build: Optional[str] = None


class HashCheckRequest(BaseModel):
    hash: str


@router.post("/operating-systems/check-duplicate")
async def check_os_duplicate(
    request: HashCheckRequest,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Check if an OS with this hash already exists."""
    existing_os = db.query(OperatingSystem).filter(
        OperatingSystem.hash_sha256 == request.hash
    ).first()

    if existing_os:
        return {
            "duplicate": True,
            "existing": {
                "id": existing_os.id,
                "name": existing_os.name,
                "version": existing_os.version,
                "edition": existing_os.edition,
                "build": existing_os.build,
                "hash": existing_os.hash_sha256
            }
        }

    return {"duplicate": False}


@router.get("/operating-systems", response_model=List[OSResponse])
async def get_operating_systems(
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get all operating systems."""
    return db.query(OperatingSystem).all()


@router.post("/operating-systems", response_model=OSResponse)
async def create_operating_system(
    os_data: OSCreate,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Create a new operating system entry. File must be uploaded separately via /upload/operating-system/{os_id}."""
    new_os = OperatingSystem(
        id=f"OS-{str(uuid.uuid4())[:8]}",
        name=os_data.name,
        version=os_data.version,
        edition=os_data.edition,
        build=os_data.build,
        file_path=None,  # Will be set when file is uploaded
        file_size=None
    )

    db.add(new_os)
    db.commit()
    db.refresh(new_os)
    return new_os


@router.delete("/operating-systems/{os_id}")
async def delete_operating_system(
    os_id: str,
    db = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Delete an operating system."""
    os_entry = db.query(OperatingSystem).filter(OperatingSystem.id == os_id).first()
    if not os_entry:
        raise HTTPException(status_code=404, detail="Operating system not found")

    # Check if OS is in use by any master profiles
    if os_entry.master_profiles:
        raise HTTPException(
            status_code=400,
            detail=f"Cannot delete OS. It is in use by {len(os_entry.master_profiles)} profile(s)"
        )

    # Delete actual file from storage
    import os
    from pathlib import Path
    if os_entry.file_path:
        file_path = Path(os_entry.file_path)
        if file_path.exists():
            try:
                file_path.unlink()
            except Exception as e:
                # Log error but don't fail the deletion
                print(f"Warning: Failed to delete file {file_path}: {e}")

    db.delete(os_entry)
    db.commit()
    return {"message": "Operating system deleted successfully"}
