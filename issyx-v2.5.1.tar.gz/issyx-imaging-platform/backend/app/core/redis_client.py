"""
Redis Client Configuration and Utilities

Provides a shared Redis client instance and helper functions for
caching, session management, and real-time data storage.
"""
import redis.asyncio as redis
from typing import Optional, Any
import json
import logging
from .config import settings

logger = logging.getLogger(__name__)

# Global Redis client instance
_redis_client: Optional[redis.Redis] = None


async def get_redis_client() -> redis.Redis:
    """
    Get or create the global Redis client instance.

    Returns:
        Redis client instance
    """
    global _redis_client

    if _redis_client is None:
        try:
            _redis_client = redis.from_url(
                settings.REDIS_URL,
                encoding="utf-8",
                decode_responses=True,
                socket_connect_timeout=5
            )
            # Test connection
            await _redis_client.ping()
            logger.info(f"Redis client connected: {settings.REDIS_URL}")
        except Exception as e:
            logger.error(f"Failed to connect to Redis: {str(e)}")
            logger.warning("Falling back to in-memory storage")
            _redis_client = None
            raise

    return _redis_client


async def close_redis_client():
    """Close the Redis client connection."""
    global _redis_client

    if _redis_client:
        await _redis_client.close()
        _redis_client = None
        logger.info("Redis client closed")


class RedisStore:
    """
    Redis-backed key-value store with JSON serialization.

    Provides a high-level interface for storing and retrieving
    data from Redis with automatic JSON encoding/decoding.
    """

    def __init__(self):
        self.client: Optional[redis.Redis] = None

    async def _ensure_client(self):
        """Ensure Redis client is initialized."""
        if self.client is None:
            self.client = await get_redis_client()

    async def set(self, key: str, value: Any, expire: Optional[int] = None) -> bool:
        """
        Set a key-value pair in Redis.

        Args:
            key: Redis key
            value: Value to store (will be JSON-encoded)
            expire: Optional expiration time in seconds

        Returns:
            True if successful, False otherwise
        """
        try:
            await self._ensure_client()

            # Serialize value to JSON
            json_value = json.dumps(value)

            if expire:
                await self.client.setex(key, expire, json_value)
            else:
                await self.client.set(key, json_value)

            return True
        except Exception as e:
            logger.error(f"Redis SET error for key '{key}': {str(e)}")
            return False

    async def get(self, key: str) -> Optional[Any]:
        """
        Get a value from Redis.

        Args:
            key: Redis key

        Returns:
            Deserialized value or None if not found
        """
        try:
            await self._ensure_client()

            value = await self.client.get(key)
            if value is None:
                return None

            # Deserialize JSON value
            return json.loads(value)
        except Exception as e:
            logger.error(f"Redis GET error for key '{key}': {str(e)}")
            return None

    async def delete(self, key: str) -> bool:
        """
        Delete a key from Redis.

        Args:
            key: Redis key

        Returns:
            True if key was deleted, False otherwise
        """
        try:
            await self._ensure_client()
            await self.client.delete(key)
            return True
        except Exception as e:
            logger.error(f"Redis DELETE error for key '{key}': {str(e)}")
            return False

    async def exists(self, key: str) -> bool:
        """
        Check if a key exists in Redis.

        Args:
            key: Redis key

        Returns:
            True if key exists, False otherwise
        """
        try:
            await self._ensure_client()
            return await self.client.exists(key) > 0
        except Exception as e:
            logger.error(f"Redis EXISTS error for key '{key}': {str(e)}")
            return False

    async def keys(self, pattern: str = "*") -> list[str]:
        """
        Get all keys matching a pattern.

        Args:
            pattern: Redis key pattern (default: *)

        Returns:
            List of matching keys
        """
        try:
            await self._ensure_client()
            return await self.client.keys(pattern)
        except Exception as e:
            logger.error(f"Redis KEYS error for pattern '{pattern}': {str(e)}")
            return []

    async def expire(self, key: str, seconds: int) -> bool:
        """
        Set expiration time for a key.

        Args:
            key: Redis key
            seconds: Expiration time in seconds

        Returns:
            True if successful, False otherwise
        """
        try:
            await self._ensure_client()
            return await self.client.expire(key, seconds)
        except Exception as e:
            logger.error(f"Redis EXPIRE error for key '{key}': {str(e)}")
            return False


# Global store instance
redis_store = RedisStore()
