from pydantic_settings import BaseSettings
from typing import List
import os


class Settings(BaseSettings):
    # API
    API_V1_PREFIX: str = "/api/v1"
    PROJECT_NAME: str = "Issyx Imaging Platform API"
    VERSION: str = "1.0.0"

    # Database - will be overridden by environment variable in Docker
    DATABASE_URL: str = "postgresql://issyx:issyx_dev_password@localhost:5432/issyx"

    # Security
    SECRET_KEY: str = "your-secret-key-change-this-in-production-09876543210"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30

    # CORS
    BACKEND_CORS_ORIGINS: List[str] = ["http://localhost:3000", "http://localhost:5173"]

    # File Storage
    DATA_ROOT: str = "../data"
    MAX_UPLOAD_SIZE: int = 10737418240  # 10GB

    # Redis
    REDIS_URL: str = "redis://localhost:6379/0"

    # Server
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    RELOAD: bool = True

    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()
