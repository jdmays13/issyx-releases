from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from typing import Annotated, Any
from fastapi import Depends
from pydantic import SkipValidation
from .config import settings

# Create engine
# For SQLite, we need to disable same-thread check for FastAPI async compatibility
connect_args = {"check_same_thread": False} if settings.DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(settings.DATABASE_URL, pool_pre_ping=True, connect_args=connect_args)

# Session factory
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Base class for models
Base = declarative_base()


# Dependency for getting DB session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# Type alias for dependency injection with proper typing
# This avoids Pydantic trying to validate SQLAlchemy Session internals
# SkipValidation tells Pydantic not to introspect Session's internal types
SessionDep = Annotated[SkipValidation[Any], Depends(get_db)]
