"""
DISM Service for Real OS Imaging Operations

Provides wrapper functions for executing real DISM commands for:
- OS image deployment
- Driver injection
- Offline servicing
- Image management

These commands are designed to be called from WinPE or Windows environment.
"""
import logging
import subprocess
import os
from typing import List, Optional, Tuple
from pathlib import Path

logger = logging.getLogger(__name__)


class DISMService:
    """
    Service class for executing DISM (Deployment Image Servicing and Management) commands.

    DISM is the official Microsoft tool for servicing Windows images.
    """

    def __init__(self, dism_path: str = "dism.exe"):
        """
        Initialize DISM service.

        Args:
            dism_path: Path to DISM executable (default: dism.exe from PATH)
        """
        self.dism_path = dism_path

    async def apply_image(
        self,
        wim_file: str,
        target_drive: str,
        image_index: int = 1,
        verify: bool = True
    ) -> Tuple[bool, str]:
        """
        Apply a WIM image to a target drive.

        This is the core imaging operation - deploys Windows OS to disk.

        Args:
            wim_file: Path to WIM file (e.g., C:\\Images\\install.wim)
            target_drive: Target drive letter or mount point (e.g., C: or D:)
            image_index: Index of image in WIM file (default: 1)
            verify: Verify image integrity after deployment

        Returns:
            Tuple of (success: bool, message: str)

        Example DISM command:
            dism /Apply-Image /ImageFile:C:\\Images\\install.wim /Index:1 /ApplyDir:C:\\ /Verify
        """
        try:
            # Validate inputs
            if not os.path.exists(wim_file):
                return False, f"WIM file not found: {wim_file}"

            if not os.path.exists(target_drive):
                return False, f"Target drive not found: {target_drive}"

            # Build DISM command
            cmd = [
                self.dism_path,
                "/Apply-Image",
                f"/ImageFile:{wim_file}",
                f"/Index:{image_index}",
                f"/ApplyDir:{target_drive}"
            ]

            if verify:
                cmd.append("/Verify")

            logger.info(f"Applying image: {' '.join(cmd)}")

            # Execute DISM command
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=1800  # 30 minutes timeout
            )

            if result.returncode == 0:
                logger.info(f"Image applied successfully to {target_drive}")
                return True, f"Image applied successfully. Output: {result.stdout[:200]}"
            else:
                logger.error(f"DISM apply-image failed: {result.stderr}")
                return False, f"DISM error: {result.stderr[:500]}"

        except subprocess.TimeoutExpired:
            return False, "DISM apply-image timeout (30 minutes exceeded)"
        except Exception as e:
            logger.error(f"Error applying image: {e}")
            return False, f"Exception: {str(e)}"

    async def add_driver(
        self,
        target_path: str,
        driver_path: str,
        recurse: bool = True,
        force_unsigned: bool = False
    ) -> Tuple[bool, str]:
        """
        Inject driver(s) into offline Windows image.

        Args:
            target_path: Mount point or drive of offline Windows image (e.g., C:\\)
            driver_path: Path to driver .inf file or folder containing drivers
            recurse: Search subdirectories for drivers
            force_unsigned: Force installation of unsigned drivers

        Returns:
            Tuple of (success: bool, message: str)

        Example DISM command:
            dism /Image:C:\\ /Add-Driver /Driver:D:\\Drivers\\NetworkAdapter /Recurse /ForceUnsigned
        """
        try:
            # Validate inputs
            if not os.path.exists(target_path):
                return False, f"Target path not found: {target_path}"

            if not os.path.exists(driver_path):
                return False, f"Driver path not found: {driver_path}"

            # Build DISM command
            cmd = [
                self.dism_path,
                f"/Image:{target_path}",
                "/Add-Driver",
                f"/Driver:{driver_path}"
            ]

            if recurse:
                cmd.append("/Recurse")

            if force_unsigned:
                cmd.append("/ForceUnsigned")

            logger.info(f"Adding driver: {' '.join(cmd)}")

            # Execute DISM command
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=600  # 10 minutes timeout
            )

            if result.returncode == 0:
                logger.info(f"Driver(s) added successfully from {driver_path}")
                return True, f"Driver(s) injected successfully. Output: {result.stdout[:200]}"
            else:
                logger.error(f"DISM add-driver failed: {result.stderr}")
                return False, f"DISM error: {result.stderr[:500]}"

        except subprocess.TimeoutExpired:
            return False, "DISM add-driver timeout (10 minutes exceeded)"
        except Exception as e:
            logger.error(f"Error adding driver: {e}")
            return False, f"Exception: {str(e)}"

    async def mount_image(
        self,
        wim_file: str,
        mount_dir: str,
        image_index: int = 1,
        read_only: bool = False
    ) -> Tuple[bool, str]:
        """
        Mount a WIM image to a directory for offline servicing.

        Args:
            wim_file: Path to WIM file
            mount_dir: Directory to mount image to (must exist and be empty)
            image_index: Index of image in WIM file
            read_only: Mount as read-only

        Returns:
            Tuple of (success: bool, message: str)

        Example DISM command:
            dism /Mount-Wim /WimFile:C:\\Images\\install.wim /Index:1 /MountDir:C:\\Mount
        """
        try:
            if not os.path.exists(wim_file):
                return False, f"WIM file not found: {wim_file}"

            if not os.path.exists(mount_dir):
                os.makedirs(mount_dir)

            # Check if directory is empty
            if os.listdir(mount_dir):
                return False, f"Mount directory not empty: {mount_dir}"

            cmd = [
                self.dism_path,
                "/Mount-Wim",
                f"/WimFile:{wim_file}",
                f"/Index:{image_index}",
                f"/MountDir:{mount_dir}"
            ]

            if read_only:
                cmd.append("/ReadOnly")

            logger.info(f"Mounting image: {' '.join(cmd)}")

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=300  # 5 minutes timeout
            )

            if result.returncode == 0:
                logger.info(f"Image mounted successfully at {mount_dir}")
                return True, f"Image mounted at {mount_dir}"
            else:
                logger.error(f"DISM mount failed: {result.stderr}")
                return False, f"DISM error: {result.stderr[:500]}"

        except subprocess.TimeoutExpired:
            return False, "DISM mount timeout (5 minutes exceeded)"
        except Exception as e:
            logger.error(f"Error mounting image: {e}")
            return False, f"Exception: {str(e)}"

    async def unmount_image(
        self,
        mount_dir: str,
        commit: bool = True,
        discard: bool = False
    ) -> Tuple[bool, str]:
        """
        Unmount a WIM image.

        Args:
            mount_dir: Directory where image is mounted
            commit: Commit changes to WIM file
            discard: Discard changes (cannot use with commit=True)

        Returns:
            Tuple of (success: bool, message: str)

        Example DISM command:
            dism /Unmount-Wim /MountDir:C:\\Mount /Commit
        """
        try:
            if not os.path.exists(mount_dir):
                return False, f"Mount directory not found: {mount_dir}"

            if commit and discard:
                return False, "Cannot specify both commit and discard"

            cmd = [
                self.dism_path,
                "/Unmount-Wim",
                f"/MountDir:{mount_dir}"
            ]

            if commit:
                cmd.append("/Commit")
            elif discard:
                cmd.append("/Discard")

            logger.info(f"Unmounting image: {' '.join(cmd)}")

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=300  # 5 minutes timeout
            )

            if result.returncode == 0:
                logger.info(f"Image unmounted successfully from {mount_dir}")
                return True, f"Image unmounted from {mount_dir}"
            else:
                logger.error(f"DISM unmount failed: {result.stderr}")
                return False, f"DISM error: {result.stderr[:500]}"

        except subprocess.TimeoutExpired:
            return False, "DISM unmount timeout (5 minutes exceeded)"
        except Exception as e:
            logger.error(f"Error unmounting image: {e}")
            return False, f"Exception: {str(e)}"

    async def get_image_info(self, wim_file: str) -> Tuple[bool, str]:
        """
        Get information about images in a WIM file.

        Args:
            wim_file: Path to WIM file

        Returns:
            Tuple of (success: bool, info_output: str)

        Example DISM command:
            dism /Get-ImageInfo /ImageFile:C:\\Images\\install.wim
        """
        try:
            if not os.path.exists(wim_file):
                return False, f"WIM file not found: {wim_file}"

            cmd = [
                self.dism_path,
                "/Get-ImageInfo",
                f"/ImageFile:{wim_file}"
            ]

            logger.info(f"Getting image info: {' '.join(cmd)}")

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=60
            )

            if result.returncode == 0:
                return True, result.stdout
            else:
                return False, f"DISM error: {result.stderr[:500]}"

        except subprocess.TimeoutExpired:
            return False, "DISM get-imageinfo timeout"
        except Exception as e:
            logger.error(f"Error getting image info: {e}")
            return False, f"Exception: {str(e)}"

    async def apply_unattend(
        self,
        target_path: str,
        unattend_xml: str
    ) -> Tuple[bool, str]:
        """
        Apply unattend.xml to offline Windows image.

        Args:
            target_path: Mount point or drive of offline Windows image
            unattend_xml: Path to unattend.xml file

        Returns:
            Tuple of (success: bool, message: str)

        Example DISM command:
            dism /Image:C:\\ /Apply-Unattend:C:\\Unattend.xml
        """
        try:
            if not os.path.exists(target_path):
                return False, f"Target path not found: {target_path}"

            if not os.path.exists(unattend_xml):
                return False, f"Unattend.xml not found: {unattend_xml}"

            cmd = [
                self.dism_path,
                f"/Image:{target_path}",
                "/Apply-Unattend",
                f"/UnattendFile:{unattend_xml}"
            ]

            logger.info(f"Applying unattend: {' '.join(cmd)}")

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=120
            )

            if result.returncode == 0:
                logger.info("Unattend.xml applied successfully")
                return True, "Unattend.xml applied successfully"
            else:
                logger.error(f"DISM apply-unattend failed: {result.stderr}")
                return False, f"DISM error: {result.stderr[:500]}"

        except subprocess.TimeoutExpired:
            return False, "DISM apply-unattend timeout"
        except Exception as e:
            logger.error(f"Error applying unattend: {e}")
            return False, f"Exception: {str(e)}"

    async def cleanup_image(
        self,
        target_path: str,
        reset_base: bool = False
    ) -> Tuple[bool, str]:
        """
        Clean up and reduce size of Windows image.

        Args:
            target_path: Mount point or drive of offline Windows image
            reset_base: Reset the base of superseded components to reduce size

        Returns:
            Tuple of (success: bool, message: str)

        Example DISM command:
            dism /Image:C:\\ /Cleanup-Image /StartComponentCleanup /ResetBase
        """
        try:
            if not os.path.exists(target_path):
                return False, f"Target path not found: {target_path}"

            cmd = [
                self.dism_path,
                f"/Image:{target_path}",
                "/Cleanup-Image",
                "/StartComponentCleanup"
            ]

            if reset_base:
                cmd.append("/ResetBase")

            logger.info(f"Cleaning up image: {' '.join(cmd)}")

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=900  # 15 minutes timeout
            )

            if result.returncode == 0:
                logger.info("Image cleanup completed")
                return True, "Image cleanup completed successfully"
            else:
                logger.error(f"DISM cleanup failed: {result.stderr}")
                return False, f"DISM error: {result.stderr[:500]}"

        except subprocess.TimeoutExpired:
            return False, "DISM cleanup timeout (15 minutes exceeded)"
        except Exception as e:
            logger.error(f"Error cleaning up image: {e}")
            return False, f"Exception: {str(e)}"

    async def set_edition(
        self,
        target_path: str,
        target_edition: str
    ) -> Tuple[bool, str]:
        """
        Change the Windows edition (e.g., Home to Pro).

        Args:
            target_path: Mount point or drive of offline Windows image
            target_edition: Target edition name (e.g., "Professional", "Enterprise")

        Returns:
            Tuple of (success: bool, message: str)

        Example DISM command:
            dism /Image:C:\\ /Set-Edition:Professional
        """
        try:
            if not os.path.exists(target_path):
                return False, f"Target path not found: {target_path}"

            cmd = [
                self.dism_path,
                f"/Image:{target_path}",
                "/Set-Edition",
                f"/{target_edition}"
            ]

            logger.info(f"Setting edition: {' '.join(cmd)}")

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=600  # 10 minutes timeout
            )

            if result.returncode == 0:
                logger.info(f"Edition set to {target_edition}")
                return True, f"Edition set to {target_edition}"
            else:
                logger.error(f"DISM set-edition failed: {result.stderr}")
                return False, f"DISM error: {result.stderr[:500]}"

        except subprocess.TimeoutExpired:
            return False, "DISM set-edition timeout"
        except Exception as e:
            logger.error(f"Error setting edition: {e}")
            return False, f"Exception: {str(e)}"
