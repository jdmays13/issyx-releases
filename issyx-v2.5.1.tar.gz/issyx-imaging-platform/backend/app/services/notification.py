"""
Notification Service

Handles sending notifications via multiple channels: Email, Webhook, Slack, Teams, In-app.
"""
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from typing import List, Dict, Optional
from ..models.notification import (
    NotificationConfig, NotificationHistory,
    NotificationType, NotificationEvent
)
from ..models.user import User, UserStatus
import logging
import uuid
import aiohttp
import json

logger = logging.getLogger(__name__)


class NotificationService:
    """
    Service for sending multi-channel notifications.
    """

    def __init__(self, db: Session):
        self.db = db

    async def send_notification(
        self,
        event_type: NotificationEvent,
        subject: str,
        message: str,
        user_id: str = None,
        job_id: str = None,
        device_mac: str = None,
        metadata: Dict = None
    ) -> List[NotificationHistory]:
        """
        Send notification to all subscribed users.

        Args:
            event_type: Type of event triggering notification
            subject: Notification subject/title
            message: Notification message body
            user_id: Specific user to notify (optional, otherwise all subscribed users)
            job_id: Related job ID (optional)
            device_mac: Related device MAC (optional)
            metadata: Additional context data

        Returns:
            List of NotificationHistory records
        """
        notifications_sent = []

        # Get users to notify
        if user_id:
            users = [self.db.query(User).filter(User.id == user_id).first()]
        else:
            users = self.db.query(User).filter(User.status == UserStatus.ACTIVE).all()

        for user in users:
            if not user:
                continue

            # Get user's notification config
            config = self.db.query(NotificationConfig).filter(
                NotificationConfig.user_id == user.id,
                NotificationConfig.is_active == True
            ).first()

            if not config:
                logger.debug(f"No notification config for user {user.id}, skipping")
                continue

            # Check if user is subscribed to this event
            if not self._is_subscribed(config, event_type):
                logger.debug(f"User {user.id} not subscribed to {event_type}, skipping")
                continue

            # Check rate limiting
            if self._is_rate_limited(config, user.id):
                logger.warning(f"User {user.id} is rate limited, skipping notification")
                continue

            # Check business hours
            if not self._is_business_hours(config):
                logger.debug(f"Outside business hours for user {user.id}, skipping")
                continue

            # Send via enabled channels
            if config.email_enabled and config.email_address:
                notification = await self._send_email(
                    config, user, event_type, subject, message,
                    job_id, device_mac, metadata
                )
                if notification:
                    notifications_sent.append(notification)

            if config.webhook_enabled and config.webhook_url:
                notification = await self._send_webhook(
                    config, user, event_type, subject, message,
                    job_id, device_mac, metadata
                )
                if notification:
                    notifications_sent.append(notification)

            if config.in_app_enabled:
                notification = await self._send_in_app(
                    config, user, event_type, subject, message,
                    job_id, device_mac, metadata
                )
                if notification:
                    notifications_sent.append(notification)

        logger.info(f"Sent {len(notifications_sent)} notifications for event {event_type}")
        return notifications_sent

    async def _send_email(
        self,
        config: NotificationConfig,
        user: User,
        event_type: NotificationEvent,
        subject: str,
        message: str,
        job_id: str,
        device_mac: str,
        metadata: Dict
    ) -> NotificationHistory:
        """Send email notification"""
        notification = NotificationHistory(
            id=str(uuid.uuid4()),
            user_id=user.id,
            config_id=config.id,
            notification_type=NotificationType.EMAIL,
            event_type=event_type,
            subject=subject,
            message=message,
            job_id=job_id,
            device_mac=device_mac,
            status="queued",
            metadata=metadata
        )

        try:
            # In production, integrate with email service (SendGrid, AWS SES, etc.)
            # For now, just log
            logger.info(
                f"Email notification queued for {config.email_address}: {subject}"
            )

            # Simulate email sending
            notification.status = "sent"
            notification.delivered_at = datetime.now()

        except Exception as e:
            logger.error(f"Failed to send email notification: {e}")
            notification.status = "failed"
            notification.error_message = str(e)

        self.db.add(notification)
        self.db.commit()

        return notification

    async def _send_webhook(
        self,
        config: NotificationConfig,
        user: User,
        event_type: NotificationEvent,
        subject: str,
        message: str,
        job_id: str,
        device_mac: str,
        metadata: Dict
    ) -> NotificationHistory:
        """Send webhook notification (Slack, Teams, or custom)"""
        notification = NotificationHistory(
            id=str(uuid.uuid4()),
            user_id=user.id,
            config_id=config.id,
            notification_type=NotificationType.WEBHOOK,
            event_type=event_type,
            subject=subject,
            message=message,
            job_id=job_id,
            device_mac=device_mac,
            status="queued",
            metadata=metadata
        )

        try:
            # Format payload based on webhook type
            if config.webhook_type == "slack":
                payload = self._format_slack_message(subject, message, event_type, metadata)
            elif config.webhook_type == "teams":
                payload = self._format_teams_message(subject, message, event_type, metadata)
            else:
                payload = {
                    "event": event_type.value,
                    "subject": subject,
                    "message": message,
                    "job_id": job_id,
                    "device_mac": device_mac,
                    "timestamp": datetime.now().isoformat(),
                    **(metadata or {})
                }

            # Send webhook
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    config.webhook_url,
                    json=payload,
                    headers={"Content-Type": "application/json"},
                    timeout=aiohttp.ClientTimeout(total=10)
                ) as response:
                    if response.status == 200:
                        notification.status = "sent"
                        notification.delivered_at = datetime.now()
                        logger.info(f"Webhook notification sent to {config.webhook_url}")
                    else:
                        notification.status = "failed"
                        notification.error_message = f"HTTP {response.status}"
                        logger.error(f"Webhook failed with status {response.status}")

        except Exception as e:
            logger.error(f"Failed to send webhook notification: {e}")
            notification.status = "failed"
            notification.error_message = str(e)

        self.db.add(notification)
        self.db.commit()

        return notification

    async def _send_in_app(
        self,
        config: NotificationConfig,
        user: User,
        event_type: NotificationEvent,
        subject: str,
        message: str,
        job_id: str,
        device_mac: str,
        metadata: Dict
    ) -> NotificationHistory:
        """Send in-app notification (stored in database, shown in UI)"""
        notification = NotificationHistory(
            id=str(uuid.uuid4()),
            user_id=user.id,
            config_id=config.id,
            notification_type=NotificationType.IN_APP,
            event_type=event_type,
            subject=subject,
            message=message,
            job_id=job_id,
            device_mac=device_mac,
            status="sent",
            delivered_at=datetime.now(),
            metadata=metadata
        )

        self.db.add(notification)
        self.db.commit()

        logger.info(f"In-app notification created for user {user.id}")
        return notification

    def _format_slack_message(
        self,
        subject: str,
        message: str,
        event_type: NotificationEvent,
        metadata: Dict
    ) -> Dict:
        """Format message for Slack"""
        color_map = {
            "completed": "good",
            "failed": "danger",
            "started": "#439FE0",
            "discovered": "#439FE0"
        }

        # Determine color from event type
        event_str = event_type.value
        color = "good"
        if "failed" in event_str:
            color = "danger"
        elif "completed" in event_str:
            color = "good"
        else:
            color = "#439FE0"

        return {
            "text": subject,
            "attachments": [
                {
                    "color": color,
                    "text": message,
                    "footer": "Issyx Imaging Platform",
                    "ts": int(datetime.now().timestamp())
                }
            ]
        }

    def _format_teams_message(
        self,
        subject: str,
        message: str,
        event_type: NotificationEvent,
        metadata: Dict
    ) -> Dict:
        """Format message for Microsoft Teams"""
        return {
            "@type": "MessageCard",
            "@context": "https://schema.org/extensions",
            "summary": subject,
            "themeColor": "0078D7",
            "title": subject,
            "text": message,
            "potentialAction": []
        }

    def _is_subscribed(self, config: NotificationConfig, event_type: NotificationEvent) -> bool:
        """Check if user is subscribed to this event type"""
        if not config.event_subscriptions:
            return False

        return config.event_subscriptions.get(event_type.value, False)

    def _is_rate_limited(self, config: NotificationConfig, user_id: str) -> bool:
        """Check if user has exceeded notification rate limit"""
        if not config.max_notifications_per_hour:
            return False

        max_per_hour = int(config.max_notifications_per_hour)
        one_hour_ago = datetime.now() - timedelta(hours=1)

        recent_count = self.db.query(NotificationHistory).filter(
            NotificationHistory.user_id == user_id,
            NotificationHistory.sent_at >= one_hour_ago
        ).count()

        return recent_count >= max_per_hour

    def _is_business_hours(self, config: NotificationConfig) -> bool:
        """Check if current time is within business hours"""
        if not config.notify_business_hours_only:
            return True

        now = datetime.now()
        current_time = now.strftime("%H:%M")

        start = config.business_hours_start or "09:00"
        end = config.business_hours_end or "17:00"

        return start <= current_time <= end

    async def get_user_notifications(
        self,
        user_id: str,
        unread_only: bool = False,
        limit: int = 50
    ) -> List[NotificationHistory]:
        """Get notifications for a user (for in-app notification inbox)"""
        query = self.db.query(NotificationHistory).filter(
            NotificationHistory.user_id == user_id,
            NotificationHistory.notification_type == NotificationType.IN_APP
        )

        if unread_only:
            query = query.filter(NotificationHistory.read_at.is_(None))

        notifications = query.order_by(
            NotificationHistory.sent_at.desc()
        ).limit(limit).all()

        return notifications

    async def mark_as_read(self, notification_id: str, user_id: str):
        """Mark notification as read"""
        notification = self.db.query(NotificationHistory).filter(
            NotificationHistory.id == notification_id,
            NotificationHistory.user_id == user_id
        ).first()

        if notification:
            notification.read_at = datetime.now()
            self.db.commit()
            logger.info(f"Notification {notification_id} marked as read")
