"""
Job Scheduler Service

Handles execution of scheduled and recurring jobs.
Uses APScheduler for cron-based scheduling.
"""
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from ..core.database import get_db
from ..models.job import Job, JobStatus
from ..routes.websocket import send_job_update_to_user, broadcast_job_update
import logging

logger = logging.getLogger(__name__)

# Global scheduler instance
scheduler = AsyncIOScheduler()


def parse_cron_pattern(pattern: str) -> dict:
    """
    Parse cron pattern into APScheduler kwargs.
    Format: minute hour day month day_of_week
    Example: "0 2 * * *" = Daily at 2:00 AM
    """
    parts = pattern.split()
    if len(parts) != 5:
        raise ValueError("Invalid cron pattern. Expected format: 'minute hour day month day_of_week'")

    return {
        'minute': parts[0],
        'hour': parts[1],
        'day': parts[2],
        'month': parts[3],
        'day_of_week': parts[4]
    }


async def execute_scheduled_job(job_id: str, db: Session):
    """
    Execute a scheduled job.
    This function is called by the scheduler when a job is due to run.
    """
    try:
        job = db.query(Job).filter(Job.id == job_id).first()
        if not job:
            logger.error(f"Job {job_id} not found")
            return

        # Update job status to QUEUED (ready to be picked up by worker)
        job.status = JobStatus.QUEUED
        job.last_run_at = datetime.now()

        # If recurring, calculate next run time
        if job.is_recurring and job.recurrence_pattern:
            try:
                cron_kwargs = parse_cron_pattern(job.recurrence_pattern)
                trigger = CronTrigger(**cron_kwargs)
                job.next_run_at = trigger.get_next_fire_time(None, datetime.now())
            except Exception as e:
                logger.error(f"Failed to calculate next run time for job {job_id}: {e}")
        else:
            # One-time scheduled job - clear next_run_at
            job.next_run_at = None

        db.commit()

        # Broadcast job status update via WebSocket
        await broadcast_job_update(
            job_id=job.id,
            status=job.status.value,
            progress=0,
            message="Job moved to queue for execution"
        )

        logger.info(f"Job {job_id} moved to queue for execution")

    except Exception as e:
        logger.error(f"Error executing scheduled job {job_id}: {e}")
        db.rollback()


async def schedule_job(job: Job, db: Session):
    """
    Schedule a job for future execution.
    """
    if not job.scheduled_for:
        logger.warning(f"Job {job.id} has no scheduled_for time")
        return

    # Remove existing schedule if any
    if scheduler.get_job(job.id):
        scheduler.remove_job(job.id)

    # Schedule the job
    if job.is_recurring and job.recurrence_pattern:
        # Recurring job - use cron trigger
        try:
            cron_kwargs = parse_cron_pattern(job.recurrence_pattern)
            scheduler.add_job(
                execute_scheduled_job,
                trigger=CronTrigger(**cron_kwargs),
                args=[job.id, db],
                id=job.id,
                replace_existing=True,
                name=f"Job {job.id} - Recurring"
            )
            logger.info(f"Scheduled recurring job {job.id} with pattern {job.recurrence_pattern}")
        except Exception as e:
            logger.error(f"Failed to schedule recurring job {job.id}: {e}")
    else:
        # One-time scheduled job - use date trigger
        scheduler.add_job(
            execute_scheduled_job,
            trigger='date',
            run_date=job.scheduled_for,
            args=[job.id, db],
            id=job.id,
            replace_existing=True,
            name=f"Job {job.id} - One-time"
        )
        logger.info(f"Scheduled one-time job {job.id} for {job.scheduled_for}")


async def cancel_scheduled_job(job_id: str):
    """
    Cancel a scheduled job.
    """
    try:
        if scheduler.get_job(job_id):
            scheduler.remove_job(job_id)
            logger.info(f"Cancelled scheduled job {job_id}")
    except Exception as e:
        logger.error(f"Error cancelling scheduled job {job_id}: {e}")


async def reschedule_job(job: Job, db: Session):
    """
    Reschedule an existing job with new schedule.
    """
    await cancel_scheduled_job(job.id)
    await schedule_job(job, db)


async def load_scheduled_jobs(db: Session):
    """
    Load all scheduled jobs from database on startup.
    """
    try:
        # Get all scheduled jobs that haven't run yet or are recurring
        scheduled_jobs = db.query(Job).filter(
            Job.status == JobStatus.SCHEDULED
        ).all()

        for job in scheduled_jobs:
            await schedule_job(job, db)

        logger.info(f"Loaded {len(scheduled_jobs)} scheduled jobs")

    except Exception as e:
        logger.error(f"Error loading scheduled jobs: {e}")


def start_scheduler():
    """
    Start the job scheduler.
    Should be called on application startup.
    """
    if not scheduler.running:
        scheduler.start()
        logger.info("Job scheduler started")


def shutdown_scheduler():
    """
    Shutdown the job scheduler.
    Should be called on application shutdown.
    """
    if scheduler.running:
        scheduler.shutdown()
        logger.info("Job scheduler shutdown")
