"""
Imaging Instruction Generator Service

Generates step-by-step DISM commands and imaging instructions for WinPE devices.
Converts high-level job/profile configuration into executable PowerShell commands.
"""
from sqlalchemy.orm import Session
from typing import Dict, List, Any, Optional
from ..models.job import Job, JobDevice
from ..models.master_profile import MasterProfile, DriverMode, WindowsUpdates
from ..models.operating_system import OperatingSystem
from ..models.driver import Driver
from ..services.driver_smart_match import DriverSmartMatcher
import logging

logger = logging.getLogger(__name__)


class DeviceInstructionGenerator:
    """
    Generates imaging instructions for WinPE PowerShell clients.

    Converts job/profile configuration into executable steps:
    - Disk partitioning (DiskPart commands)
    - Image application (DISM apply-image)
    - Driver injection (DISM add-driver)
    - Software installation (MSI/EXE commands)
    - Script execution
    """

    def __init__(self, db: Session):
        self.db = db
        self.driver_matcher = DriverSmartMatcher(db)

    def generate_next_instruction(
        self,
        job: Job,
        device: JobDevice,
        api_base_url: str
    ) -> Optional[Dict[str, Any]]:
        """
        Generate the next imaging instruction for a device.

        Returns the next step in the imaging sequence, or None if complete.

        Args:
            job: The job this device belongs to
            device: The device being imaged
            api_base_url: Base URL for downloading files (e.g., "http://10.0.0.1:8000")

        Returns:
            Instruction dict with step info and actions, or None if imaging complete
        """
        # Get current progress to determine next step
        current_progress = device.progress or 0

        # Get master profile
        profile = self.db.query(MasterProfile).filter(
            MasterProfile.id == job.profile_id
        ).first()

        if not profile:
            raise ValueError(f"Profile {job.profile_id} not found")

        # Determine next step based on current progress
        if current_progress < 5:
            return self._generate_disk_prep_instruction(job, device, profile, api_base_url)
        elif current_progress < 30:
            return self._generate_os_deployment_instruction(job, device, profile, api_base_url)
        elif current_progress < 40:
            return self._generate_naming_instruction(job, device, profile, api_base_url)
        elif current_progress < 65:
            return self._generate_driver_injection_instruction(job, device, profile, api_base_url)
        elif current_progress < 85:
            return self._generate_software_installation_instruction(job, device, profile, api_base_url)
        elif current_progress < 90:
            return self._generate_windows_updates_instruction(job, device, profile, api_base_url)
        elif current_progress < 95:
            return self._generate_script_execution_instruction(job, device, profile, api_base_url)
        elif current_progress < 100:
            return self._generate_finalization_instruction(job, device, profile, api_base_url)
        else:
            # Imaging complete
            return None

    def _generate_disk_prep_instruction(
        self,
        job: Job,
        device: JobDevice,
        profile: MasterProfile,
        api_base_url: str
    ) -> Dict[str, Any]:
        """Generate disk partitioning instructions (DiskPart)"""

        # Standard UEFI/GPT partitioning for modern Windows
        diskpart_commands = [
            "SELECT DISK 0",
            "CLEAN",
            "CONVERT GPT",
            "CREATE PARTITION EFI SIZE=100",
            "FORMAT QUICK FS=FAT32 LABEL=System",
            "ASSIGN LETTER=S",
            "CREATE PARTITION MSR SIZE=16",
            "CREATE PARTITION PRIMARY",
            "FORMAT QUICK FS=NTFS LABEL=Windows",
            "ASSIGN LETTER=C",
        ]

        return {
            "step": 1,
            "step_name": "Prepare Disk",
            "progress_start": 0,
            "progress_end": 5,
            "actions": [
                {
                    "type": "diskpart",
                    "description": "Partition and format disk for UEFI/GPT",
                    "commands": diskpart_commands,
                    "timeout_seconds": 60
                }
            ],
            "estimated_duration_seconds": 30
        }

    def _generate_os_deployment_instruction(
        self,
        job: Job,
        device: JobDevice,
        profile: MasterProfile,
        api_base_url: str
    ) -> Dict[str, Any]:
        """Generate OS image deployment instructions (DISM apply-image)"""

        # Get OS details
        os_image = self.db.query(OperatingSystem).filter(
            OperatingSystem.id == profile.os_id
        ).first()

        if not os_image:
            raise ValueError(f"Operating system {profile.os_id} not found")

        # Construct download URL for WIM file
        wim_url = f"{api_base_url}/api/v1/boot/os-images/{os_image.id}/install.wim"

        return {
            "step": 2,
            "step_name": "Deploy OS",
            "progress_start": 5,
            "progress_end": 30,
            "actions": [
                {
                    "type": "download",
                    "description": f"Download {os_image.name} WIM file",
                    "url": wim_url,
                    "destination": "X:\\install.wim",
                    "verify_hash": True,
                    "timeout_seconds": 1800  # 30 minutes for large WIM files
                },
                {
                    "type": "dism_apply_image",
                    "description": f"Apply {os_image.name} to C:\\",
                    "image_file": "X:\\install.wim",
                    "image_index": 1,  # Usually index 1 for install.wim
                    "target_drive": "C:\\",
                    "timeout_seconds": 1800
                },
                {
                    "type": "bcdboot",
                    "description": "Configure boot loader",
                    "commands": [
                        "bcdboot C:\\Windows /s S: /f UEFI"
                    ],
                    "timeout_seconds": 60
                }
            ],
            "estimated_duration_seconds": 900  # 15 minutes
        }

    def _generate_naming_instruction(
        self,
        job: Job,
        device: JobDevice,
        profile: MasterProfile,
        api_base_url: str
    ) -> Dict[str, Any]:
        """Generate computer naming instructions"""

        # Get naming configuration from profile
        system_config = profile.system_config or {}
        naming_config = system_config.get("naming", {})

        # Default naming if not configured
        computer_name = device.hostname or f"PC-{device.mac_address.replace(':', '')[-8:]}"

        # Check if profile has custom naming pattern
        if naming_config.get("pattern"):
            # Pattern could be: "WKS-{CUSTOMER}-{MAC}", "LAB-{SERIAL}", etc.
            pattern = naming_config["pattern"]
            computer_name = pattern.replace("{MAC}", device.mac_address.replace(":", "")[-8:])
            computer_name = computer_name.replace("{CUSTOMER}", job.customer_id or "DEFAULT")

        return {
            "step": 3,
            "step_name": "Apply Computer Naming",
            "progress_start": 30,
            "progress_end": 40,
            "actions": [
                {
                    "type": "rename_computer",
                    "description": f"Set computer name to {computer_name}",
                    "computer_name": computer_name,
                    "timeout_seconds": 30
                }
            ],
            "estimated_duration_seconds": 10
        }

    def _generate_driver_injection_instruction(
        self,
        job: Job,
        device: JobDevice,
        profile: MasterProfile,
        api_base_url: str
    ) -> Dict[str, Any]:
        """Generate driver injection instructions"""

        actions = []

        if profile.driver_mode == DriverMode.SMART:
            # Use hardware compatibility matching
            # In production, we'd get device hardware IDs from PXE boot data
            # For now, we'll inject common drivers

            # This would query the driver_smart_match service
            # matched_drivers = self.driver_matcher.match_drivers_for_device(device)

            # Placeholder: Get all drivers for now
            drivers = self.db.query(Driver).limit(10).all()

            for driver in drivers:
                driver_url = f"{api_base_url}/api/v1/drivers/{driver.id}/download"

                actions.append({
                    "type": "download",
                    "description": f"Download {driver.name}",
                    "url": driver_url,
                    "destination": f"X:\\Drivers\\{driver.id}.zip",
                    "verify_hash": True,
                    "timeout_seconds": 300
                })

                actions.append({
                    "type": "dism_add_driver",
                    "description": f"Inject {driver.name}",
                    "driver_path": f"X:\\Drivers\\{driver.id}",
                    "recurse": True,
                    "timeout_seconds": 300
                })

        elif profile.driver_mode == DriverMode.ALL:
            # Inject all drivers from library
            # This would be a bulk operation
            actions.append({
                "type": "download",
                "description": "Download all drivers",
                "url": f"{api_base_url}/api/v1/drivers/bundle/all",
                "destination": "X:\\Drivers\\all.zip",
                "verify_hash": True,
                "timeout_seconds": 600
            })

            actions.append({
                "type": "dism_add_driver",
                "description": "Inject all drivers",
                "driver_path": "X:\\Drivers\\all",
                "recurse": True,
                "timeout_seconds": 900
            })

        if not actions:
            # Skip driver injection if no drivers configured
            actions.append({
                "type": "skip",
                "description": "No drivers configured for injection",
                "timeout_seconds": 1
            })

        return {
            "step": 4,
            "step_name": "Inject Drivers",
            "progress_start": 40,
            "progress_end": 65,
            "actions": actions,
            "estimated_duration_seconds": len(actions) * 120  # ~2 min per driver
        }

    def _generate_software_installation_instruction(
        self,
        job: Job,
        device: JobDevice,
        profile: MasterProfile,
        api_base_url: str
    ) -> Dict[str, Any]:
        """Generate software installation instructions"""

        actions = []

        # Get software packages from profile
        if profile.software:
            for idx, software in enumerate(sorted(profile.software, key=lambda s: s.id)):
                software_url = f"{api_base_url}/api/v1/software/{software.id}/download"

                actions.append({
                    "type": "download",
                    "description": f"Download {software.name}",
                    "url": software_url,
                    "destination": f"X:\\Software\\{software.id}\\{software.filename}",
                    "verify_hash": True,
                    "timeout_seconds": 600
                })

                # Determine installation method based on file type
                if software.filename.lower().endswith(".msi"):
                    install_cmd = f"msiexec /i X:\\Software\\{software.id}\\{software.filename} /qn /norestart"
                else:
                    # Assume EXE with silent flag
                    install_cmd = f"X:\\Software\\{software.id}\\{software.filename} /S /silent"

                actions.append({
                    "type": "execute",
                    "description": f"Install {software.name}",
                    "command": install_cmd,
                    "timeout_seconds": 600
                })

        if not actions:
            actions.append({
                "type": "skip",
                "description": "No software packages configured",
                "timeout_seconds": 1
            })

        return {
            "step": 5,
            "step_name": "Install Software",
            "progress_start": 65,
            "progress_end": 85,
            "actions": actions,
            "estimated_duration_seconds": len(actions) * 180  # ~3 min per package
        }

    def _generate_windows_updates_instruction(
        self,
        job: Job,
        device: JobDevice,
        profile: MasterProfile,
        api_base_url: str
    ) -> Dict[str, Any]:
        """Generate Windows Update instructions"""

        actions = []

        if profile.windows_updates == WindowsUpdates.OFFLINE:
            # Offline updates via DISM
            actions.append({
                "type": "download",
                "description": "Download offline updates",
                "url": f"{api_base_url}/api/v1/updates/offline-bundle",
                "destination": "X:\\Updates\\offline.cab",
                "timeout_seconds": 600
            })

            actions.append({
                "type": "dism_add_package",
                "description": "Apply offline updates",
                "package_path": "X:\\Updates",
                "timeout_seconds": 900
            })

        elif profile.windows_updates == WindowsUpdates.WSUS:
            # Configure WSUS settings
            system_config = profile.system_config or {}
            wsus_server = system_config.get("wsus_server", "")

            actions.append({
                "type": "configure_wsus",
                "description": f"Configure WSUS server: {wsus_server}",
                "wsus_server": wsus_server,
                "timeout_seconds": 60
            })

        else:
            # POST_IMAGING or skip
            actions.append({
                "type": "skip",
                "description": "Windows updates will be applied post-imaging",
                "timeout_seconds": 1
            })

        return {
            "step": 6,
            "step_name": "Apply Windows Updates",
            "progress_start": 85,
            "progress_end": 90,
            "actions": actions,
            "estimated_duration_seconds": 300
        }

    def _generate_script_execution_instruction(
        self,
        job: Job,
        device: JobDevice,
        profile: MasterProfile,
        api_base_url: str
    ) -> Dict[str, Any]:
        """Generate post-imaging script execution instructions"""

        actions = []

        # Get post-imaging scripts from profile
        if profile.scripts:
            for script in profile.scripts:
                script_url = f"{api_base_url}/api/v1/scripts/{script.id}/download"

                actions.append({
                    "type": "download",
                    "description": f"Download {script.name}",
                    "url": script_url,
                    "destination": f"X:\\Scripts\\{script.id}.ps1",
                    "timeout_seconds": 60
                })

                actions.append({
                    "type": "execute_powershell",
                    "description": f"Execute {script.name}",
                    "script_path": f"X:\\Scripts\\{script.id}.ps1",
                    "timeout_seconds": 600
                })

        if not actions:
            actions.append({
                "type": "skip",
                "description": "No post-imaging scripts configured",
                "timeout_seconds": 1
            })

        return {
            "step": 7,
            "step_name": "Execute Scripts",
            "progress_start": 90,
            "progress_end": 95,
            "actions": actions,
            "estimated_duration_seconds": len(actions) * 120
        }

    def _generate_finalization_instruction(
        self,
        job: Job,
        device: JobDevice,
        profile: MasterProfile,
        api_base_url: str
    ) -> Dict[str, Any]:
        """Generate finalization instructions"""

        return {
            "step": 8,
            "step_name": "Finalize",
            "progress_start": 95,
            "progress_end": 100,
            "actions": [
                {
                    "type": "cleanup",
                    "description": "Clean up temporary files",
                    "paths": ["X:\\Drivers", "X:\\Software", "X:\\Scripts", "X:\\Updates"],
                    "timeout_seconds": 60
                },
                {
                    "type": "complete",
                    "description": "Mark imaging as complete",
                    "reboot": True,
                    "timeout_seconds": 10
                }
            ],
            "estimated_duration_seconds": 30
        }
