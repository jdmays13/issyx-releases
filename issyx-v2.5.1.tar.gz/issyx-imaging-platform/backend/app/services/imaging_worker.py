"""
Imaging Execution Worker Service

Handles the actual device imaging process, including:
- Image deployment via PXE/iPXE
- Driver injection
- Software installation
- Script execution
- Progress tracking and error handling
- Device retry logic (max 3 retries)
"""
from sqlalchemy.orm import Session
from sqlalchemy import and_
from datetime import datetime, timedelta
from ..models.job import Job, JobDevice, JobStatus, DeviceStatus
from ..models.master_profile import MasterProfile
from ..models.notification import NotificationEvent
from ..routes.websocket import broadcast_job_update
from ..services.notification import NotificationService
from ..services.script_executor import ScriptExecutor
import logging
import asyncio
import os

logger = logging.getLogger(__name__)


class ImagingWorker:
    """
    Worker class for executing imaging jobs on devices.
    Runs as a background task processing devices in running jobs.
    """

    def __init__(self, db: Session):
        self.db = db
        self.max_retries = 3
        self.running = False
        self.script_executor = ScriptExecutor(db)

    async def start(self):
        """Start the imaging worker background task"""
        self.running = True
        logger.info("Imaging Worker started")

        while self.running:
            try:
                await self.process_jobs()
                await asyncio.sleep(5)  # Check for work every 5 seconds
            except Exception as e:
                logger.error(f"Error in imaging worker main loop: {e}")
                await asyncio.sleep(5)

    async def stop(self):
        """Stop the imaging worker"""
        self.running = False
        logger.info("Imaging Worker stopped")

    async def process_jobs(self):
        """
        Process all running jobs and their queued devices.

        For each running job:
        1. Find devices in QUEUED status
        2. Start imaging process for each device
        3. Track progress and handle errors
        4. Update job rollup statistics
        """
        # Get all running jobs
        running_jobs = self.db.query(Job).filter(
            Job.status == JobStatus.RUNNING
        ).all()

        for job in running_jobs:
            await self.process_job_devices(job)

    async def process_job_devices(self, job: Job):
        """
        Process devices for a specific job.

        Handles concurrent device imaging with progress tracking.
        """
        # Get queued devices for this job
        queued_devices = self.db.query(JobDevice).filter(
            and_(
                JobDevice.job_id == job.id,
                JobDevice.status == DeviceStatus.QUEUED
            )
        ).all()

        # Process each queued device (in production, this would be concurrent)
        for device in queued_devices:
            try:
                await self.image_device(job, device)
            except Exception as e:
                logger.error(f"Error imaging device {device.mac_address}: {e}")
                await self.handle_device_error(job, device, str(e))

        # Update job rollup after processing devices
        await self.update_job_status(job)

    async def image_device(self, job: Job, device: JobDevice):
        """
        Execute the imaging process for a single device.

        Steps:
        1. Mark device as RUNNING
        2. Deploy base image via PXE/iPXE
        3. Inject drivers (based on profile settings)
        4. Install software packages
        5. Execute scripts (pre/post)
        6. Mark device as SUCCEEDED
        7. Update progress via WebSocket
        """
        try:
            # Mark device as running
            device.status = DeviceStatus.RUNNING
            device.started_at = datetime.now()
            device.progress = 0
            device.current_step = "Starting imaging process"

            job.in_progress += 1

            self.db.commit()

            # Broadcast initial status
            await broadcast_job_update(
                job_id=job.id,
                status=job.status.value,
                progress=self._calculate_job_progress(job),
                message=f"Device {device.hostname or device.mac_address} started imaging"
            )

            # Get master profile configuration
            profile = self.db.query(MasterProfile).filter(
                MasterProfile.id == job.profile_id
            ).first()

            if not profile:
                raise ValueError(f"Profile {job.profile_id} not found")

            # Step 1: Deploy base image
            await self._deploy_base_image(job, device, profile)

            # Step 2: Inject drivers
            await self._inject_drivers(job, device, profile)

            # Step 3: Install software
            await self._install_software(job, device, profile)

            # Step 4: Apply Windows Updates
            await self._apply_windows_updates(job, device, profile)

            # Step 5: Execute post-imaging scripts
            await self._execute_scripts(job, device, profile)

            # Step 6: Finalize and mark as succeeded
            device.status = DeviceStatus.SUCCEEDED
            device.completed_at = datetime.now()
            device.progress = 100
            device.current_step = "Imaging completed successfully"
            device.duration = self._calculate_duration(device.started_at, device.completed_at)

            # Update job counters
            job.in_progress -= 1
            job.succeeded += 1

            self.db.commit()

            # Broadcast completion
            await broadcast_job_update(
                job_id=job.id,
                status=job.status.value,
                progress=self._calculate_job_progress(job),
                message=f"Device {device.hostname or device.mac_address} completed successfully"
            )

            # Send device completion notification
            await self._send_device_notification(
                job=job,
                device=device,
                event_type=NotificationEvent.DEVICE_IMAGING_COMPLETED,
                subject=f"Device Imaging Completed: {device.hostname or device.mac_address}",
                message=f"Device '{device.hostname or device.mac_address}' imaging completed successfully in {device.duration}."
            )

            logger.info(f"Device {device.mac_address} imaging completed successfully")

        except Exception as e:
            logger.error(f"Error during imaging for device {device.mac_address}: {e}")
            await self.handle_device_error(job, device, str(e))

    async def handle_device_error(self, job: Job, device: JobDevice, error_message: str):
        """
        Handle device imaging failure with retry logic.

        Retry policy:
        - Max 3 retries per device
        - If retries exhausted, mark as FAILED
        - Update job rollup counters
        """
        device.retries += 1
        device.error_message = error_message

        if device.retries < self.max_retries:
            # Retry: reset to QUEUED
            device.status = DeviceStatus.QUEUED
            device.current_step = f"Retry {device.retries}/{self.max_retries} - {error_message}"

            logger.warning(f"Device {device.mac_address} failed, retry {device.retries}/{self.max_retries}")

            await broadcast_job_update(
                job_id=job.id,
                status=job.status.value,
                progress=self._calculate_job_progress(job),
                message=f"Device {device.hostname or device.mac_address} failed, retrying ({device.retries}/{self.max_retries})"
            )

        else:
            # Max retries exhausted, mark as FAILED
            device.status = DeviceStatus.FAILED
            device.completed_at = datetime.now()
            device.current_step = f"Failed after {self.max_retries} retries"
            device.duration = self._calculate_duration(device.started_at, device.completed_at)

            # Update job counters
            if job.in_progress > 0:
                job.in_progress -= 1
            job.failed += 1

            logger.error(f"Device {device.mac_address} failed after {self.max_retries} retries")

            await broadcast_job_update(
                job_id=job.id,
                status=job.status.value,
                progress=self._calculate_job_progress(job),
                message=f"Device {device.hostname or device.mac_address} failed after {self.max_retries} retries"
            )

            # Send device failure notification
            await self._send_device_notification(
                job=job,
                device=device,
                event_type=NotificationEvent.DEVICE_IMAGING_FAILED,
                subject=f"Device Imaging Failed: {device.hostname or device.mac_address}",
                message=f"Device '{device.hostname or device.mac_address}' failed after {self.max_retries} retries. Error: {error_message}"
            )

        self.db.commit()

    async def update_job_status(self, job: Job):
        """
        Update job status based on device states (status rollup).

        Logic:
        - If all devices SUCCEEDED → Job SUCCEEDED
        - If any device RUNNING → Job RUNNING
        - If any device FAILED and no RUNNING → Job FAILED
        """
        devices = self.db.query(JobDevice).filter(
            JobDevice.job_id == job.id
        ).all()

        if not devices:
            return

        # Count device statuses
        total = len(devices)
        succeeded = sum(1 for d in devices if d.status == DeviceStatus.SUCCEEDED)
        failed = sum(1 for d in devices if d.status == DeviceStatus.FAILED)
        running = sum(1 for d in devices if d.status == DeviceStatus.RUNNING)
        queued = sum(1 for d in devices if d.status == DeviceStatus.QUEUED)

        # Store previous status for notification logic
        previous_status = job.status

        # Update job counters (should match device counts)
        job.total_devices = total
        job.succeeded = succeeded
        job.failed = failed
        job.in_progress = running

        # Determine job status
        if succeeded == total:
            # All devices succeeded
            job.status = JobStatus.SUCCEEDED
            job.completed_at = datetime.now()
            logger.info(f"Job {job.id} completed successfully")

            # Send job completion notification
            if previous_status != JobStatus.SUCCEEDED:
                await self._send_job_notification(
                    job=job,
                    event_type=NotificationEvent.JOB_COMPLETED,
                    subject=f"Job Completed: {job.name}",
                    message=f"Job '{job.name}' completed successfully. {succeeded}/{total} devices succeeded."
                )

        elif failed > 0 and running == 0 and queued == 0:
            # Some devices failed, none running or queued
            job.status = JobStatus.FAILED
            job.completed_at = datetime.now()
            logger.warning(f"Job {job.id} failed")

            # Send job failure notification
            if previous_status != JobStatus.FAILED:
                await self._send_job_notification(
                    job=job,
                    event_type=NotificationEvent.JOB_FAILED,
                    subject=f"Job Failed: {job.name}",
                    message=f"Job '{job.name}' failed. {succeeded}/{total} succeeded, {failed}/{total} failed."
                )

        elif running > 0 or queued > 0:
            # Still processing
            job.status = JobStatus.RUNNING

        self.db.commit()

        # Broadcast job status update
        await broadcast_job_update(
            job_id=job.id,
            status=job.status.value,
            progress=self._calculate_job_progress(job),
            message=f"Job status updated: {job.status.value}"
        )

    # Imaging step implementations (placeholders for actual PXE/imaging logic)

    async def _deploy_base_image(self, job: Job, device: JobDevice, profile: MasterProfile):
        """
        Deploy OS image via DISM.

        Note: In real deployment, this is executed BY THE WINPE CLIENT, not by this backend.
        This method documents the DISM commands that should be used by the WinPE PowerShell client.

        The WinPE client will:
        1. Download the OS WIM file from the API
        2. Partition and format the target disk
        3. Apply the WIM using DISM /Apply-Image
        4. Configure boot files with bcdboot
        """
        device.progress = 10
        device.current_step = "Deploying base OS image"
        self.db.commit()

        await broadcast_job_update(
            job_id=job.id,
            status=job.status.value,
            progress=self._calculate_job_progress(job),
            message=f"Device {device.hostname or device.mac_address}: Deploying base image"
        )

        # Get OS information from profile
        if not profile.operating_system:
            raise ValueError(f"No operating system configured in profile {profile.id}")

        os_info = profile.operating_system
        logger.info(
            f"Device {device.mac_address}: Deploying {os_info.name} "
            f"(Edition: {os_info.edition}, Build: {os_info.build_number})"
        )

        # In production, the WinPE client polls the API for imaging instructions
        # and executes DISM commands locally on the target device.
        # The backend tracks progress via API calls from the WinPE client.

        # For development/testing, we simulate the deployment
        device.progress = 20
        device.current_step = f"Applying {os_info.name} image"
        self.db.commit()

        # Real DISM commands that would be executed by WinPE client:
        # 1. diskpart /s diskpart.txt (partition and format)
        # 2. dism /Apply-Image /ImageFile:install.wim /Index:1 /ApplyDir:C:\ /Verify
        # 3. bcdboot C:\Windows /s S: (configure boot)

        await asyncio.sleep(2)  # Simulate imaging time

        device.progress = 30
        device.current_step = "Base image deployed"
        self.db.commit()

        # Apply computer naming if configured in profile
        await self._apply_computer_naming(job, device, profile)

        device.progress = 40
        device.current_step = "System configuration applied"
        self.db.commit()

        logger.info(f"Device {device.mac_address}: Base image deployed")

    async def _inject_drivers(self, job: Job, device: JobDevice, profile: MasterProfile):
        """
        Inject drivers based on profile settings.

        Driver deployment modes:
        - Smart: Use smart hardware detection to match drivers
        - Profile: Use drivers from assigned driver profile

        Note: In real deployment, driver injection is performed by the WinPE client using:
        dism /Image:C:\ /Add-Driver /Driver:D:\Drivers /Recurse /ForceUnsigned

        The WinPE client will:
        1. Call API to get list of drivers for this device
        2. Download driver packages from /api/v1/boot/drivers/{driver_id}/{filename}
        3. Extract drivers to temp directory
        4. Inject using DISM /Add-Driver
        """
        device.progress = 50
        device.current_step = "Injecting drivers"
        self.db.commit()

        await broadcast_job_update(
            job_id=job.id,
            status=job.status.value,
            progress=self._calculate_job_progress(job),
            message=f"Device {device.hostname or device.mac_address}: Injecting drivers"
        )

        # Determine driver deployment mode from profile
        driver_mode = profile.driver_mode if hasattr(profile, 'driver_mode') else 'Smart'

        driver_count = 0

        if driver_mode == 'Smart':
            # Use smart driver detection
            try:
                from ..services.driver_smart_match import DriverSmartMatcher
                matcher = DriverSmartMatcher(self.db)

                # Get matched drivers for this device
                drivers = matcher.get_drivers_for_device(
                    device_mac=device.mac_address,
                    confidence_threshold="medium"
                )

                if drivers:
                    driver_count = len(drivers)
                    logger.info(
                        f"Device {device.mac_address}: Smart driver matching found {driver_count} drivers"
                    )
                    device.current_step = f"Injecting {driver_count} smart-matched drivers"
                    self.db.commit()

                    # Real DISM commands executed by WinPE client for each driver:
                    # dism /Image:C:\ /Add-Driver /Driver:X:\Drivers\{driver_id} /Recurse /ForceUnsigned
                else:
                    logger.warning(
                        f"Device {device.mac_address}: No drivers matched via smart detection, "
                        "falling back to profile drivers"
                    )
                    driver_mode = 'Profile'  # Fallback
            except Exception as e:
                logger.error(f"Smart driver matching failed: {e}, falling back to profile drivers")
                driver_mode = 'Profile'  # Fallback

        if driver_mode == 'Profile' and profile.driver_profile:
            # Use drivers from assigned driver profile
            driver_count = len(profile.driver_profile.drivers) if profile.driver_profile.drivers else 0
            logger.info(
                f"Device {device.mac_address}: Using {driver_count} drivers from profile {profile.driver_profile_id}"
            )

        # Simulate driver injection (in production, WinPE client executes DISM)
        await asyncio.sleep(1)

        device.progress = 65
        device.current_step = f"Drivers injected ({driver_count} drivers, {driver_mode} mode)"
        self.db.commit()

        logger.info(f"Device {device.mac_address}: Drivers injected using {driver_mode} mode")

    async def _install_software(self, job: Job, device: JobDevice, profile: MasterProfile):
        """
        Install software packages based on profile configuration.

        Installs software in order specified by install_order.
        Retries failed installs once before skipping.
        Logs all installation attempts and failures.
        """
        device.progress = 70
        device.current_step = "Installing software packages"
        self.db.commit()

        await broadcast_job_update(
            job_id=job.id,
            status=job.status.value,
            progress=self._calculate_job_progress(job),
            message=f"Device {device.hostname or device.mac_address}: Installing software"
        )

        # Get software packages from profile, ordered by install_order
        from sqlalchemy import select
        from ..models.master_profile import master_profile_software
        from ..models.software import SoftwareCatalog

        # Query software with install order
        stmt = (
            select(SoftwareCatalog, master_profile_software.c.install_order)
            .join(master_profile_software, SoftwareCatalog.id == master_profile_software.c.software_id)
            .where(master_profile_software.c.profile_id == profile.id)
            .order_by(master_profile_software.c.install_order)
        )

        result = self.db.execute(stmt).all()
        software_list = [(row[0], row[1]) for row in result]  # (SoftwareCatalog, install_order)

        if not software_list:
            logger.info(f"Device {device.mac_address}: No software configured in profile")
            device.progress = 85
            device.current_step = "No software to install"
            self.db.commit()
            return

        # Install each software package
        from ..utils.software_installer import SoftwareInstaller
        installer = SoftwareInstaller(max_retries=1)

        total_software = len(software_list)
        installed_count = 0
        failed_software = []

        for idx, (software, install_order) in enumerate(software_list, 1):
            try:
                device.current_step = f"Installing software {idx}/{total_software}: {software.name}"
                self.db.commit()

                await broadcast_job_update(
                    job_id=job.id,
                    status=job.status.value,
                    progress=self._calculate_job_progress(job),
                    message=f"Device {device.hostname or device.mac_address}: Installing {software.name}"
                )

                logger.info(
                    f"Device {device.mac_address}: Installing {software.name} v{software.version} "
                    f"({idx}/{total_software}, order={install_order})"
                )

                # Check if file exists
                if not software.file_path or not os.path.exists(software.file_path):
                    error_msg = f"Software file not found: {software.file_path}"
                    logger.error(f"Device {device.mac_address}: {error_msg}")
                    failed_software.append({
                        'name': software.name,
                        'version': software.version,
                        'error': error_msg
                    })
                    continue

                # Install the software with retry logic
                success, message = await installer.install_software(
                    file_path=software.file_path,
                    install_params=software.install_params,
                    software_name=f"{software.name} v{software.version}"
                )

                if success:
                    installed_count += 1
                    logger.info(
                        f"Device {device.mac_address}: {software.name} installed successfully - {message}"
                    )
                else:
                    logger.warning(
                        f"Device {device.mac_address}: {software.name} installation failed - {message}"
                    )
                    failed_software.append({
                        'name': software.name,
                        'version': software.version,
                        'error': message
                    })

                # Update progress proportionally
                progress_increment = 15 / total_software  # Software takes 70-85% range
                device.progress = int(70 + (idx * progress_increment))
                self.db.commit()

            except Exception as e:
                error_msg = f"Exception installing {software.name}: {str(e)}"
                logger.error(f"Device {device.mac_address}: {error_msg}")
                failed_software.append({
                    'name': software.name,
                    'version': software.version,
                    'error': error_msg
                })

        # Set final status message
        if failed_software:
            failed_names = ", ".join([f"{s['name']}" for s in failed_software])
            device.current_step = (
                f"Software installation completed with failures: {installed_count}/{total_software} successful. "
                f"Failed: {failed_names}"
            )
            logger.warning(
                f"Device {device.mac_address}: Software installation completed with {len(failed_software)} failures"
            )

            # Log detailed failure information
            for failed in failed_software:
                logger.error(
                    f"Device {device.mac_address}: FAILED - {failed['name']} v{failed['version']}: {failed['error']}"
                )
        else:
            device.current_step = f"All software installed successfully ({installed_count}/{total_software})"
            logger.info(
                f"Device {device.mac_address}: All software installed successfully ({installed_count} packages)"
            )

        device.progress = 85
        self.db.commit()

    async def _apply_windows_updates(self, job: Job, device: JobDevice, profile: MasterProfile):
        """Apply Windows Updates based on profile settings"""
        # Check if Windows Updates are enabled in profile
        windows_update_mode = getattr(profile, 'windows_update_mode', None)

        if not windows_update_mode or windows_update_mode == "None":
            logger.info(f"Device {device.mac_address}: Windows Updates disabled in profile, skipping")
            return

        device.progress = 75
        device.current_step = f"Applying Windows Updates ({windows_update_mode} mode)"
        self.db.commit()

        await broadcast_job_update(
            job_id=job.id,
            status=job.status.value,
            progress=self._calculate_job_progress(job),
            message=f"Device {device.hostname or device.mac_address}: Applying Windows Updates"
        )

        try:
            from ..services.windows_update import WindowsUpdateService
            from ..models.windows_update import WindowsUpdateMode

            update_service = WindowsUpdateService(self.db)

            # Convert string mode to enum
            mode_map = {
                "Offline": WindowsUpdateMode.OFFLINE,
                "Online": WindowsUpdateMode.ONLINE,
                "WSUS": WindowsUpdateMode.WSUS
            }
            mode = mode_map.get(windows_update_mode, WindowsUpdateMode.ONLINE)

            # Apply updates
            update_config_id = getattr(profile, 'windows_update_config_id', None)
            update_log = await update_service.apply_updates(
                job_id=job.id,
                device=device,
                config_id=update_config_id,
                mode=mode
            )

            device.current_step = f"Windows Updates applied: {update_log.updates_installed} installed"
            logger.info(
                f"Device {device.mac_address}: Windows Updates completed - "
                f"{update_log.updates_installed}/{update_log.updates_found} installed"
            )

        except Exception as e:
            logger.error(f"Device {device.mac_address}: Windows Update failed: {e}")
            device.current_step = f"Windows Updates failed (continuing): {str(e)[:50]}"

        device.progress = 88
        self.db.commit()

    async def _execute_scripts(self, job: Job, device: JobDevice, profile: MasterProfile):
        """Execute post-imaging scripts with real script execution"""
        device.progress = 90
        device.current_step = "Executing post-imaging scripts"
        self.db.commit()

        await broadcast_job_update(
            job_id=job.id,
            status=job.status.value,
            progress=self._calculate_job_progress(job),
            message=f"Device {device.hostname or device.mac_address}: Executing scripts"
        )

        # Execute post-imaging scripts using ScriptExecutor
        try:
            script_results = await self.script_executor.execute_profile_scripts(
                profile=profile,
                device=device,
                phase="post"
            )

            # Log script results
            for script_name, success, output in script_results:
                if success:
                    logger.info(f"Device {device.mac_address}: Script '{script_name}' succeeded - {output}")
                else:
                    logger.warning(f"Device {device.mac_address}: Script '{script_name}' failed - {output}")

            # Update progress
            device.progress = 95
            device.current_step = f"Scripts executed ({len(script_results)} total)"
            self.db.commit()

            logger.info(f"Device {device.mac_address}: All scripts executed ({len(script_results)} total)")

        except Exception as e:
            logger.error(f"Device {device.mac_address}: Error executing scripts - {e}")
            device.current_step = f"Script execution error: {str(e)[:50]}"
            self.db.commit()

    async def _apply_computer_naming(self, job: Job, device: JobDevice, profile: MasterProfile):
        """
        Apply computer naming template from profile configuration.

        Uses the ScriptExecutor's generate_computer_name() to create a unique
        computer name based on the profile's system_config template.
        """
        try:
            # Check if profile has system configuration with computer naming template
            if not profile.system_config:
                logger.info(f"Device {device.mac_address}: No system_config in profile, skipping computer naming")
                return

            computer_name_template = profile.system_config.get('computerNameTemplate')

            if not computer_name_template:
                logger.info(f"Device {device.mac_address}: No computer name template configured, skipping")
                return

            # Generate computer name using the template
            computer_name = self.script_executor.generate_computer_name(
                template=computer_name_template,
                device=device,
                profile=profile
            )

            # Update device hostname with generated computer name
            device.hostname = computer_name
            device.current_step = f"Computer name set to: {computer_name}"
            self.db.commit()

            logger.info(f"Device {device.mac_address}: Computer name generated: {computer_name} (template: {computer_name_template})")

            await broadcast_job_update(
                job_id=job.id,
                status=job.status.value,
                progress=self._calculate_job_progress(job),
                message=f"Device computer name set to: {computer_name}"
            )

        except Exception as e:
            logger.error(f"Device {device.mac_address}: Error applying computer naming - {e}")
            device.current_step = f"Computer naming error (continuing): {str(e)[:50]}"
            self.db.commit()

    # Utility methods

    def _calculate_job_progress(self, job: Job) -> int:
        """Calculate overall job progress percentage"""
        if job.total_devices == 0:
            return 0

        completed = job.succeeded + job.failed
        return int((completed / job.total_devices) * 100)

    def _calculate_duration(self, started_at: datetime, completed_at: datetime) -> str:
        """Calculate duration string in HH:MM:SS format"""
        if not started_at or not completed_at:
            return "00:00:00"

        duration = completed_at - started_at
        hours, remainder = divmod(duration.total_seconds(), 3600)
        minutes, seconds = divmod(remainder, 60)

        return f"{int(hours):02d}:{int(minutes):02d}:{int(seconds):02d}"

    async def _send_job_notification(
        self,
        job: Job,
        event_type: NotificationEvent,
        subject: str,
        message: str
    ):
        """Send notification for job-level events"""
        try:
            notification_service = NotificationService(self.db)
            await notification_service.send_notification(
                event_type=event_type,
                subject=subject,
                message=message,
                job_id=job.id,
                metadata={
                    "job_name": job.name,
                    "total_devices": job.total_devices,
                    "succeeded": job.succeeded,
                    "failed": job.failed,
                    "customer_id": job.customer_id
                }
            )
        except Exception as e:
            logger.error(f"Failed to send job notification: {e}")

    async def _send_device_notification(
        self,
        job: Job,
        device: JobDevice,
        event_type: NotificationEvent,
        subject: str,
        message: str
    ):
        """Send notification for device-level events"""
        try:
            notification_service = NotificationService(self.db)
            await notification_service.send_notification(
                event_type=event_type,
                subject=subject,
                message=message,
                job_id=job.id,
                device_mac=device.mac_address,
                metadata={
                    "job_name": job.name,
                    "device_hostname": device.hostname,
                    "device_mac": device.mac_address,
                    "duration": device.duration,
                    "error_message": device.error_message
                }
            )
        except Exception as e:
            logger.error(f"Failed to send device notification: {e}")


# Global worker instance
_worker_instance = None


async def start_imaging_worker(db: Session):
    """Start the global imaging worker"""
    global _worker_instance

    if _worker_instance is None:
        _worker_instance = ImagingWorker(db)
        asyncio.create_task(_worker_instance.start())
        logger.info("Imaging worker task created")


async def stop_imaging_worker():
    """Stop the global imaging worker"""
    global _worker_instance

    if _worker_instance:
        await _worker_instance.stop()
        _worker_instance = None
        logger.info("Imaging worker stopped")
