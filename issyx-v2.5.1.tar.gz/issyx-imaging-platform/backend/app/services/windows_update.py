"""
Windows Update Service

Handles Windows Update deployment during imaging process.
Supports Offline, Online, and WSUS modes.
"""
from sqlalchemy.orm import Session
from datetime import datetime
from ..models.windows_update import WindowsUpdateConfig, WindowsUpdateLog, WindowsUpdateMode
from ..models.job import JobDevice
import logging
import uuid
import asyncio

logger = logging.getLogger(__name__)


class WindowsUpdateService:
    """
    Service for managing Windows Update deployment.
    """

    def __init__(self, db: Session):
        self.db = db

    async def apply_updates(
        self,
        job_id: str,
        device: JobDevice,
        config_id: str = None,
        mode: WindowsUpdateMode = None
    ) -> WindowsUpdateLog:
        """
        Apply Windows Updates to a device during imaging.

        Args:
            job_id: Job ID
            device: JobDevice being imaged
            config_id: Windows Update config to use (optional)
            mode: Override mode (optional)

        Returns:
            WindowsUpdateLog record
        """
        # Get configuration
        config = None
        if config_id:
            config = self.db.query(WindowsUpdateConfig).filter(
                WindowsUpdateConfig.id == config_id
            ).first()

        if not config:
            # Get default config
            config = self.db.query(WindowsUpdateConfig).filter(
                WindowsUpdateConfig.is_default == True
            ).first()

        if not config:
            logger.warning("No Windows Update config found, using defaults")
            config = self._get_default_config()

        # Override mode if specified
        update_mode = mode or config.mode

        # Create log entry
        log = WindowsUpdateLog(
            id=str(uuid.uuid4()),
            job_id=job_id,
            device_mac=device.mac_address,
            update_mode=update_mode,
            config_id=config.id if config else None,
            status="started"
        )
        self.db.add(log)
        self.db.commit()

        try:
            # Route to appropriate update method
            if update_mode == WindowsUpdateMode.OFFLINE:
                await self._apply_offline_updates(device, config, log)
            elif update_mode == WindowsUpdateMode.WSUS:
                await self._apply_wsus_updates(device, config, log)
            else:  # ONLINE
                await self._apply_online_updates(device, config, log)

            # Mark as completed
            log.status = "completed"
            log.completed_at = datetime.now()
            if log.started_at:
                log.duration_seconds = int((log.completed_at - log.started_at).total_seconds())

            self.db.commit()

            logger.info(
                f"Windows Update completed for {device.mac_address}: "
                f"{log.updates_installed}/{log.updates_found} updates installed"
            )

            return log

        except Exception as e:
            log.status = "failed"
            log.error_message = str(e)
            log.completed_at = datetime.now()
            self.db.commit()

            logger.error(f"Windows Update failed for {device.mac_address}: {e}")
            raise

    async def _apply_offline_updates(
        self,
        device: JobDevice,
        config: WindowsUpdateConfig,
        log: WindowsUpdateLog
    ):
        """Apply pre-downloaded offline update packages"""
        logger.info(f"Applying offline updates for {device.mac_address}")

        log.status = "installing"
        self.db.commit()

        # In production, this would:
        # 1. Mount offline update package path
        # 2. Apply .cab/.msu files in specified order
        # 3. Track installation progress

        # Simulate offline update installation
        await asyncio.sleep(2)

        log.updates_found = 15
        log.updates_installed = 15
        log.updates_failed = 0

        logger.info(f"Offline updates applied: 15 updates installed")

    async def _apply_online_updates(
        self,
        device: JobDevice,
        config: WindowsUpdateConfig,
        log: WindowsUpdateLog
    ):
        """Apply updates via Windows Update service"""
        logger.info(f"Applying online updates for {device.mac_address}")

        # Phase 1: Search for updates
        log.status = "searching"
        self.db.commit()

        await asyncio.sleep(1)

        # In production, this would:
        # 1. Use Windows Update API to search
        # 2. Filter based on config (security, critical, etc.)
        # 3. Download updates

        log.status = "downloading"
        log.updates_found = 25
        self.db.commit()

        await asyncio.sleep(2)

        log.updates_downloaded = 25

        # Phase 2: Install updates
        log.status = "installing"
        self.db.commit()

        await asyncio.sleep(2)

        log.updates_installed = 24
        log.updates_failed = 1
        log.reboot_required = True

        logger.info(f"Online updates applied: 24/25 updates installed")

    async def _apply_wsus_updates(
        self,
        device: JobDevice,
        config: WindowsUpdateConfig,
        log: WindowsUpdateLog
    ):
        """Apply updates via WSUS server"""
        logger.info(
            f"Applying WSUS updates for {device.mac_address} "
            f"from {config.wsus_server_url}:{config.wsus_server_port}"
        )

        # Phase 1: Configure WSUS client
        log.status = "configuring"
        self.db.commit()

        # In production, this would:
        # 1. Configure registry for WSUS server
        # 2. Set target group
        # 3. Trigger update check

        await asyncio.sleep(1)

        # Phase 2: Search WSUS for updates
        log.status = "searching"
        self.db.commit()

        await asyncio.sleep(1)

        log.updates_found = 18

        # Phase 3: Download from WSUS
        log.status = "downloading"
        self.db.commit()

        await asyncio.sleep(1)

        log.updates_downloaded = 18

        # Phase 4: Install updates
        log.status = "installing"
        self.db.commit()

        await asyncio.sleep(2)

        log.updates_installed = 18
        log.updates_failed = 0
        log.reboot_required = True

        logger.info(f"WSUS updates applied: 18 updates installed")

    def _get_default_config(self) -> WindowsUpdateConfig:
        """Get default Windows Update configuration"""
        return WindowsUpdateConfig(
            id="default",
            name="Default Configuration",
            mode=WindowsUpdateMode.ONLINE,
            online_include_recommended=True,
            online_auto_reboot=True,
            include_security_updates=True,
            include_critical_updates=True,
            exclude_preview_updates=True
        )

    async def get_update_status(
        self,
        job_id: str = None,
        device_mac: str = None
    ) -> list:
        """
        Get Windows Update status for job or device.

        Returns list of WindowsUpdateLog records.
        """
        query = self.db.query(WindowsUpdateLog)

        if job_id:
            query = query.filter(WindowsUpdateLog.job_id == job_id)

        if device_mac:
            query = query.filter(WindowsUpdateLog.device_mac == device_mac)

        return query.order_by(WindowsUpdateLog.started_at.desc()).all()

    async def retry_failed_updates(
        self,
        log_id: str
    ) -> WindowsUpdateLog:
        """Retry failed Windows Update operation"""
        log = self.db.query(WindowsUpdateLog).filter(
            WindowsUpdateLog.id == log_id
        ).first()

        if not log:
            raise ValueError(f"Update log {log_id} not found")

        if log.status != "failed":
            raise ValueError(f"Update log {log_id} is not in failed state")

        # Get device
        device = self.db.query(JobDevice).filter(
            JobDevice.mac_address == log.device_mac,
            JobDevice.job_id == log.job_id
        ).first()

        if not device:
            raise ValueError(f"Device not found for log {log_id}")

        # Retry
        log.retry_count += 1
        self.db.commit()

        return await self.apply_updates(
            job_id=log.job_id,
            device=device,
            config_id=log.config_id,
            mode=log.update_mode
        )
