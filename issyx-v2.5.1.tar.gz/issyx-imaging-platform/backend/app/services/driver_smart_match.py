"""
Driver Smart Matching Service

Automatically matches detected hardware to appropriate drivers.
Implements intelligent driver selection based on hardware IDs.
"""
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_
from typing import List, Dict, Optional, Tuple
from ..models.hardware_compatibility import HardwareCompatibility, DetectedHardware, generate_hardware_id
from ..models.driver import Driver
import logging
import uuid

logger = logging.getLogger(__name__)


class DriverSmartMatcher:
    """
    Service for matching hardware to drivers using multiple strategies.
    """

    def __init__(self, db: Session):
        self.db = db

    def match_hardware_to_driver(
        self,
        vendor_id: str,
        device_id: str,
        device_class: str = None,
        subsystem_vendor_id: str = None,
        subsystem_device_id: str = None,
        os_version: str = None,
        architecture: str = "x64"
    ) -> Tuple[Optional[Driver], str, str]:
        """
        Match hardware to the best available driver.

        Matching Strategy (in order of preference):
        1. Exact match (vendor + device + subsystem)
        2. Vendor + device match
        3. Device class match
        4. Fallback to generic driver

        Returns:
            Tuple of (Driver | None, confidence: str, method: str)
        """

        # Strategy 1: Exact match with subsystem
        if subsystem_vendor_id and subsystem_device_id:
            driver, method = self._exact_match_with_subsystem(
                vendor_id, device_id, subsystem_vendor_id, subsystem_device_id,
                os_version, architecture
            )
            if driver:
                return driver, "high", method

        # Strategy 2: Vendor + Device match
        driver, method = self._vendor_device_match(
            vendor_id, device_id, os_version, architecture
        )
        if driver:
            return driver, "high", method

        # Strategy 3: Device class match
        if device_class:
            driver, method = self._class_based_match(
                device_class, os_version, architecture
            )
            if driver:
                return driver, "medium", method

        # Strategy 4: No match found
        logger.warning(f"No driver match found for {vendor_id}:{device_id}")
        return None, "none", "no_match"

    def _exact_match_with_subsystem(
        self,
        vendor_id: str,
        device_id: str,
        subsystem_vendor_id: str,
        subsystem_device_id: str,
        os_version: str = None,
        architecture: str = "x64"
    ) -> Tuple[Optional[Driver], str]:
        """Exact hardware match including subsystem."""

        compat = self.db.query(HardwareCompatibility).filter(
            and_(
                HardwareCompatibility.vendor_id == vendor_id.upper(),
                HardwareCompatibility.device_id == device_id.upper(),
                HardwareCompatibility.subsystem_vendor_id == subsystem_vendor_id.upper(),
                HardwareCompatibility.subsystem_device_id == subsystem_device_id.upper(),
                HardwareCompatibility.architecture == architecture,
                HardwareCompatibility.driver_id.isnot(None)
            )
        )

        if os_version:
            compat = compat.filter(HardwareCompatibility.os_version == os_version)

        compat = compat.first()

        if compat and compat.driver_id:
            driver = self.db.query(Driver).filter(Driver.id == compat.driver_id).first()
            if driver:
                logger.info(f"Exact match found: {driver.name} for {vendor_id}:{device_id}")
                return driver, "exact_subsystem"

        return None, ""

    def _vendor_device_match(
        self,
        vendor_id: str,
        device_id: str,
        os_version: str = None,
        architecture: str = "x64"
    ) -> Tuple[Optional[Driver], str]:
        """Match based on vendor and device ID only."""

        compat = self.db.query(HardwareCompatibility).filter(
            and_(
                HardwareCompatibility.vendor_id == vendor_id.upper(),
                HardwareCompatibility.device_id == device_id.upper(),
                HardwareCompatibility.architecture == architecture,
                HardwareCompatibility.driver_id.isnot(None)
            )
        )

        if os_version:
            compat = compat.filter(HardwareCompatibility.os_version == os_version)

        # Prefer verified matches
        verified = compat.filter(HardwareCompatibility.verified == True).first()
        if verified and verified.driver_id:
            driver = self.db.query(Driver).filter(Driver.id == verified.driver_id).first()
            if driver:
                logger.info(f"Verified match found: {driver.name} for {vendor_id}:{device_id}")
                return driver, "exact_verified"

        # Fall back to any match
        compat_result = compat.first()
        if compat_result and compat_result.driver_id:
            driver = self.db.query(Driver).filter(Driver.id == compat_result.driver_id).first()
            if driver:
                logger.info(f"Vendor/Device match found: {driver.name} for {vendor_id}:{device_id}")
                return driver, "exact"

        return None, ""

    def _class_based_match(
        self,
        device_class: str,
        os_version: str = None,
        architecture: str = "x64"
    ) -> Tuple[Optional[Driver], str]:
        """Match based on device class (e.g., Network, Storage)."""

        compat = self.db.query(HardwareCompatibility).filter(
            and_(
                HardwareCompatibility.device_class == device_class,
                HardwareCompatibility.architecture == architecture,
                HardwareCompatibility.driver_id.isnot(None),
                HardwareCompatibility.confidence_score == "high"
            )
        )

        if os_version:
            compat = compat.filter(HardwareCompatibility.os_version == os_version)

        compat_result = compat.first()
        if compat_result and compat_result.driver_id:
            driver = self.db.query(Driver).filter(Driver.id == compat_result.driver_id).first()
            if driver:
                logger.info(f"Class-based match found: {driver.name} for class {device_class}")
                return driver, "class_based"

        return None, ""

    async def record_detected_hardware(
        self,
        device_mac: str,
        hardware_info: List[Dict],
        job_id: str = None
    ) -> List[DetectedHardware]:
        """
        Record hardware detected from a device and perform smart matching.

        Args:
            device_mac: MAC address of the device
            hardware_info: List of hardware dictionaries with vendor_id, device_id, etc.
            job_id: Optional job ID if part of an imaging job

        Returns:
            List of DetectedHardware records with matched drivers
        """
        detected_records = []

        for hw in hardware_info:
            # Extract hardware info
            vendor_id = hw.get('vendor_id', '').upper()
            device_id = hw.get('device_id', '').upper()
            device_class = hw.get('device_class')
            device_name = hw.get('device_name')
            hardware_type = hw.get('hardware_type', 'pci')
            pnp_id = hw.get('pnp_id')
            subsys_vendor = hw.get('subsystem_vendor_id', '').upper() if hw.get('subsystem_vendor_id') else None
            subsys_device = hw.get('subsystem_device_id', '').upper() if hw.get('subsystem_device_id') else None

            # Perform smart matching
            matched_driver, confidence, method = self.match_hardware_to_driver(
                vendor_id=vendor_id,
                device_id=device_id,
                device_class=device_class,
                subsystem_vendor_id=subsys_vendor,
                subsystem_device_id=subsys_device,
                os_version=hw.get('os_version'),
                architecture=hw.get('architecture', 'x64')
            )

            # Create detection record
            detected = DetectedHardware(
                id=str(uuid.uuid4()),
                device_mac=device_mac,
                job_id=job_id,
                vendor_id=vendor_id,
                device_id=device_id,
                subsystem_vendor_id=subsys_vendor,
                subsystem_device_id=subsys_device,
                hardware_type=hardware_type,
                device_class=device_class,
                device_name=device_name,
                pnp_id=pnp_id,
                matched_driver_id=matched_driver.id if matched_driver else None,
                match_confidence=confidence,
                match_method=method,
                raw_data=str(hw)
            )

            self.db.add(detected)
            detected_records.append(detected)

            logger.info(
                f"Recorded hardware: {device_name or f'{vendor_id}:{device_id}'} "
                f"-> Driver: {matched_driver.name if matched_driver else 'None'} "
                f"(confidence: {confidence}, method: {method})"
            )

        self.db.commit()
        return detected_records

    def get_drivers_for_device(
        self,
        device_mac: str,
        confidence_threshold: str = "medium"
    ) -> List[Driver]:
        """
        Get all matched drivers for a device.

        Args:
            device_mac: MAC address of the device
            confidence_threshold: Minimum confidence level ("high", "medium", "low")

        Returns:
            List of Driver objects
        """
        confidence_order = {"high": 3, "medium": 2, "low": 1, "none": 0}
        min_confidence_value = confidence_order.get(confidence_threshold, 2)

        detected_hw = self.db.query(DetectedHardware).filter(
            DetectedHardware.device_mac == device_mac
        ).all()

        drivers = []
        seen_driver_ids = set()

        for hw in detected_hw:
            if hw.matched_driver_id and hw.matched_driver_id not in seen_driver_ids:
                # Check confidence threshold
                hw_confidence_value = confidence_order.get(hw.match_confidence, 0)
                if hw_confidence_value >= min_confidence_value:
                    driver = self.db.query(Driver).filter(Driver.id == hw.matched_driver_id).first()
                    if driver:
                        drivers.append(driver)
                        seen_driver_ids.add(driver.id)

        logger.info(f"Found {len(drivers)} drivers for device {device_mac}")
        return drivers

    async def add_compatibility_mapping(
        self,
        vendor_id: str,
        device_id: str,
        driver_id: str,
        device_class: str = None,
        device_name: str = None,
        os_version: str = None,
        architecture: str = "x64",
        verified: bool = False,
        **kwargs
    ) -> HardwareCompatibility:
        """
        Add a new hardware-to-driver compatibility mapping.

        Useful for building the compatibility database.
        """
        hw_id = generate_hardware_id(
            vendor_id,
            device_id,
            kwargs.get('subsystem_vendor_id'),
            kwargs.get('subsystem_device_id')
        )

        compat = HardwareCompatibility(
            id=hw_id,
            vendor_id=vendor_id.upper(),
            device_id=device_id.upper(),
            subsystem_vendor_id=kwargs.get('subsystem_vendor_id', '').upper() if kwargs.get('subsystem_vendor_id') else None,
            subsystem_device_id=kwargs.get('subsystem_device_id', '').upper() if kwargs.get('subsystem_device_id') else None,
            hardware_type=kwargs.get('hardware_type', 'pci'),
            device_class=device_class,
            device_name=device_name,
            manufacturer=kwargs.get('manufacturer'),
            driver_id=driver_id,
            os_version=os_version,
            architecture=architecture,
            confidence_score=kwargs.get('confidence_score', 'high'),
            verified=verified,
            pnp_id_pattern=kwargs.get('pnp_id_pattern'),
            notes=kwargs.get('notes'),
            source=kwargs.get('source', 'manual')
        )

        self.db.add(compat)
        self.db.commit()

        logger.info(f"Added compatibility mapping: {hw_id} -> {driver_id}")
        return compat
