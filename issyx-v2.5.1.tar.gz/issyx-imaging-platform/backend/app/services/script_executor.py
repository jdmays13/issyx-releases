"""
Script Execution Service

Handles execution of PowerShell and Batch scripts with template variable substitution.
Supports computer naming templates with device-specific variables.
"""
import re
import random
import string
import subprocess
import os
import logging
from typing import Dict, Optional
from sqlalchemy.orm import Session
from ..models.script import ScriptsLibrary
from ..models.master_profile import MasterProfile
from ..models.job import JobDevice

logger = logging.getLogger(__name__)


class ScriptExecutor:
    """
    Executes scripts with variable substitution for computer naming and configuration.
    """

    def __init__(self, db: Session):
        self.db = db

    def generate_computer_name(self, template: str, device: JobDevice, profile: MasterProfile) -> str:
        """
        Generate computer name from template using device-specific variables.

        Supported variables:
        - %serial% - Device serial number (from hardware detection)
        - %mac% - Device MAC address (last 6 characters, no colons)
        - %model% - Device model (from hardware detection)
        - %random% - 4 random alphanumeric characters
        - %customer% - Customer name abbreviation (first 3 letters)
        - %date% - Current date in YYMMDD format

        Example templates:
        - "CORP-%serial%" -> "CORP-ABC12345"
        - "BRN-%model%-%random%" -> "BRN-X1CARBON-A7F2"
        - "%customer%-%mac%" -> "BAR-F4A123"
        """
        if not template:
            # Fallback: use MAC address
            mac_clean = device.mac_address.replace(":", "").replace("-", "").upper()[-6:]
            return f"PC-{mac_clean}"

        computer_name = template

        # %serial% - Device serial number (placeholder for now, will come from hardware detection)
        if "%serial%" in computer_name:
            serial = getattr(device, 'serial_number', None) or 'UNKNOWN'
            computer_name = computer_name.replace("%serial%", serial)

        # %mac% - Last 6 characters of MAC address
        if "%mac%" in computer_name:
            mac_clean = device.mac_address.replace(":", "").replace("-", "").upper()[-6:]
            computer_name = computer_name.replace("%mac%", mac_clean)

        # %model% - Device model (placeholder for now)
        if "%model%" in computer_name:
            model = getattr(device, 'model', None) or 'PC'
            # Clean model name (remove spaces and special chars)
            model_clean = re.sub(r'[^A-Z0-9]', '', model.upper())[:10]
            computer_name = computer_name.replace("%model%", model_clean)

        # %random% - 4 random alphanumeric characters
        if "%random%" in computer_name:
            random_str = ''.join(random.choices(string.ascii_uppercase + string.digits, k=4))
            computer_name = computer_name.replace("%random%", random_str)

        # %customer% - Customer abbreviation (first 3 letters)
        if "%customer%" in computer_name:
            customer_name = profile.customer.name if profile.customer else "CUS"
            customer_abbr = re.sub(r'[^A-Z0-9]', '', customer_name.upper())[:3]
            computer_name = computer_name.replace("%customer%", customer_abbr)

        # %date% - Current date YYMMDD
        if "%date%" in computer_name:
            from datetime import datetime
            date_str = datetime.now().strftime("%y%m%d")
            computer_name = computer_name.replace("%date%", date_str)

        # Ensure computer name meets Windows requirements
        # Max 15 characters, alphanumeric and hyphens only
        computer_name = re.sub(r'[^A-Za-z0-9\-]', '', computer_name)[:15]

        return computer_name

    def substitute_variables(self, script_content: str, variables: Dict[str, str]) -> str:
        """
        Substitute template variables in script content.

        Variables format: {{VARIABLE_NAME}}
        """
        for key, value in variables.items():
            placeholder = f"{{{{{key}}}}}"
            script_content = script_content.replace(placeholder, str(value))

        return script_content

    async def execute_script(
        self,
        script_id: str,
        device: JobDevice,
        profile: MasterProfile,
        additional_vars: Optional[Dict[str, str]] = None
    ) -> tuple[bool, str]:
        """
        Execute a script with device and profile context.

        Returns:
            tuple[bool, str]: (success, output/error_message)
        """
        try:
            # Get script from database
            script = self.db.query(ScriptsLibrary).filter(ScriptsLibrary.id == script_id).first()
            if not script:
                return False, f"Script {script_id} not found"

            # Check if script file exists
            if not os.path.exists(script.file_path):
                return False, f"Script file not found: {script.file_path}"

            # Prepare variables for substitution
            variables = {}

            # Computer naming variables (if system_config exists)
            if profile.system_config:
                system_config = profile.system_config

                # Generate computer name if template is provided
                computer_name_template = system_config.get('computerNameTemplate')
                if computer_name_template:
                    computer_name = self.generate_computer_name(computer_name_template, device, profile)
                    variables['COMPUTER_NAME'] = computer_name

                # Local admin configuration
                local_admin = system_config.get('localAdmin', {})
                if local_admin.get('enabled'):
                    variables['ADMIN_USERNAME'] = local_admin.get('username', 'LocalAdmin')
                    variables['ADMIN_PASSWORD'] = local_admin.get('password', '')

                # DNS configuration
                dns_servers = system_config.get('dnsServers', {})
                if dns_servers.get('enabled'):
                    variables['DNS_PRIMARY'] = dns_servers.get('primary', '8.8.8.8')
                    variables['DNS_SECONDARY'] = dns_servers.get('secondary', '8.8.4.4')

            # Add additional variables
            if additional_vars:
                variables.update(additional_vars)

            # Device-specific variables
            variables['DEVICE_MAC'] = device.mac_address
            variables['DEVICE_IP'] = device.ip_address or 'DHCP'
            variables['JOB_ID'] = device.job_id

            # Read script content
            with open(script.file_path, 'r', encoding='utf-8') as f:
                script_content = f.read()

            # Substitute variables
            script_content = self.substitute_variables(script_content, variables)

            # Execute script based on type
            if script.type == "PowerShell":
                success, output = await self._execute_powershell(script_content, script.name)
            elif script.type == "Batch":
                success, output = await self._execute_batch(script_content, script.name)
            else:
                return False, f"Unsupported script type: {script.type}"

            logger.info(f"Script {script.name} executed for device {device.mac_address}: {'SUCCESS' if success else 'FAILED'}")
            return success, output

        except Exception as e:
            logger.error(f"Error executing script {script_id}: {e}")
            return False, str(e)

    async def _execute_powershell(self, script_content: str, script_name: str) -> tuple[bool, str]:
        """
        Execute PowerShell script content.

        NOTE: In production, this would execute on the target device via WinPE/WinRM.
        For now, this simulates execution.
        """
        try:
            # In production environment, you would use:
            # - WinRM to execute on remote device
            # - Or save script to WinPE environment and execute during boot

            logger.info(f"[SIMULATED] Executing PowerShell script: {script_name}")
            logger.debug(f"Script content preview: {script_content[:200]}...")

            # Simulated success for development
            return True, f"PowerShell script '{script_name}' executed successfully (simulated)"

            # Production code would look like:
            # result = subprocess.run(
            #     ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script_content],
            #     capture_output=True,
            #     text=True,
            #     timeout=300
            # )
            # return result.returncode == 0, result.stdout if result.returncode == 0 else result.stderr

        except Exception as e:
            return False, f"PowerShell execution error: {str(e)}"

    async def _execute_batch(self, script_content: str, script_name: str) -> tuple[bool, str]:
        """
        Execute Batch script content.

        NOTE: In production, this would execute on the target device.
        For now, this simulates execution.
        """
        try:
            logger.info(f"[SIMULATED] Executing Batch script: {script_name}")
            logger.debug(f"Script content preview: {script_content[:200]}...")

            # Simulated success for development
            return True, f"Batch script '{script_name}' executed successfully (simulated)"

            # Production code would look like:
            # result = subprocess.run(
            #     ["cmd", "/c", script_content],
            #     capture_output=True,
            #     text=True,
            #     timeout=300
            # )
            # return result.returncode == 0, result.stdout if result.returncode == 0 else result.stderr

        except Exception as e:
            return False, f"Batch execution error: {str(e)}"

    async def execute_profile_scripts(
        self,
        profile: MasterProfile,
        device: JobDevice,
        phase: str  # "pre" or "post"
    ) -> list[tuple[str, bool, str]]:
        """
        Execute all scripts for a profile in a specific phase (pre/post imaging).

        Returns:
            list[tuple[str, bool, str]]: List of (script_name, success, output)
        """
        results = []

        try:
            # Get scripts for this phase
            scripts_to_execute = [
                script for script in profile.scripts
                if any(
                    assoc.execution_phase.value == phase
                    for assoc in self.db.query(profile.__class__.scripts.property.secondary).filter_by(
                        profile_id=profile.id,
                        script_id=script.id
                    )
                )
            ]

            logger.info(f"Executing {len(scripts_to_execute)} {phase}-imaging scripts for device {device.mac_address}")

            for script in scripts_to_execute:
                success, output = await self.execute_script(script.id, device, profile)
                results.append((script.name, success, output))

                if not success:
                    logger.warning(f"Script {script.name} failed: {output}")

        except Exception as e:
            logger.error(f"Error executing profile scripts: {e}")
            results.append(("Error", False, str(e)))

        return results
