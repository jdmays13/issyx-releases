"""
Device Discovery Service

Handles PXE boot detection, device registration, and intelligent auto-assignment to jobs.

Auto-assignment logic:
- If exactly 1 job is RUNNING → auto-assign device
- If multiple jobs are RUNNING → manual assignment required (device held as "unassigned")
- If no RUNNING jobs → hold device, notify admins
"""
from sqlalchemy.orm import Session
from sqlalchemy import and_
from datetime import datetime
from ..models.discovered_device import DiscoveredDevice
from ..models.job import Job, JobDevice, JobStatus, DeviceStatus
from ..models.notification import NotificationEvent
from ..routes.websocket import broadcast_job_update
from ..services.notification import NotificationService
import logging
import uuid

logger = logging.getLogger(__name__)


async def register_device(
    mac_address: str,
    ip_address: str,
    hostname: str = None,
    manufacturer: str = None,
    model: str = None,
    db: Session = None
):
    """
    Register a device detected via PXE boot.

    Handles:
    1. Update or create discovered_device record
    2. Check for running jobs
    3. Auto-assign to job if exactly one is running
    4. Send WebSocket notifications

    Returns:
        dict: {
            "device": DiscoveredDevice,
            "assigned_to_job": str | None,
            "assignment_status": "auto" | "manual_required" | "queued"
        }
    """
    try:
        # Step 1: Update or create discovered device record
        discovered = db.query(DiscoveredDevice).filter(
            DiscoveredDevice.mac_address == mac_address
        ).first()

        if discovered:
            # Update existing device
            discovered.ip_address = ip_address
            discovered.hostname = hostname or discovered.hostname
            discovered.manufacturer = manufacturer or discovered.manufacturer
            discovered.model = model or discovered.model
            discovered.last_seen = datetime.now()
            discovered.times_seen = str(int(discovered.times_seen or 0) + 1)
            logger.info(f"Updated discovered device: {mac_address}")
        else:
            # Create new device
            discovered = DiscoveredDevice(
                mac_address=mac_address,
                ip_address=ip_address,
                hostname=hostname,
                manufacturer=manufacturer,
                model=model,
                times_seen="1",
                is_active=True
            )
            db.add(discovered)
            logger.info(f"New device discovered: {mac_address}")

            # Send device discovery notification for new devices
            try:
                notification_service = NotificationService(db)
                await notification_service.send_notification(
                    event_type=NotificationEvent.DEVICE_DISCOVERED,
                    subject=f"New Device Discovered: {hostname or mac_address}",
                    message=f"New device discovered via PXE boot.\nMAC: {mac_address}\nHostname: {hostname or 'Unknown'}\nIP: {ip_address}\nManufacturer: {manufacturer or 'Unknown'}",
                    device_mac=mac_address,
                    metadata={
                        "mac_address": mac_address,
                        "ip_address": ip_address,
                        "hostname": hostname,
                        "manufacturer": manufacturer,
                        "model": model
                    }
                )
            except Exception as e:
                logger.error(f"Failed to send device discovery notification: {e}")

        db.commit()
        db.refresh(discovered)

        # Step 2: Check if device is already assigned to a job
        existing_assignment = db.query(JobDevice).filter(
            JobDevice.mac_address == mac_address
        ).first()

        if existing_assignment:
            # Device already assigned to a job
            logger.info(f"Device {mac_address} already assigned to job {existing_assignment.job_id}")
            return {
                "device": discovered,
                "assigned_to_job": existing_assignment.job_id,
                "assignment_status": "already_assigned"
            }

        # Step 3: Find running jobs
        running_jobs = db.query(Job).filter(
            Job.status == JobStatus.RUNNING
        ).all()

        # Step 4: Apply assignment logic
        if len(running_jobs) == 1:
            # Exactly one running job → auto-assign
            job = running_jobs[0]
            job_device = JobDevice(
                id=str(uuid.uuid4()),
                job_id=job.id,
                mac_address=mac_address,
                ip_address=ip_address,
                hostname=hostname or f"Device-{mac_address[-8:]}",
                status=DeviceStatus.QUEUED,
                progress=0,
                current_step="Waiting to start imaging"
            )
            db.add(job_device)

            # Update job device counts
            job.total_devices += 1

            db.commit()

            # Send WebSocket notification
            await broadcast_job_update(
                job_id=job.id,
                status=job.status.value,
                progress=0,
                message=f"Device {hostname or mac_address} auto-assigned to job"
            )

            logger.info(f"Auto-assigned device {mac_address} to job {job.id}")

            return {
                "device": discovered,
                "assigned_to_job": job.id,
                "assignment_status": "auto"
            }

        elif len(running_jobs) > 1:
            # Multiple running jobs → manual assignment required
            logger.info(f"Device {mac_address} requires manual assignment ({len(running_jobs)} jobs running)")

            # Send notification about unassigned device
            from ..routes.websocket import manager
            await manager.broadcast({
                "type": "device_discovered",
                "data": {
                    "mac_address": mac_address,
                    "hostname": hostname,
                    "ip_address": ip_address,
                    "assignment_status": "manual_required",
                    "running_jobs_count": len(running_jobs),
                    "message": f"Device {hostname or mac_address} detected - manual assignment required"
                }
            })

            return {
                "device": discovered,
                "assigned_to_job": None,
                "assignment_status": "manual_required"
            }

        else:
            # No running jobs → hold device, notify
            logger.info(f"Device {mac_address} detected but no jobs running")

            # Check if there are queued jobs
            queued_jobs = db.query(Job).filter(
                Job.status == JobStatus.QUEUED
            ).count()

            # Send notification
            from ..routes.websocket import manager
            await manager.broadcast({
                "type": "device_discovered",
                "data": {
                    "mac_address": mac_address,
                    "hostname": hostname,
                    "ip_address": ip_address,
                    "assignment_status": "queued",
                    "queued_jobs_count": queued_jobs,
                    "message": f"Device {hostname or mac_address} detected - no running jobs"
                }
            })

            return {
                "device": discovered,
                "assigned_to_job": None,
                "assignment_status": "queued"
            }

    except Exception as e:
        logger.error(f"Error registering device {mac_address}: {e}")
        db.rollback()
        raise


async def manually_assign_device(
    mac_address: str,
    job_id: str,
    db: Session
):
    """
    Manually assign an unassigned device to a specific job.
    Used when multiple jobs are running.
    """
    try:
        # Check if device exists
        discovered = db.query(DiscoveredDevice).filter(
            DiscoveredDevice.mac_address == mac_address
        ).first()

        if not discovered:
            raise ValueError(f"Device {mac_address} not found")

        # Check if already assigned
        existing = db.query(JobDevice).filter(
            JobDevice.mac_address == mac_address
        ).first()

        if existing:
            raise ValueError(f"Device already assigned to job {existing.job_id}")

        # Check if job exists and is running
        job = db.query(Job).filter(Job.id == job_id).first()
        if not job:
            raise ValueError(f"Job {job_id} not found")

        if job.status != JobStatus.RUNNING:
            raise ValueError(f"Job {job_id} is not running (status: {job.status})")

        # Create job device assignment
        job_device = JobDevice(
            id=str(uuid.uuid4()),
            job_id=job.id,
            mac_address=mac_address,
            ip_address=discovered.ip_address,
            hostname=discovered.hostname or f"Device-{mac_address[-8:]}",
            status=DeviceStatus.QUEUED,
            progress=0,
            current_step="Manually assigned - waiting to start"
        )
        db.add(job_device)

        # Update job device count
        job.total_devices += 1

        db.commit()

        # Send WebSocket notification
        await broadcast_job_update(
            job_id=job.id,
            status=job.status.value,
            progress=0,
            message=f"Device {discovered.hostname or mac_address} manually assigned"
        )

        logger.info(f"Manually assigned device {mac_address} to job {job_id}")

        return job_device

    except Exception as e:
        logger.error(f"Error manually assigning device {mac_address} to job {job_id}: {e}")
        db.rollback()
        raise
