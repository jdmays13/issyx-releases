<#
.SYNOPSIS
    BIOS Configuration Script - Configures BIOS settings for deployment
.DESCRIPTION
    This script configures common BIOS settings to prepare for imaging.
    Settings include boot order, secure boot, virtualization, and power settings.
.NOTES
    Category: Pre-Imaging
    Author: ISSYX Imaging Platform
#>

Write-Host "======================================"
Write-Host "  BIOS Configuration Script"
Write-Host "======================================"
Write-Host ""

# Log file
$LogPath = "C:\Windows\Temp\ISSYX_BIOSConfig.log"
$LogMessage = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') - Starting BIOS configuration check"
Add-Content -Path $LogPath -Value $LogMessage -ErrorAction SilentlyContinue

try {
    # Check if running as administrator
    $IsAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]"Administrator")

    if (-not $IsAdmin) {
        throw "Script must be run as Administrator"
    }

    Write-Host "Checking BIOS/UEFI Settings..." -ForegroundColor Yellow
    Write-Host ""

    # Check Secure Boot status
    try {
        $SecureBoot = Confirm-SecureBootUEFI
        Write-Host "[INFO] Secure Boot is: $(if($SecureBoot){'ENABLED'}else{'DISABLED'})"
    } catch {
        Write-Host "[INFO] Secure Boot status could not be determined (Legacy BIOS or unsupported)"
    }

    # Check Virtualization (Intel VT-x/AMD-V)
    Write-Host "[INFO] Checking virtualization support..."
    $Processor = Get-WmiObject Win32_Processor
    if ($Processor.VirtualizationFirmwareEnabled -eq $true) {
        Write-Host "[OK] Hardware virtualization is ENABLED" -ForegroundColor Green
    } else {
        Write-Host "[WARNING] Hardware virtualization is DISABLED" -ForegroundColor Yellow
    }

    # Check TPM status
    try {
        $TPM = Get-Tpm -ErrorAction Stop
        Write-Host "[INFO] TPM Present: $($TPM.TpmPresent), Enabled: $($TPM.TpmEnabled), Activated: $($TPM.TpmActivated)"
    } catch {
        Write-Host "[INFO] TPM information could not be retrieved"
    }

    # Check boot mode (UEFI vs Legacy)
    $BootMode = $env:firmware_type
    if (-not $BootMode) {
        # Alternative method
        $BootMode = (Get-ItemProperty "HKLM:\System\CurrentControlSet\Control" -Name PEFirmwareType -ErrorAction SilentlyContinue).PEFirmwareType
        if ($BootMode -eq 1) {
            $BootMode = "BIOS"
        } elseif ($BootMode -eq 2) {
            $BootMode = "UEFI"
        } else {
            $BootMode = "Unknown"
        }
    }
    Write-Host "[INFO] Boot Mode: $BootMode"

    Write-Host ""
    Write-Host "BIOS configuration check completed successfully!" -ForegroundColor Green
    Write-Host ""
    Write-Host "NOTE: Actual BIOS settings changes require manufacturer-specific tools."
    Write-Host "For automated BIOS configuration, use vendor tools like:"
    Write-Host "  - Dell: Dell Command | Configure"
    Write-Host "  - HP: HP BIOS Configuration Utility"
    Write-Host "  - Lenovo: Lenovo BIOS Setup Using Windows Management Instrumentation"

    $LogMessage = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') - BIOS configuration check completed"
    Add-Content -Path $LogPath -Value $LogMessage -ErrorAction SilentlyContinue

    exit 0

} catch {
    Write-Host ""
    Write-Host "ERROR: BIOS configuration failed!" -ForegroundColor Red
    Write-Host "Error Details: $($_.Exception.Message)" -ForegroundColor Red

    $LogMessage = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') - ERROR: $($_.Exception.Message)"
    Add-Content -Path $LogPath -Value $LogMessage -ErrorAction SilentlyContinue

    exit 1
}
