<#
.SYNOPSIS
    Local Admin Setup Script - Creates and configures local administrator account
.DESCRIPTION
    This script creates a local administrator account with specified credentials and configures policies.
    Variables available: {{ADMIN_USERNAME}}, {{ADMIN_PASSWORD}}
.NOTES
    Category: Post-Imaging
    Author: ISSYX Imaging Platform
#>

param(
    [Parameter(Mandatory=$true)]
    [string]$AdminUsername,

    [Parameter(Mandatory=$true)]
    [string]$AdminPassword
)

Write-Host "======================================"
Write-Host "  Local Admin Setup Script"
Write-Host "======================================"
Write-Host ""

# Log file
$LogPath = "C:\Windows\Temp\ISSYX_LocalAdmin.log"

try {
    Write-Host "Creating local administrator account: $AdminUsername"

    # Check if user already exists
    $UserExists = Get-LocalUser -Name $AdminUsername -ErrorAction SilentlyContinue

    if ($UserExists) {
        Write-Host "[INFO] User '$AdminUsername' already exists. Updating password..." -ForegroundColor Yellow

        # Update password
        $SecurePassword = ConvertTo-SecureString $AdminPassword -AsPlainText -Force
        $UserExists | Set-LocalUser -Password $SecurePassword

        Write-Host "[OK] Password updated successfully" -ForegroundColor Green

    } else {
        Write-Host "[INFO] Creating new user '$AdminUsername'..."

        # Create new local user
        $SecurePassword = ConvertTo-SecureString $AdminPassword -AsPlainText -Force
        New-LocalUser -Name $AdminUsername `
                      -Password $SecurePassword `
                      -FullName "Local Administrator" `
                      -Description "Local administrator account created by ISSYX Imaging Platform" `
                      -PasswordNeverExpires:$true `
                      -AccountNeverExpires `
                      -ErrorAction Stop

        Write-Host "[OK] User created successfully" -ForegroundColor Green
    }

    # Add to Administrators group
    Write-Host "[INFO] Adding '$AdminUsername' to Administrators group..."
    $AdminsGroup = Get-LocalGroup -Name "Administrators" -ErrorAction Stop
    Add-LocalGroupMember -Group $AdminsGroup -Member $AdminUsername -ErrorAction SilentlyContinue

    Write-Host "[OK] User added to Administrators group" -ForegroundColor Green

    # Disable password expiration policy for this account
    Write-Host "[INFO] Configuring account policies..."
    Set-LocalUser -Name $AdminUsername -PasswordNeverExpires:$true -ErrorAction SilentlyContinue

    Write-Host ""
    Write-Host "SUCCESS: Local administrator account configured successfully!" -ForegroundColor Green
    Write-Host "  Username: $AdminUsername"
    Write-Host "  Group: Administrators"
    Write-Host "  Password Expires: Never"

    # Log success
    $LogMessage = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') - Local admin account '$AdminUsername' configured successfully"
    Add-Content -Path $LogPath -Value $LogMessage

    exit 0

} catch {
    Write-Host ""
    Write-Host "ERROR: Failed to configure local administrator!" -ForegroundColor Red
    Write-Host "Error Details: $($_.Exception.Message)" -ForegroundColor Red

    # Log error
    $LogMessage = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') - ERROR: $($_.Exception.Message)"
    Add-Content -Path $LogPath -Value $LogMessage

    exit 1
}
