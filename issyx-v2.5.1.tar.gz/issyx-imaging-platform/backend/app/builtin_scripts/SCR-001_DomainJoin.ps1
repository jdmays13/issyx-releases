<#
.SYNOPSIS
    Domain Join Script - Joins computer to Active Directory domain
.DESCRIPTION
    This script joins the computer to the specified domain and moves it to the appropriate OU.
    Variables available: {{COMPUTER_NAME}}, {{DOMAIN}}, {{OU_PATH}}, {{DOMAIN_USER}}, {{DOMAIN_PASS}}
.NOTES
    Category: Post-Imaging
    Author: ISSYX Imaging Platform
#>

param(
    [Parameter(Mandatory=$true)]
    [string]$ComputerName,

    [Parameter(Mandatory=$true)]
    [string]$Domain,

    [Parameter(Mandatory=$false)]
    [string]$OUPath,

    [Parameter(Mandatory=$true)]
    [string]$DomainUser,

    [Parameter(Mandatory=$true)]
    [string]$DomainPass
)

Write-Host "======================================"
Write-Host "  Domain Join Script"
Write-Host "======================================"
Write-Host ""

# Create credential object
$SecurePassword = ConvertTo-SecureString $DomainPass -AsPlainText -Force
$Credential = New-Object System.Management.Automation.PSCredential($DomainUser, $SecurePassword)

try {
    Write-Host "Setting computer name to: $ComputerName"
    Rename-Computer -NewName $ComputerName -Force -ErrorAction Stop

    Write-Host "Joining domain: $Domain"

    if ($OUPath) {
        Write-Host "OU Path: $OUPath"
        Add-Computer -DomainName $Domain -OUPath $OUPath -Credential $Credential -Force -ErrorAction Stop
    } else {
        Add-Computer -DomainName $Domain -Credential $Credential -Force -ErrorAction Stop
    }

    Write-Host ""
    Write-Host "SUCCESS: Computer joined to domain successfully!" -ForegroundColor Green
    Write-Host "A restart is required to complete the domain join."

    # Log success
    $LogPath = "C:\Windows\Temp\ISSYX_DomainJoin.log"
    $LogMessage = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') - Domain join completed successfully. Computer: $ComputerName, Domain: $Domain"
    Add-Content -Path $LogPath -Value $LogMessage

    exit 0

} catch {
    Write-Host ""
    Write-Host "ERROR: Failed to join domain!" -ForegroundColor Red
    Write-Host "Error Details: $($_.Exception.Message)" -ForegroundColor Red

    # Log error
    $LogPath = "C:\Windows\Temp\ISSYX_DomainJoin.log"
    $LogMessage = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') - ERROR: $($_.Exception.Message)"
    Add-Content -Path $LogPath -Value $LogMessage

    exit 1
}
