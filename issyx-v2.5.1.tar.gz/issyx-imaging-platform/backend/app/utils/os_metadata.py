"""
Utility functions for extracting OS metadata from filenames and ISO images.
"""
import re
from typing import Dict, Optional


def parse_os_metadata_from_filename(filename: str) -> Dict[str, str]:
    """
    Extract OS metadata (version, edition, build) from filename.

    Args:
        filename: The ISO filename

    Returns:
        Dictionary with name, version, edition, and build keys
    """
    # Remove file extension
    name_without_ext = filename.rsplit('.', 1)[0] if '.' in filename else filename

    metadata = {
        "name": name_without_ext,
        "version": "N/A",
        "edition": "N/A",
        "build": "N/A"
    }

    # Windows patterns
    windows_patterns = [
        # Win11_24H2_English_x64
        r'Win(?:dows)?(\d+)_(\d+H\d+)_\w+_x(?:86|64)',
        # Windows 11 Pro 22H2 Build 22621.2715
        r'Windows\s+(\d+(?:\.\d+)?)\s+(Pro|Enterprise|Home|Education)\s+(\d+H\d+)(?:\s+Build\s+(\d+\.\d+))?',
        # Windows_11_22H2_x64
        r'Windows[_\s](\d+)(?:[_\s](\d+H\d+))?',
    ]

    for pattern in windows_patterns:
        match = re.search(pattern, filename, re.IGNORECASE)
        if match:
            groups = match.groups()
            if len(groups) >= 1:
                metadata["name"] = f"Windows {groups[0]}"
                metadata["version"] = groups[2] if len(groups) > 2 and groups[2] else (groups[1] if len(groups) > 1 and groups[1] and re.match(r'\d+H\d+', groups[1]) else "N/A")
                metadata["edition"] = groups[1] if len(groups) > 1 and groups[1] and not re.match(r'\d+H\d+', groups[1]) else "N/A"
                metadata["build"] = groups[3] if len(groups) > 3 and groups[3] else "N/A"
            return metadata

    # Ubuntu patterns
    # ubuntu-24.04.3-live-server-amd64
    ubuntu_match = re.search(r'ubuntu[_-](\d+\.\d+(?:\.\d+)?)[_-](desktop|server|live-server)', filename, re.IGNORECASE)
    if ubuntu_match:
        metadata["name"] = "Ubuntu"
        metadata["version"] = ubuntu_match.group(1)
        metadata["edition"] = ubuntu_match.group(2).replace('-', ' ').title()
        return metadata

    # Debian patterns
    # debian-12.5.0-amd64-netinst
    debian_match = re.search(r'debian[_-](\d+\.\d+(?:\.\d+)?)', filename, re.IGNORECASE)
    if debian_match:
        metadata["name"] = "Debian"
        metadata["version"] = debian_match.group(1)
        return metadata

    # CentOS / Rocky / AlmaLinux patterns
    # CentOS-8.5.2111-x86_64-dvd1
    # Rocky-9.3-x86_64-minimal
    rhel_match = re.search(r'(CentOS|Rocky|AlmaLinux|RHEL)[_-](\d+(?:\.\d+)?)', filename, re.IGNORECASE)
    if rhel_match:
        metadata["name"] = rhel_match.group(1)
        metadata["version"] = rhel_match.group(2)
        return metadata

    # Fedora patterns
    # Fedora-Workstation-Live-x86_64-39-1.5
    fedora_match = re.search(r'Fedora[_-](\w+)[_-].*?(\d+)(?:[_-](\d+\.\d+))?', filename, re.IGNORECASE)
    if fedora_match:
        metadata["name"] = "Fedora"
        metadata["edition"] = fedora_match.group(1)
        metadata["version"] = fedora_match.group(2)
        return metadata

    # Proxmox patterns
    # proxmox-ve_9.0-1
    proxmox_match = re.search(r'proxmox[_-]ve[_-](\d+\.\d+(?:[_-]\d+)?)', filename, re.IGNORECASE)
    if proxmox_match:
        metadata["name"] = "Proxmox VE"
        metadata["version"] = proxmox_match.group(1).replace('_', '.').replace('-', '.')
        return metadata

    # XCP-ng patterns
    # xcp-ng-8.3.0-20250606
    xcpng_match = re.search(r'xcp[_-]ng[_-](\d+\.\d+\.\d+)', filename, re.IGNORECASE)
    if xcpng_match:
        metadata["name"] = "XCP-ng"
        metadata["version"] = xcpng_match.group(1)
        return metadata

    # Generic pattern: Try to extract version numbers
    version_match = re.search(r'(\d+\.\d+(?:\.\d+)?)', filename)
    if version_match:
        metadata["version"] = version_match.group(1)

    return metadata


def validate_os_metadata(metadata: Dict[str, str]) -> bool:
    """
    Validate that essential OS metadata is present.

    Args:
        metadata: Dictionary with OS metadata

    Returns:
        True if valid, False otherwise
    """
    return bool(metadata.get("name") and metadata["name"] != "N/A")
