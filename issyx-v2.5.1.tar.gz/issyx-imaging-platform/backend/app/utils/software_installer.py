"""
Software Installation Utility

Handles silent installation of various software package types
with automatic parameter detection and retry logic.
"""
import os
import subprocess
import asyncio
import logging
from pathlib import Path
from typing import Optional, Tuple

logger = logging.getLogger(__name__)


class SoftwareInstaller:
    """Utility class for installing software packages silently"""

    # Default silent install parameters for common installers
    SILENT_PARAMS = {
        '.exe': {
            'NSIS': '/S',  # Nullsoft Scriptable Install System
            'Inno Setup': '/VERYSILENT /NORESTART',
            'InstallShield': '/s /v"/qn"',
            'WiX': '/quiet /norestart',
            'Default': '/S /silent /quiet'  # Try common parameters
        },
        '.msi': '/qn /norestart',  # Windows Installer quiet mode, no restart
        '.msix': None,  # Installed via PowerShell Add-AppxPackage
        '.appx': None,  # Installed via PowerShell Add-AppxPackage
    }

    def __init__(self, max_retries: int = 1):
        """
        Initialize software installer.

        Args:
            max_retries: Maximum number of retry attempts (default 1)
        """
        self.max_retries = max_retries

    def detect_install_params(self, file_path: str, custom_params: Optional[str] = None) -> str:
        """
        Detect appropriate silent install parameters for a software package.

        Args:
            file_path: Path to the installer file
            custom_params: Custom install parameters (overrides auto-detection)

        Returns:
            Silent install parameters string
        """
        if custom_params:
            return custom_params

        file_ext = Path(file_path).suffix.lower()

        if file_ext == '.msi':
            return self.SILENT_PARAMS['.msi']
        elif file_ext in ['.msix', '.appx']:
            return self.SILENT_PARAMS.get(file_ext)
        elif file_ext == '.exe':
            # For EXE files, try to detect installer type
            # In production, you could inspect the file to detect NSIS, Inno Setup, etc.
            # For now, return a common set of parameters
            return self.SILENT_PARAMS['.exe']['Default']
        elif file_ext == '.zip':
            # ZIP files need to be extracted, not installed
            return None
        else:
            logger.warning(f"Unknown file type: {file_ext}, using default parameters")
            return '/S /silent /quiet'

    async def install_software(
        self,
        file_path: str,
        install_params: Optional[str] = None,
        software_name: str = "Software"
    ) -> Tuple[bool, str]:
        """
        Install software with automatic retry logic.

        Args:
            file_path: Path to the installer file
            install_params: Custom install parameters (optional)
            software_name: Name of the software for logging

        Returns:
            Tuple of (success: bool, message: str)
        """
        if not os.path.exists(file_path):
            error_msg = f"Installer file not found: {file_path}"
            logger.error(error_msg)
            return False, error_msg

        file_ext = Path(file_path).suffix.lower()

        # Handle different file types
        if file_ext == '.zip':
            return False, "ZIP files must be extracted manually - not supported for automated installation"

        # Attempt installation with retries
        for attempt in range(self.max_retries + 1):
            try:
                if attempt > 0:
                    logger.info(f"Retry {attempt}/{self.max_retries} for {software_name}")

                success, message = await self._execute_install(
                    file_path=file_path,
                    install_params=install_params,
                    software_name=software_name
                )

                if success:
                    return True, message

                # If this was the last attempt, return the failure
                if attempt >= self.max_retries:
                    return False, f"Failed after {self.max_retries + 1} attempts: {message}"

                # Wait before retry
                await asyncio.sleep(2)

            except Exception as e:
                error_msg = f"Exception during installation attempt {attempt + 1}: {str(e)}"
                logger.error(error_msg)

                if attempt >= self.max_retries:
                    return False, error_msg

        return False, "Installation failed"

    async def _execute_install(
        self,
        file_path: str,
        install_params: Optional[str],
        software_name: str
    ) -> Tuple[bool, str]:
        """
        Execute the actual installation command.

        Args:
            file_path: Path to the installer file
            install_params: Install parameters
            software_name: Software name for logging

        Returns:
            Tuple of (success: bool, message: str)
        """
        file_ext = Path(file_path).suffix.lower()

        # Detect install parameters if not provided
        params = self.detect_install_params(file_path, install_params)

        try:
            if file_ext in ['.msix', '.appx']:
                # Use PowerShell to install MSIX/APPX packages
                command = [
                    'powershell.exe',
                    '-Command',
                    f'Add-AppxPackage -Path "{file_path}"'
                ]
                logger.info(f"Installing {software_name} via PowerShell: {file_path}")

            elif file_ext == '.msi':
                # Use msiexec for MSI packages
                command = ['msiexec.exe', '/i', file_path] + (params.split() if params else [])
                logger.info(f"Installing {software_name} via msiexec: {file_path} {params}")

            elif file_ext == '.exe':
                # Execute EXE installer with parameters
                command = [file_path] + (params.split() if params else [])
                logger.info(f"Installing {software_name}: {file_path} {params}")

            else:
                return False, f"Unsupported file type: {file_ext}"

            # Execute the installation command
            process = await asyncio.create_subprocess_exec(
                *command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )

            stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=600)  # 10 min timeout

            # Check return code
            if process.returncode == 0:
                success_msg = f"{software_name} installed successfully"
                logger.info(success_msg)
                return True, success_msg
            elif process.returncode == 3010:
                # Exit code 3010 means success but reboot required
                success_msg = f"{software_name} installed successfully (reboot required)"
                logger.info(success_msg)
                return True, success_msg
            else:
                error_msg = f"Installation failed with exit code {process.returncode}"
                if stderr:
                    error_msg += f": {stderr.decode('utf-8', errors='ignore')}"
                logger.error(error_msg)
                return False, error_msg

        except asyncio.TimeoutError:
            error_msg = f"Installation timed out after 10 minutes"
            logger.error(error_msg)
            return False, error_msg

        except Exception as e:
            error_msg = f"Installation exception: {str(e)}"
            logger.error(error_msg)
            return False, error_msg

    def get_suggested_params(self, file_path: str) -> str:
        """
        Get suggested install parameters for a given file.

        Args:
            file_path: Path to the installer file

        Returns:
            Suggested install parameters
        """
        return self.detect_install_params(file_path)
