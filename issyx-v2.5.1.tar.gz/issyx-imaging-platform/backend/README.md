# Issyx Imaging Platform - Backend API

FastAPI backend for the Issyx Imaging Platform.

## Prerequisites

- Python 3.11+ (download from [python.org](https://www.python.org/downloads/))
- pip (comes with Python)

## Quick Start

### 1. Install Python

Download and install Python 3.11 or newer from python.org. **Important:** Check "Add Python to PATH" during installation.

### 2. Create Virtual Environment

```bash
cd backend
python -m venv venv
```

### 3. Activate Virtual Environment

**Windows (PowerShell):**
```powershell
.\venv\Scripts\Activate.ps1
```

**Windows (Command Prompt):**
```cmd
venv\Scripts\activate.bat
```

You should see `(venv)` in your terminal prompt.

### 4. Install Dependencies

```bash
pip install -r requirements.txt
```

### 5. Create Environment File

```bash
copy .env.example .env
```

Edit `.env` and update the `SECRET_KEY` if desired.

### 6. Initialize Database

```bash
python init_db.py
```

This creates the SQLite database and seeds it with test data.

### 7. Start the Server

```bash
python server.py
```

The API will be available at:
- **API:** http://localhost:8000
- **API Docs (Swagger UI):** http://localhost:8000/docs
- **Alternative Docs (ReDoc):** http://localhost:8000/redoc

## Default Login Credentials

```
Email: james@issyx.io
Password: password123
```

Additional test users:
- `brandon@issyx.io / password123` (Engineer role)
- `pavan@issyx.io / password123` (Viewer role)

## Project Structure

```
backend/
├── app/
│   ├── core/              # Core configuration
│   │   ├── config.py      # Settings and environment variables
│   │   ├── database.py    # Database connection and session
│   │   └── security.py    # JWT and password hashing
│   ├── models/            # SQLAlchemy database models
│   │   ├── user.py
│   │   ├── customer.py
│   │   ├── job.py
│   │   └── ...
│   ├── routes/            # API endpoints
│   │   ├── auth.py        # Authentication (login, JWT)
│   │   ├── customers.py   # Customer CRUD
│   │   ├── jobs.py        # Job management
│   │   └── ...
│   ├── schemas/           # Pydantic models for validation
│   │   └── auth.py
│   └── main.py            # FastAPI application
├── init_db.py             # Database initialization script
├── server.py              # Server entry point
├── requirements.txt       # Python dependencies
└── .env                   # Environment variables (create from .env.example)
```

## API Endpoints

### Authentication
- `POST /api/v1/auth/login` - Login and get JWT token
- `GET /api/v1/auth/me` - Get current user info

### Resources (all require authentication)
- `GET /api/v1/customers` - List all customers
- `POST /api/v1/customers` - Create customer
- `GET /api/v1/operating-systems` - List OS images
- `GET /api/v1/drivers` - List drivers
- `GET /api/v1/driver-profiles` - List driver profiles
- `GET /api/v1/software` - List software
- `GET /api/v1/scripts` - List scripts
- `GET /api/v1/master-profiles` - List master profiles
- `GET /api/v1/jobs` - List jobs
- `GET /api/v1/users` - List users
- `GET /api/v1/roles` - List roles
- `GET /api/v1/system-settings` - Get system settings

## Testing the API

### Using Swagger UI (Recommended)

1. Start the server: `python server.py`
2. Open http://localhost:8000/docs
3. Click "Authorize" button
4. Click "Try it out" on `/api/v1/auth/token`
5. Enter:
   - username: `james@issyx.io`
   - password: `password123`
6. Click "Execute"
7. Click "Authorize" again and you'll see the token is now set
8. Now you can test any endpoint!

### Using curl

```bash
# Login
curl -X POST "http://localhost:8000/api/v1/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"email":"james@issyx.io","password":"password123"}'

# Get customers (use token from login)
curl -X GET "http://localhost:8000/api/v1/customers" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

## Development

### Database Location

SQLite database is stored at: `../data/issyx.db`

### Reset Database

To reset the database:
1. Stop the server
2. Delete `../data/issyx.db`
3. Run `python init_db.py` again

### Hot Reload

The server runs with `reload=True` by default, so code changes automatically restart the server.

## Next Steps

Once the backend is running:
1. Update the React frontend to call these APIs
2. Add file upload endpoints for OS images, drivers, and software
3. Implement job queue with Celery
4. Add WebSocket support for real-time updates

## Troubleshooting

### Python not found
- Make sure Python is installed and added to PATH
- Try `python --version` or `python3 --version`

### Permission errors on Windows
- Run PowerShell as Administrator
- Or enable script execution: `Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser`

### Port 8000 already in use
- Change the PORT in `.env` file
- Or stop the process using port 8000

### Import errors
- Make sure virtual environment is activated (you should see `(venv)`)
- Run `pip install -r requirements.txt` again
