"""
Add use_custom_pxe_ip column to system_settings table
"""
from app.core.database import engine
from sqlalchemy import text

def add_column():
    try:
        with engine.begin() as conn:
            # Check if column already exists (PostgreSQL)
            result = conn.execute(text("""
                SELECT COUNT(*)
                FROM information_schema.columns
                WHERE table_name='system_settings'
                AND column_name='use_custom_pxe_ip'
            """))
            exists = result.scalar() > 0

            if exists:
                print("Column 'use_custom_pxe_ip' already exists. Skipping.")
                return

            # Add the column (PostgreSQL)
            conn.execute(text(
                "ALTER TABLE system_settings ADD COLUMN use_custom_pxe_ip BOOLEAN DEFAULT FALSE"
            ))
            print("✓ Column 'use_custom_pxe_ip' added successfully!")

    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    add_column()
