<#
.SYNOPSIS
    Issyx Imaging Platform - WinPE PowerShell Client

.DESCRIPTION
    This script runs inside Windows PE on the device being imaged.
    It communicates with the Issyx API to get imaging instructions
    and executes them step by step.

    Workflow:
    1. Detect hardware (MAC address, hostname, IP)
    2. Poll API for next imaging instruction
    3. Execute instruction (DISM, DiskPart, downloads, etc.)
    4. Report progress back to API
    5. Repeat until imaging complete
    6. Reboot into new OS

.NOTES
    Version: 1.0.0
    Requires: Windows PE with PowerShell, DISM, DiskPart
    API Endpoints: /api/v1/jobs/{jobId}/devices/{mac}/instructions
                   /api/v1/jobs/{jobId}/devices/{mac}/progress
                   /api/v1/jobs/{jobId}/devices/{mac}/complete
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory=$false)]
    [string]$ApiBaseUrl = "",  # Will auto-detect from PXE/DHCP if not provided

    [Parameter(Mandatory=$false)]
    [string]$JobId = "",  # Job ID (e.g., "JOB-1042")

    [Parameter(Mandatory=$false)]
    [int]$ProgressIntervalSeconds = 10,  # How often to report progress

    [Parameter(Mandatory=$false)]
    [string]$LogFile = "X:\imaging.log"
)

# Global variables
$script:MacAddress = ""
$script:IpAddress = ""
$script:Hostname = ""
$script:CurrentProgress = 0
$script:CurrentStep = "Initializing"
$script:LogBuffer = @()
$script:ErrorCount = 0
$script:MaxErrors = 5

#region Logging Functions

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")

    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logMessage = "[$timestamp] [$Level] $Message"

    # Write to console
    switch ($Level) {
        "ERROR"   { Write-Host $logMessage -ForegroundColor Red }
        "WARNING" { Write-Host $logMessage -ForegroundColor Yellow }
        "SUCCESS" { Write-Host $logMessage -ForegroundColor Green }
        default   { Write-Host $logMessage }
    }

    # Buffer for API upload
    $script:LogBuffer += $logMessage

    # Write to file
    try {
        Add-Content -Path $LogFile -Value $logMessage -ErrorAction SilentlyContinue
    }
    catch {
        # Ignore file write errors in WinPE
    }
}

#endregion

#region Hardware Detection

function Get-DeviceMacAddress {
    <#
    .SYNOPSIS
        Get the MAC address of the primary network adapter.
    #>
    try {
        $adapter = Get-WmiObject Win32_NetworkAdapterConfiguration |
                   Where-Object { $_.IPEnabled -eq $true } |
                   Select-Object -First 1

        if ($adapter) {
            return $adapter.MACAddress
        }

        throw "No active network adapter found"
    }
    catch {
        Write-Log "Error getting MAC address: $_" -Level "ERROR"
        throw
    }
}

function Get-DeviceIpAddress {
    <#
    .SYNOPSIS
        Get the IP address of the primary network adapter.
    #>
    try {
        $adapter = Get-WmiObject Win32_NetworkAdapterConfiguration |
                   Where-Object { $_.IPEnabled -eq $true } |
                   Select-Object -First 1

        if ($adapter -and $adapter.IPAddress) {
            return $adapter.IPAddress[0]
        }

        return "Unknown"
    }
    catch {
        Write-Log "Error getting IP address: $_" -Level "WARNING"
        return "Unknown"
    }
}

function Get-DeviceHostname {
    <#
    .SYNOPSIS
        Get the current hostname (usually generic in WinPE).
    #>
    try {
        return $env:COMPUTERNAME
    }
    catch {
        return "WINPE"
    }
}

#endregion

#region API Communication

function Invoke-ApiRequest {
    param(
        [string]$Method = "GET",
        [string]$Endpoint,
        [hashtable]$Body = @{}
    )

    $url = "$ApiBaseUrl$Endpoint"

    try {
        $params = @{
            Method = $Method
            Uri = $url
            ContentType = "application/json"
            TimeoutSec = 30
        }

        if ($Method -ne "GET" -and $Body.Count -gt 0) {
            $params.Body = ($Body | ConvertTo-Json -Depth 10)
        }

        $response = Invoke-RestMethod @params
        return $response
    }
    catch {
        Write-Log "API request failed: $Method $url - $_" -Level "ERROR"
        $script:ErrorCount++

        if ($script:ErrorCount -ge $script:MaxErrors) {
            throw "Too many API errors ($script:MaxErrors). Aborting."
        }

        return $null
    }
}

function Get-NextInstruction {
    <#
    .SYNOPSIS
        Get the next imaging instruction from the API.
    #>
    $endpoint = "/api/v1/jobs/$JobId/devices/$script:MacAddress/instructions"

    Write-Log "Requesting next instruction from API"
    $instruction = Invoke-ApiRequest -Method "GET" -Endpoint $endpoint

    return $instruction
}

function Send-ProgressUpdate {
    param(
        [int]$Progress,
        [string]$Step,
        [string]$Status = "running"
    )

    $endpoint = "/api/v1/jobs/$JobId/devices/$script:MacAddress/progress"

    $body = @{
        progress = $Progress
        current_step = $Step
        status = $Status
        log_output = ($script:LogBuffer -join "`n")
    }

    # Clear log buffer after sending
    $script:LogBuffer = @()

    $result = Invoke-ApiRequest -Method "POST" -Endpoint $endpoint -Body $body

    if ($result) {
        Write-Log "Progress updated: $Progress% - $Step"
    }
}

function Send-CompletionReport {
    param(
        [string]$Status,  # "succeeded" or "failed"
        [string]$ErrorMessage = ""
    )

    $endpoint = "/api/v1/jobs/$JobId/devices/$script:MacAddress/complete"

    $totalSeconds = ([datetime]::Now - $script:StartTime).TotalSeconds

    $body = @{
        status = $Status
        total_time_seconds = [int]$totalSeconds
        log = ($script:LogBuffer -join "`n")
    }

    if ($ErrorMessage) {
        $body.error_message = $ErrorMessage
    }

    $result = Invoke-ApiRequest -Method "POST" -Endpoint $endpoint -Body $body

    Write-Log "Completion report sent: $Status" -Level "SUCCESS"
    return $result
}

#endregion

#region Instruction Execution

function Invoke-DiskPart {
    param([array]$Commands)

    Write-Log "Executing DiskPart commands"

    # Create DiskPart script file
    $scriptFile = "X:\diskpart_script.txt"
    $Commands | Out-File -FilePath $scriptFile -Encoding ASCII

    try {
        $output = diskpart /s $scriptFile 2>&1
        Write-Log "DiskPart output: $output"

        if ($LASTEXITCODE -ne 0) {
            throw "DiskPart failed with exit code $LASTEXITCODE"
        }

        Write-Log "DiskPart completed successfully" -Level "SUCCESS"
    }
    finally {
        Remove-Item -Path $scriptFile -ErrorAction SilentlyContinue
    }
}

function Invoke-FileDownload {
    param(
        [string]$Url,
        [string]$Destination,
        [bool]$VerifyHash = $false
    )

    Write-Log "Downloading: $Url -> $Destination"

    # Create destination directory if needed
    $destDir = Split-Path -Path $Destination -Parent
    if (-not (Test-Path $destDir)) {
        New-Item -Path $destDir -ItemType Directory -Force | Out-Null
    }

    try {
        # Use BITS if available (faster), otherwise WebClient
        if (Get-Command Start-BitsTransfer -ErrorAction SilentlyContinue) {
            Start-BitsTransfer -Source $Url -Destination $Destination -ErrorAction Stop
        }
        else {
            $webClient = New-Object System.Net.WebClient
            $webClient.DownloadFile($Url, $Destination)
            $webClient.Dispose()
        }

        Write-Log "Download completed: $Destination" -Level "SUCCESS"
    }
    catch {
        Write-Log "Download failed: $_" -Level "ERROR"
        throw
    }
}

function Invoke-DismApplyImage {
    param(
        [string]$ImageFile,
        [int]$ImageIndex = 1,
        [string]$TargetDrive
    )

    Write-Log "Applying WIM image: $ImageFile (Index $ImageIndex) -> $TargetDrive"

    try {
        $output = dism /Apply-Image /ImageFile:$ImageFile /Index:$ImageIndex /ApplyDir:$TargetDrive 2>&1
        Write-Log "DISM output: $output"

        if ($LASTEXITCODE -ne 0) {
            throw "DISM apply-image failed with exit code $LASTEXITCODE"
        }

        Write-Log "Image applied successfully" -Level "SUCCESS"
    }
    catch {
        Write-Log "DISM apply-image failed: $_" -Level "ERROR"
        throw
    }
}

function Invoke-DismAddDriver {
    param(
        [string]$DriverPath,
        [bool]$Recurse = $true
    )

    Write-Log "Injecting drivers from: $DriverPath"

    try {
        $args = "/Image:C:\ /Add-Driver /Driver:$DriverPath"
        if ($Recurse) {
            $args += " /Recurse"
        }

        $output = dism $args.Split(' ') 2>&1
        Write-Log "DISM driver injection output: $output"

        if ($LASTEXITCODE -ne 0) {
            Write-Log "DISM add-driver completed with warnings/errors" -Level "WARNING"
        }
        else {
            Write-Log "Drivers injected successfully" -Level "SUCCESS"
        }
    }
    catch {
        Write-Log "Driver injection error: $_" -Level "WARNING"
        # Don't throw - driver injection errors are often non-fatal
    }
}

function Invoke-BcdBoot {
    param([array]$Commands)

    Write-Log "Configuring boot loader"

    foreach ($command in $Commands) {
        try {
            $output = Invoke-Expression $command 2>&1
            Write-Log "BCDBoot output: $output"

            if ($LASTEXITCODE -ne 0) {
                throw "BCDBoot failed with exit code $LASTEXITCODE"
            }
        }
        catch {
            Write-Log "BCDBoot error: $_" -Level "ERROR"
            throw
        }
    }

    Write-Log "Boot loader configured" -Level "SUCCESS"
}

function Invoke-ComputerRename {
    param([string]$ComputerName)

    Write-Log "Setting computer name: $ComputerName"

    try {
        # Offline rename using registry
        $registryPath = "C:\Windows\System32\config\SYSTEM"

        reg load HKLM\TempSystem $registryPath
        reg add "HKLM\TempSystem\ControlSet001\Control\ComputerName\ComputerName" /v ComputerName /t REG_SZ /d $ComputerName /f
        reg add "HKLM\TempSystem\ControlSet001\Control\ComputerName\ActiveComputerName" /v ComputerName /t REG_SZ /d $ComputerName /f
        reg add "HKLM\TempSystem\ControlSet001\Services\Tcpip\Parameters" /v Hostname /t REG_SZ /d $ComputerName /f
        reg add "HKLM\TempSystem\ControlSet001\Services\Tcpip\Parameters" /v "NV Hostname" /t REG_SZ /d $ComputerName /f
        reg unload HKLM\TempSystem

        Write-Log "Computer name set successfully" -Level "SUCCESS"
    }
    catch {
        Write-Log "Computer rename error: $_" -Level "WARNING"
        # Non-fatal
    }
}

function Invoke-Instruction {
    param($Instruction)

    $stepName = $Instruction.step_name
    $progressStart = $Instruction.progress_start
    $progressEnd = $Instruction.progress_end
    $actions = $Instruction.actions

    Write-Log "=== Starting Step: $stepName ===" -Level "SUCCESS"
    Send-ProgressUpdate -Progress $progressStart -Step $stepName

    $actionCount = $actions.Count
    $actionIndex = 0

    foreach ($action in $actions) {
        $actionIndex++
        $actionProgress = $progressStart + (($progressEnd - $progressStart) * ($actionIndex / $actionCount))

        Write-Log "Action $actionIndex/$actionCount : $($action.type) - $($action.description)"
        Send-ProgressUpdate -Progress $actionProgress -Step "$stepName - $($action.description)"

        try {
            switch ($action.type) {
                "diskpart" {
                    Invoke-DiskPart -Commands $action.commands
                }
                "download" {
                    Invoke-FileDownload -Url $action.url -Destination $action.destination -VerifyHash $action.verify_hash
                }
                "dism_apply_image" {
                    Invoke-DismApplyImage -ImageFile $action.image_file -ImageIndex $action.image_index -TargetDrive $action.target_drive
                }
                "dism_add_driver" {
                    Invoke-DismAddDriver -DriverPath $action.driver_path -Recurse $action.recurse
                }
                "bcdboot" {
                    Invoke-BcdBoot -Commands $action.commands
                }
                "rename_computer" {
                    Invoke-ComputerRename -ComputerName $action.computer_name
                }
                "execute" {
                    Write-Log "Executing: $($action.command)"
                    $output = Invoke-Expression $action.command 2>&1
                    Write-Log "Output: $output"
                }
                "skip" {
                    Write-Log "Skipping: $($action.description)" -Level "WARNING"
                }
                "complete" {
                    Write-Log "Imaging complete!" -Level "SUCCESS"
                    if ($action.reboot) {
                        Write-Log "System will reboot in 10 seconds..."
                    }
                }
                default {
                    Write-Log "Unknown action type: $($action.type)" -Level "WARNING"
                }
            }
        }
        catch {
            Write-Log "Action failed: $_" -Level "ERROR"
            throw
        }
    }

    Write-Log "=== Step Complete: $stepName ===" -Level "SUCCESS"
    Send-ProgressUpdate -Progress $progressEnd -Step "$stepName completed"
}

#endregion

#region Main Execution

function Start-ImagingProcess {
    Write-Log "==============================================="
    Write-Log "Issyx Imaging Platform - WinPE Client v1.0.0"
    Write-Log "==============================================="

    # Detect hardware
    Write-Log "Detecting hardware..."
    $script:MacAddress = Get-DeviceMacAddress
    $script:IpAddress = Get-DeviceIpAddress
    $script:Hostname = Get-DeviceHostname

    Write-Log "MAC Address: $script:MacAddress"
    Write-Log "IP Address: $script:IpAddress"
    Write-Log "Hostname: $script:Hostname"

    # Auto-detect API base URL if not provided
    if (-not $ApiBaseUrl) {
        # Try to get DHCP next-server option (typically the PXE server)
        $adapter = Get-WmiObject Win32_NetworkAdapterConfiguration | Where-Object { $_.IPEnabled -eq $true } | Select-Object -First 1
        if ($adapter.DHCPServer) {
            $ApiBaseUrl = "http://$($adapter.DHCPServer):8000"
            Write-Log "Auto-detected API base URL: $ApiBaseUrl"
        }
        else {
            throw "API base URL not provided and could not be auto-detected"
        }
    }

    # Send initial progress
    Send-ProgressUpdate -Progress 0 -Step "WinPE client started - Waiting for instructions"

    # Main imaging loop
    $script:StartTime = [datetime]::Now
    $complete = $false

    while (-not $complete) {
        try {
            # Get next instruction
            $instruction = Get-NextInstruction

            if (-not $instruction) {
                Write-Log "Failed to get instruction from API. Retrying in 30 seconds..." -Level "WARNING"
                Start-Sleep -Seconds 30
                continue
            }

            # Check if imaging is complete
            if ($instruction.complete -eq $true) {
                Write-Log "Imaging process complete!" -Level "SUCCESS"
                $complete = $true
                break
            }

            # Execute the instruction
            Invoke-Instruction -Instruction $instruction

            # Update progress
            $script:CurrentProgress = $instruction.progress_end
            $script:CurrentStep = "$($instruction.step_name) completed"

        }
        catch {
            Write-Log "Error during imaging: $_" -Level "ERROR"

            # Send failure report
            Send-CompletionReport -Status "failed" -ErrorMessage $_.Exception.Message

            throw
        }
    }

    # Send success report
    Send-CompletionReport -Status "succeeded"

    Write-Log "==============================================="
    Write-Log "Imaging completed successfully!"
    Write-Log "Total time: $(([datetime]::Now - $script:StartTime).ToString('hh\:mm\:ss'))"
    Write-Log "Rebooting in 10 seconds..."
    Write-Log "==============================================="

    Start-Sleep -Seconds 10
    wpeutil reboot
}

#endregion

# Script entry point
try {
    Start-ImagingProcess
}
catch {
    Write-Log "FATAL ERROR: $_" -Level "ERROR"
    Write-Log "Imaging failed. System will remain in WinPE for troubleshooting."
    Write-Log "Press any key to retry, or Ctrl+C to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")

    # Retry
    & $MyInvocation.MyCommand.Path @PSBoundParameters
}
