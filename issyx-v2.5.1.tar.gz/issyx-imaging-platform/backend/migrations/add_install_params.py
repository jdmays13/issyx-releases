"""
Database Migration: Add install_params column to software_catalog

This migration adds the install_params column to store silent install parameters
for automated software installation.

Run this script directly:
    python backend/migrations/add_install_params.py
"""
import sys
from pathlib import Path

# Add parent directory to path for imports
backend_dir = Path(__file__).parent.parent
sys.path.insert(0, str(backend_dir))

from sqlalchemy import text
from app.core.database import engine
from app.core.config import settings

def migrate():
    """Apply the migration"""
    print("Starting migration: add_install_params")
    print(f"Database URL: {settings.DATABASE_URL}")

    with engine.begin() as conn:
        # Check if column already exists
        if 'postgresql' in settings.DATABASE_URL:
            check_query = text("""
                SELECT column_name
                FROM information_schema.columns
                WHERE table_name='software_catalog' AND column_name='install_params'
            """)
        else:  # SQLite
            check_query = text("""
                PRAGMA table_info(software_catalog)
            """)

        result = conn.execute(check_query)

        if 'postgresql' in settings.DATABASE_URL:
            exists = result.fetchone() is not None
        else:  # SQLite
            columns = [row[1] for row in result.fetchall()]
            exists = 'install_params' in columns

        if exists:
            print("Column 'install_params' already exists, skipping migration")
            return

        # Add the column
        print("Adding 'install_params' column to software_catalog table...")

        if 'postgresql' in settings.DATABASE_URL:
            alter_query = text("""
                ALTER TABLE software_catalog
                ADD COLUMN install_params VARCHAR(500)
            """)
        else:  # SQLite
            alter_query = text("""
                ALTER TABLE software_catalog
                ADD COLUMN install_params VARCHAR(500)
            """)

        conn.execute(alter_query)

        print("Migration completed successfully")
        print("  - Added column: install_params (VARCHAR(500))")


def rollback():
    """Rollback the migration"""
    print("Rolling back migration: add_install_params")
    print(f"Database URL: {settings.DATABASE_URL}")

    with engine.begin() as conn:
        print("Removing 'install_params' column from software_catalog table...")

        if 'postgresql' in settings.DATABASE_URL:
            rollback_query = text("""
                ALTER TABLE software_catalog
                DROP COLUMN install_params
            """)
        else:  # SQLite doesn't support DROP COLUMN easily
            print("WARNING: SQLite doesn't support DROP COLUMN. Manual rollback required.")
            return

        conn.execute(rollback_query)

        print("Rollback completed successfully")


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Database migration: add_install_params")
    parser.add_argument('--rollback', action='store_true', help='Rollback the migration')
    args = parser.parse_args()

    try:
        if args.rollback:
            rollback()
        else:
            migrate()
    except Exception as e:
        print(f"X Migration failed: {e}")
        sys.exit(1)
