-- Migration: Add system_config column to master_profiles table
-- This adds support for computer naming templates and system configuration

ALTER TABLE master_profiles ADD COLUMN IF NOT EXISTS system_config JSON;

COMMENT ON COLUMN master_profiles.system_config IS 'System configuration including computer naming template, local admin, DNS, power settings, etc.';

-- Example system_config structure:
-- {
--   "computerNameTemplate": "CORP-%serial%",
--   "localAdmin": {
--     "enabled": true,
--     "username": "LocalAdmin",
--     "password": "SecurePass123"
--   },
--   "powerSettings": {
--     "highPerformance": true
--   },
--   "removeBloatware": true,
--   "enableRDP": true,
--   "disableDefender": false,
--   "dnsServers": {
--     "enabled": true,
--     "primary": "8.8.8.8",
--     "secondary": "8.8.4.4"
--   }
-- }
