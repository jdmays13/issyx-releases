-- Migration: Add SHA256 hash columns for duplicate detection
-- Date: 2025-11-14
-- Description: Add hash_sha256 columns to operating_systems and software_catalog for duplicate detection

-- Add hash column to operating_systems
ALTER TABLE operating_systems
ADD COLUMN IF NOT EXISTS hash_sha256 VARCHAR(64),
ADD COLUMN IF NOT EXISTS architecture VARCHAR(20) DEFAULT 'x64';

-- Add unique index on hash (allows NULL for existing records without files)
CREATE UNIQUE INDEX IF NOT EXISTS idx_os_hash ON operating_systems(hash_sha256) WHERE hash_sha256 IS NOT NULL;

-- Add hash column to software_catalog
ALTER TABLE software_catalog
ADD COLUMN IF NOT EXISTS hash_sha256 VARCHAR(64);

-- Add unique index on hash (allows NULL for existing records without files)
CREATE UNIQUE INDEX IF NOT EXISTS idx_software_hash ON software_catalog(hash_sha256) WHERE hash_sha256 IS NOT NULL;

-- Verification queries
SELECT 'Operating Systems:' as table_name, COUNT(*) as total_records, COUNT(hash_sha256) as records_with_hash FROM operating_systems
UNION ALL
SELECT 'Software Catalog' as table_name, COUNT(*) as total_records, COUNT(hash_sha256) as records_with_hash FROM software_catalog;
