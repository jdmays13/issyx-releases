-- Migration: Remove Driver Profiles
-- Date: 2025-11-14
-- Description: Remove driver_profile_id columns and update driver_mode enum

-- Step 1: Remove driver_profile_id from master_profiles
ALTER TABLE master_profiles DROP COLUMN IF EXISTS driver_profile_id;

-- Step 2: Add task_sequence column to master_profiles
ALTER TABLE master_profiles ADD COLUMN IF NOT EXISTS task_sequence JSONB;

-- Step 3: Update driver_mode enum values
-- Change 'profile' to 'all' for existing records
UPDATE master_profiles SET driver_mode = 'all' WHERE driver_mode = 'profile';

-- Step 4: Remove driver_profile_id from hardware_compatibility
ALTER TABLE hardware_compatibility DROP COLUMN IF EXISTS driver_profile_id;

-- Step 5: Drop driver_profiles table (if exists)
-- Note: Only run this if you're sure you want to remove the entire table
-- DROP TABLE IF EXISTS driver_profiles CASCADE;

-- Verification queries
SELECT COUNT(*) as master_profiles_count FROM master_profiles;
SELECT driver_mode, COUNT(*) as count FROM master_profiles GROUP BY driver_mode;
