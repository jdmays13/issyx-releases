-- Create enum type for imaging mode
DO $$
BEGIN
    CREATE TYPE imagingmode AS ENUM ('unicast', 'multicast');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Add column to jobs table
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name='jobs' AND column_name='imaging_mode'
    ) THEN
        ALTER TABLE jobs ADD COLUMN imaging_mode imagingmode DEFAULT 'unicast';
    END IF;
END $$;

-- Update existing jobs: set to multicast if total_devices >= 2
UPDATE jobs SET imaging_mode = 'multicast' WHERE total_devices >= 2;
