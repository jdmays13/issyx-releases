#!/bin/bash
# ===========================================
# Issyx Imaging Platform - Standalone Installer
# ===========================================
# Installs directly on the system (like FOG Project)
# No Docker required - bare-metal installation

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# Installation paths
INSTALL_DIR="/opt/issyx"
DATA_DIR="/data/issyx"
CONFIG_FILE="/etc/issyx/config.env"
LOG_DIR="/var/log/issyx"

echo -e "${GREEN}=====================================${NC}"
echo -e "${GREEN}  Issyx Imaging Platform${NC}"
echo -e "${GREEN}  Standalone Installer (No Docker)${NC}"
echo -e "${GREEN}=====================================${NC}"
echo ""

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   echo -e "${RED}This script must be run as root${NC}"
   echo "Usage: sudo ./install-standalone.sh"
   exit 1
fi

# Detect OS
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$ID
    VERSION=$VERSION_ID
else
    echo -e "${RED}Cannot detect OS${NC}"
    exit 1
fi

echo -e "${BLUE}Detected: $OS $VERSION${NC}"

# Check supported OS
if [[ "$OS" != "ubuntu" && "$OS" != "debian" ]]; then
    echo -e "${RED}Only Ubuntu/Debian are supported${NC}"
    exit 1
fi

# ========================================
# Network Configuration Verification
# ========================================
echo -e "\n${YELLOW}Checking network configuration...${NC}"

# Get primary network interface and IP
PRIMARY_IF=$(ip route | grep default | awk '{print $5}' | head -1)
if [ -z "$PRIMARY_IF" ]; then
    echo -e "${RED}ERROR: No default network interface found${NC}"
    echo "Please configure network connectivity before running this installer."
    exit 1
fi

SERVER_IP=$(ip -4 addr show $PRIMARY_IF | grep inet | awk '{print $2}' | cut -d/ -f1 | head -1)
GATEWAY=$(ip route | grep default | awk '{print $3}' | head -1)
NETMASK=$(ip -4 addr show $PRIMARY_IF | grep inet | awk '{print $2}' | cut -d/ -f2 | head -1)
DNS_SERVERS=$(grep nameserver /etc/resolv.conf | awk '{print $2}' | tr '\n' ' ' | sed 's/ $//')

echo -e "\n${CYAN}Current Network Configuration:${NC}"
echo -e "  Interface:  ${GREEN}$PRIMARY_IF${NC}"
echo -e "  IP Address: ${GREEN}$SERVER_IP${NC}"
echo -e "  Gateway:    ${GREEN}$GATEWAY${NC}"
echo -e "  Netmask:    ${GREEN}/$NETMASK${NC}"
echo -e "  DNS:        ${GREEN}$DNS_SERVERS${NC}"

# Check if IP looks like DHCP (common DHCP ranges)
IS_DHCP=false
if [[ "$SERVER_IP" =~ ^192\.168\.[0-9]+\.(10[0-9]|1[1-9][0-9]|2[0-4][0-9]|25[0-4])$ ]] || \
   [[ "$SERVER_IP" =~ ^10\.[0-9]+\.[0-9]+\.(10[0-9]|1[1-9][0-9]|2[0-4][0-9]|25[0-4])$ ]] || \
   [[ "$SERVER_IP" =~ ^172\.(1[6-9]|2[0-9]|3[01])\.[0-9]+\.(10[0-9]|1[1-9][0-9]|2[0-4][0-9]|25[0-4])$ ]]; then
    IS_DHCP=true
fi

# Check for DHCP lease file
if [ -f /var/lib/dhcp/dhclient.${PRIMARY_IF}.leases ] || [ -f /var/lib/dhclient/dhclient.${PRIMARY_IF}.leases ]; then
    IS_DHCP=true
fi

if [ "$IS_DHCP" = true ]; then
    echo -e "\n${YELLOW}⚠️  WARNING: IP address may be DHCP-assigned${NC}"
    echo -e "For a PXE server, a ${RED}STATIC IP${NC} is strongly recommended."
    echo -e "If the IP changes, WinPE devices won't be able to connect."
fi

echo -e "\n${YELLOW}IMPORTANT:${NC}"
echo -e "This IP address (${GREEN}$SERVER_IP${NC}) will be used for:"
echo -e "  • PXE server endpoint (WinPE devices will connect here)"
echo -e "  • Web interface access"
echo -e "  • API endpoint for all operations"
echo ""

# Check if running in container (LXC/Docker)
IS_CONTAINER=false
if [ -f /.dockerenv ] || grep -q "container=lxc" /proc/1/environ 2>/dev/null || [ -f /run/container_type ]; then
    IS_CONTAINER=true
fi

if [ "$IS_CONTAINER" = true ] && [ "$IS_DHCP" = true ]; then
    echo -e "${YELLOW}Running in container environment.${NC}"
    echo -e "Network configuration should be set at the ${CYAN}container host level${NC}."
    echo -e "\n${BLUE}For Proxmox LXC:${NC}"
    echo -e "  pct set <CTID> -net0 name=eth0,bridge=vmbr0,ip=${SERVER_IP}/${NETMASK},gw=${GATEWAY}"
    echo -e "\n${BLUE}For Proxmox GUI:${NC}"
    echo -e "  Container → Network → Edit → Set IPv4 to Static"
    echo ""
fi

# Ask for confirmation
read -p "Is this IP address correct for your PXE server? (y/N) " confirm
if [[ ! "$confirm" =~ ^[Yy]$ ]]; then
    echo -e "\n${YELLOW}Installation cancelled.${NC}"
    echo "Please configure your network with a static IP before running this installer."
    if [ "$IS_CONTAINER" = true ]; then
        echo -e "\nConfigure the static IP at the container host level (Proxmox), then run this installer again."
    else
        echo -e "\nConfigure a static IP using netplan or /etc/network/interfaces, then run this installer again."
    fi
    exit 0
fi

echo -e "${GREEN}✓ Network configuration confirmed${NC}"

# ========================================
# 1. Install System Dependencies
# ========================================
echo -e "\n${YELLOW}[1/9] Installing system dependencies...${NC}"

apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y \
    python3 \
    python3-pip \
    python3-venv \
    postgresql \
    postgresql-contrib \
    redis-server \
    nginx \
    tftpd-hpa \
    syslinux-common \
    pxelinux \
    curl \
    wget \
    git \
    openssl \
    net-tools \
    iproute2 \
    ipxe \
    nodejs \
    npm

echo -e "${GREEN}✓ System dependencies installed${NC}"

# ========================================
# 2. Create Directory Structure
# ========================================
echo -e "\n${YELLOW}[2/9] Creating directory structure...${NC}"

mkdir -p $INSTALL_DIR/{backend,frontend,boot-files/tftp}
mkdir -p $DATA_DIR/{images,drivers,software,backups,scripts}
mkdir -p /etc/issyx
mkdir -p $LOG_DIR
mkdir -p /var/lib/tftpboot/issyx

# Set permissions
chmod -R 755 $DATA_DIR
chown -R www-data:www-data $DATA_DIR

echo -e "${GREEN}✓ Directories created${NC}"

# ========================================
# 3. Setup PostgreSQL Database
# ========================================
echo -e "\n${YELLOW}[3/9] Configuring PostgreSQL...${NC}"

# Start PostgreSQL if not running
systemctl enable postgresql
systemctl start postgresql

# Generate secure password
DB_PASSWORD=$(openssl rand -hex 16)

# Create database and user (drop if exists for clean install)
sudo -u postgres psql <<EOF
DROP DATABASE IF EXISTS issyx;
DROP USER IF EXISTS issyx;
CREATE USER issyx WITH PASSWORD '$DB_PASSWORD';
CREATE DATABASE issyx OWNER issyx;
GRANT ALL PRIVILEGES ON DATABASE issyx TO issyx;
\c issyx
GRANT ALL ON SCHEMA public TO issyx;
EOF

echo -e "${GREEN}✓ PostgreSQL configured${NC}"

# ========================================
# 4. Setup Redis
# ========================================
echo -e "\n${YELLOW}[4/9] Configuring Redis...${NC}"

REDIS_PASSWORD=$(openssl rand -hex 16)

# Configure Redis with password
sed -i "s/^# requirepass .*/requirepass $REDIS_PASSWORD/" /etc/redis/redis.conf
sed -i "s/^requirepass .*/requirepass $REDIS_PASSWORD/" /etc/redis/redis.conf

systemctl enable redis-server
systemctl restart redis-server

echo -e "${GREEN}✓ Redis configured${NC}"

# ========================================
# 5. Install Backend Application
# ========================================
echo -e "\n${YELLOW}[5/9] Installing backend application...${NC}"

# Get the directory where this script is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Copy backend files
if [ -d "$SCRIPT_DIR/backend" ]; then
    cp -r "$SCRIPT_DIR/backend"/* $INSTALL_DIR/backend/
else
    echo -e "${RED}Backend directory not found. Please run this script from the project root.${NC}"
    exit 1
fi

# Create Python virtual environment
python3 -m venv $INSTALL_DIR/venv

# Install Python dependencies
$INSTALL_DIR/venv/bin/pip install --upgrade pip
$INSTALL_DIR/venv/bin/pip install -r $INSTALL_DIR/backend/requirements.txt

# Generate secret key
SECRET_KEY=$(openssl rand -hex 32)

# Note: PRIMARY_IF, SERVER_IP, GATEWAY, NETMASK already set during network verification

# Create configuration file
cat > $CONFIG_FILE <<EOF
# Issyx Imaging Platform Configuration
# Generated by installer on $(date)

# Database
DATABASE_URL=postgresql://issyx:$DB_PASSWORD@localhost:5432/issyx

# Redis
REDIS_URL=redis://:$REDIS_PASSWORD@localhost:6379/0

# Security
SECRET_KEY=$SECRET_KEY
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=60

# File Storage
DATA_ROOT=$DATA_DIR
MAX_UPLOAD_SIZE=10737418240

# API Configuration
API_V1_PREFIX=/api/v1
BACKEND_CORS_ORIGINS=["http://localhost", "http://$SERVER_IP", "https://$SERVER_IP"]

# Server
HOST=127.0.0.1
PORT=8000
RELOAD=False

# Boot Files
BOOT_FILES_DIR=$INSTALL_DIR/boot-files
OS_IMAGES_DIR=$DATA_DIR/images
DRIVERS_DIR=$DATA_DIR/drivers
SOFTWARE_DIR=$DATA_DIR/software

# Network Configuration (Detected)
PRIMARY_INTERFACE=$PRIMARY_IF
SERVER_IP=$SERVER_IP
GATEWAY=$GATEWAY
NETMASK=$NETMASK

# Project Configuration
PROJECT_NAME=Issyx Imaging Platform
VERSION=2.5.0
EOF

chmod 600 $CONFIG_FILE
chown www-data:www-data $CONFIG_FILE

echo -e "${GREEN}✓ Backend installed${NC}"
echo -e "  Server IP: ${CYAN}$SERVER_IP${NC}"
echo -e "  Interface: ${CYAN}$PRIMARY_IF${NC}"

# ========================================
# 6. Build and Install Frontend
# ========================================
echo -e "\n${YELLOW}[6/9] Building frontend...${NC}"

if [ -d "$SCRIPT_DIR/src" ]; then
    cd "$SCRIPT_DIR"

    # Install Node dependencies
    npm install --silent

    # Build frontend with proper API URL
    VITE_API_URL="http://$SERVER_IP/api/v1" VITE_SKIP_SETUP=false npm run build --silent

    # Copy built frontend
    cp -r dist/* $INSTALL_DIR/frontend/

    echo -e "${GREEN}✓ Frontend built and installed${NC}"
else
    echo -e "${YELLOW}⚠ Frontend source not found. Skipping frontend build.${NC}"
    echo -e "  You can manually build and copy to: $INSTALL_DIR/frontend/"
fi

# ========================================
# 7. Configure System Services
# ========================================
echo -e "\n${YELLOW}[7/9] Configuring system services...${NC}"

# Create systemd service for backend
# Note: Backend runs on 8001 internally, Nginx proxies to it
# Port 8000 is exposed via Nginx for PXE boot clients
cat > /etc/systemd/system/issyx-backend.service <<EOF
[Unit]
Description=Issyx Imaging Platform Backend
After=network.target postgresql.service redis-server.service
Wants=postgresql.service redis-server.service

[Service]
Type=simple
User=www-data
Group=www-data
WorkingDirectory=$INSTALL_DIR/backend
EnvironmentFile=$CONFIG_FILE
ExecStart=$INSTALL_DIR/venv/bin/python -m uvicorn app.main:app --host 127.0.0.1 --port 8001
Restart=always
RestartSec=10
StandardOutput=append:$LOG_DIR/backend.log
StandardError=append:$LOG_DIR/backend.error.log

[Install]
WantedBy=multi-user.target
EOF

# Configure Nginx
cat > /etc/nginx/sites-available/issyx <<EOF
# Issyx Imaging Platform - Nginx Configuration
# Main server on port 80

server {
    listen 80;
    server_name _;

    # Frontend static files
    root $INSTALL_DIR/frontend;
    index index.html;

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml;

    # Client upload size (10GB for OS images)
    client_max_body_size 11G;

    # API proxy (backend runs on 8001 internally)
    location /api/ {
        proxy_pass http://127.0.0.1:8001;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;

        # WebSocket support
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";

        # Extended timeouts for uploads
        proxy_connect_timeout 1800;
        proxy_send_timeout 1800;
        proxy_read_timeout 1800;
        proxy_request_buffering off;
    }

    # Health check endpoint
    location /health {
        proxy_pass http://127.0.0.1:8001/health;
        access_log off;
    }

    # API documentation
    location /docs {
        proxy_pass http://127.0.0.1:8001/docs;
    }

    location /redoc {
        proxy_pass http://127.0.0.1:8001/redoc;
    }

    location /openapi.json {
        proxy_pass http://127.0.0.1:8001/api/v1/openapi.json;
    }

    # Static asset caching (hashed filenames from Vite build)
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
        try_files \$uri =404;
    }

    # Frontend SPA routing - NO CACHE for HTML to ensure latest version loads
    location / {
        add_header Cache-Control "no-cache, no-store, must-revalidate";
        add_header Pragma "no-cache";
        add_header Expires "0";
        try_files \$uri \$uri/ /index.html;
    }
}

# Direct backend access for PXE boot (port 8000)
# This allows PXE clients to connect to :8000 as expected
server {
    listen 8000;
    server_name _;

    # No rate limiting for PXE devices
    location / {
        proxy_pass http://127.0.0.1:8001;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_buffering off;

        # Large file downloads for WIM/ISO
        proxy_connect_timeout 600;
        proxy_send_timeout 600;
        proxy_read_timeout 600;
    }
}
EOF

# Enable site and remove default
ln -sf /etc/nginx/sites-available/issyx /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

# Test nginx configuration
nginx -t

# Configure TFTP
cat > /etc/default/tftpd-hpa <<EOF
TFTP_USERNAME="tftp"
TFTP_DIRECTORY="/var/lib/tftpboot"
TFTP_ADDRESS=":69"
TFTP_OPTIONS="--secure --verbose"
EOF

# Setup iPXE boot files
if [ -f /usr/lib/ipxe/undionly.kpxe ]; then
    cp /usr/lib/ipxe/undionly.kpxe /var/lib/tftpboot/
    echo -e "${GREEN}✓ iPXE bootloader installed${NC}"
else
    echo -e "${YELLOW}⚠ iPXE not found. Downloading...${NC}"
    curl -sSL -o /var/lib/tftpboot/undionly.kpxe http://boot.ipxe.org/undionly.kpxe
fi

# Create iPXE boot script
cat > /var/lib/tftpboot/boot.ipxe <<EOF
#!ipxe
dhcp
chain http://$SERVER_IP:8000/api/v1/boot/config/\${mac} || shell
EOF

# Set TFTP permissions
chown -R tftp:tftp /var/lib/tftpboot
chmod -R 755 /var/lib/tftpboot

# Set backend permissions
chown -R www-data:www-data $INSTALL_DIR
chmod -R 755 $INSTALL_DIR

echo -e "${GREEN}✓ Services configured${NC}"

# ========================================
# 8. Initialize Database
# ========================================
echo -e "\n${YELLOW}[8/9] Initializing database...${NC}"

cd $INSTALL_DIR/backend

# Set essential environment variables for database initialization
export DATABASE_URL="postgresql://issyx:$DB_PASSWORD@localhost:5432/issyx"
export SECRET_KEY="$SECRET_KEY"
export REDIS_URL="redis://:$REDIS_PASSWORD@localhost:6379/0"
export API_V1_PREFIX="/api/v1"
export PROJECT_NAME="Issyx Imaging Platform"
export VERSION="2.5.0"
export DATA_ROOT="$DATA_DIR"
export BOOT_FILES_DIR="$INSTALL_DIR/boot-files"
export OS_IMAGES_DIR="$DATA_DIR/images"
export DRIVERS_DIR="$DATA_DIR/drivers"
export SOFTWARE_DIR="$DATA_DIR/software"
export ISSYX_SERVER_IP="$SERVER_IP"

# Initialize database as www-data
sudo -u www-data -E $INSTALL_DIR/venv/bin/python init_db.py

echo -e "${GREEN}✓ Database initialized${NC}"

# ========================================
# 9. Start Services
# ========================================
echo -e "\n${YELLOW}[9/9] Starting services...${NC}"

# Reload systemd
systemctl daemon-reload

# Enable and start services
systemctl enable issyx-backend
systemctl start issyx-backend

systemctl enable nginx
systemctl restart nginx

systemctl enable tftpd-hpa
systemctl restart tftpd-hpa

# Wait for backend to start
echo "Waiting for backend to start..."
sleep 5

# Verify services
echo ""
echo -e "${BLUE}Service Status:${NC}"

if systemctl is-active --quiet issyx-backend; then
    echo -e "  ${GREEN}✓${NC} Backend:    Running"
else
    echo -e "  ${RED}✗${NC} Backend:    Failed - Check: journalctl -u issyx-backend"
fi

if systemctl is-active --quiet nginx; then
    echo -e "  ${GREEN}✓${NC} Nginx:      Running"
else
    echo -e "  ${RED}✗${NC} Nginx:      Failed - Check: systemctl status nginx"
fi

if systemctl is-active --quiet tftpd-hpa; then
    echo -e "  ${GREEN}✓${NC} TFTP:       Running"
else
    echo -e "  ${RED}✗${NC} TFTP:       Failed - Check: systemctl status tftpd-hpa"
fi

if systemctl is-active --quiet postgresql; then
    echo -e "  ${GREEN}✓${NC} PostgreSQL: Running"
else
    echo -e "  ${RED}✗${NC} PostgreSQL: Failed"
fi

if systemctl is-active --quiet redis-server; then
    echo -e "  ${GREEN}✓${NC} Redis:      Running"
else
    echo -e "  ${RED}✗${NC} Redis:      Failed"
fi

# ========================================
# Installation Complete
# ========================================
echo ""
echo -e "${GREEN}=====================================${NC}"
echo -e "${GREEN}  Installation Complete!${NC}"
echo -e "${GREEN}=====================================${NC}"
echo ""
echo -e "${YELLOW}Access URLs:${NC}"
echo "  Web Interface: http://$SERVER_IP"
echo "  API Docs:      http://$SERVER_IP/docs"
echo "  PXE Boot:      http://$SERVER_IP:8000"
echo ""
echo -e "${YELLOW}Network Configuration:${NC}"
echo "  Server IP:     $SERVER_IP"
echo "  Interface:     $PRIMARY_IF"
echo "  Gateway:       $GATEWAY"
echo ""
echo -e "${YELLOW}Important Paths:${NC}"
echo "  Installation:  $INSTALL_DIR"
echo "  Data Storage:  $DATA_DIR"
echo "  Configuration: $CONFIG_FILE"
echo "  Logs:          $LOG_DIR"
echo "  TFTP Root:     /var/lib/tftpboot"
echo ""
echo -e "${YELLOW}Service Management:${NC}"
echo "  Status:   systemctl status issyx-backend"
echo "  Logs:     journalctl -u issyx-backend -f"
echo "  Restart:  systemctl restart issyx-backend"
echo ""
echo -e "${CYAN}Next Steps:${NC}"
echo "  1. Open http://$SERVER_IP in your browser"
echo "  2. Complete the Setup Wizard to create your admin account"
echo "  3. Configure your DHCP server for PXE boot:"
echo ""
echo -e "${YELLOW}     DHCP Options to set:${NC}"
echo "     - Option 66 (Next Server): $SERVER_IP"
echo "     - Option 67 (Boot File):   undionly.kpxe"
echo ""
echo -e "${GREEN}No Docker required - everything runs natively!${NC}"
echo ""

# Save credentials to a file for the admin
cat > /root/issyx-credentials.txt <<EOF
# Issyx Imaging Platform - Installation Credentials
# Generated: $(date)
# IMPORTANT: Keep this file secure!

Database:
  Host:     localhost
  Port:     5432
  Database: issyx
  User:     issyx
  Password: $DB_PASSWORD

Redis:
  Host:     localhost
  Port:     6379
  Password: $REDIS_PASSWORD

Secret Key: $SECRET_KEY

Configuration File: $CONFIG_FILE

Web Interface: http://$SERVER_IP
API Documentation: http://$SERVER_IP/docs
EOF

chmod 600 /root/issyx-credentials.txt
echo -e "${YELLOW}Database credentials saved to: /root/issyx-credentials.txt${NC}"
echo ""
