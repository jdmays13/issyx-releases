# Issyx Imaging Platform

An enterprise-grade network imaging and automation platform for PXE/iPXE + WinPE deployments, featuring intelligent driver matching, real-time job orchestration, and multi-tenant management.

---

## Overview

Issyx Imaging Platform provides a complete solution for automated OS deployment similar to FOG Project but with modern architecture and enhanced features. It supports Windows imaging workflows with smart driver injection, hardware compatibility detection, and real-time progress monitoring.

### Key Features

**Core Imaging**
- PXE/iPXE boot server with TFTP support
- WinPE-based Windows deployment
- Real-time WebSocket progress updates
- Multi-phase job orchestration with retry policies

**Hardware Management**
- Intelligent hardware-to-driver mapping with confidence scoring
- Automated compatibility detection using vendor/device IDs
- Smart driver matching (exact → subsystem → class → generic)

**Device Management**
- PXE boot device registration and discovery
- Dynamic device queue management
- Device state tracking and history monitoring
- Automated job assignment

**Resource Management**
- Operating system image library (WIM format)
- Driver repository with SHA256 duplicate detection
- Software catalog management
- Pre/Post-imaging script automation (PowerShell/Batch)

**Enterprise Features**
- Multi-tenant customer organization
- Role-based access control with custom roles
- Master profiles (OS + Drivers + Software + Scripts)
- Dark mode support throughout

---

## Architecture

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   Frontend  │────▶│   Nginx     │────▶│   Backend   │
│   (React)   │     │   (Proxy)   │     │  (FastAPI)  │
└─────────────┘     └─────────────┘     └─────────────┘
                                              │
                    ┌─────────────────────────┼─────────────────────────┐
                    │                         │                         │
              ┌─────▼─────┐            ┌──────▼──────┐           ┌──────▼──────┐
              │ PostgreSQL│            │    Redis    │           │    TFTP     │
              │ (Database)│            │   (Cache)   │           │   (PXE)     │
              └───────────┘            └─────────────┘           └─────────────┘
```

### Tech Stack

**Backend**
- FastAPI (Python 3.10+) - High-performance async API
- PostgreSQL 14+ - Relational database
- Redis - Caching and session management
- SQLAlchemy - ORM
- Alembic - Database migrations

**Frontend**
- React 18 - Modern hooks-based UI
- Vite - Lightning-fast build tool
- Tailwind CSS 3 - Utility-first styling
- WebSocket - Real-time updates

**Infrastructure**
- Nginx - Reverse proxy and static file serving
- TFTP Server - PXE boot file delivery
- iPXE - Network bootloader

---

## Quick Start

### Installation

Two installation options are available:

| Method | Best For | Docker Required |
|--------|----------|-----------------|
| **Standalone** (Recommended) | Production, LXC containers, bare metal | No |
| **Docker** | Development, quick testing | Yes |

#### Standalone Installation (Recommended)

```bash
# Download latest release
wget https://github.com/jdmays13/issyx-releases/releases/download/v2.5.1/issyx-v2.5.1.tar.gz

# Extract and install
tar -xzf issyx-v2.5.1.tar.gz
cd issyx-imaging-platform
sudo ./install-standalone.sh
```

**Requirements:**
- Ubuntu 22.04+ or Debian 12+
- 4GB RAM minimum (8GB recommended)
- 100GB disk (500GB+ for OS images)
- Static IP address (critical for PXE)
- Root/sudo privileges

The installer automatically:
- Installs all dependencies (Python, PostgreSQL, Redis, Nginx, TFTP, Node.js)
- Creates directory structure
- Builds the frontend
- Configures services
- Initializes database with server IP
- Starts all services

#### Docker Installation (Development)

```bash
git clone https://github.com/issyx/issyx-imaging-platform.git
cd issyx-imaging-platform
cp .env.example .env
docker compose up -d
```

See [INSTALL.md](INSTALL.md) for detailed installation instructions.

---

## Configuration

### System Settings

After installation, configure in the web interface:

- **PXE Server IP** - Auto-detected from system (read-only)
- **TFTP Root Path** - `/var/lib/tftpboot` (standalone)
- **WinPE API Endpoint** - Auto-configured during install
- **Network Interface** - Primary NIC (read-only, configured at host level)

### DHCP Configuration

The platform does NOT include a DHCP server. Configure your existing DHCP server with PXE options:

- **Option 66 (Next Server):** Your Issyx server IP
- **Option 67 (Boot Filename):** `undionly.kpxe`

See [INSTALL.md](INSTALL.md#dhcp-configuration) for examples.

---

## Usage

### Initial Setup

1. Open web interface (http://YOUR_SERVER_IP)
2. Complete setup wizard to create admin account
3. Upload resources:
   - Operating Systems (WIM images)
   - Drivers (INF packages)
   - Software (MSI/EXE)
   - Scripts (PS1/BAT)

### Creating an Imaging Job

1. **Create Master Profile**
   - Select base OS image
   - Add required drivers
   - Add software packages
   - Add pre/post-imaging scripts

2. **Create Customer** (optional)
   - Multi-tenant organization
   - Track jobs by customer

3. **Create Job**
   - Select customer
   - Select master profile
   - Configure job options
   - Start job

4. **PXE Boot Device**
   - Boot target device via PXE
   - Device registers with server
   - Job automatically assigned
   - Real-time progress monitoring

### Role-Based Access

Default roles:
- **Admin** - Full access including user management
- **Engineer** - Create/modify profiles, manage jobs
- **Viewer** - Read-only access

Custom roles can be created with specific permissions.

---

## Project Structure

```
issyx-imaging-platform/
├── backend/                    # FastAPI backend
│   ├── app/
│   │   ├── main.py            # Application entry point
│   │   ├── models/            # SQLAlchemy models
│   │   ├── routes/            # API endpoints
│   │   ├── services/          # Business logic
│   │   └── config.py          # Configuration
│   ├── migrations/            # Alembic migrations
│   └── init_db.py             # Database initialization
├── src/                       # React frontend
│   ├── components/
│   │   ├── pages/             # Page components
│   │   ├── common/            # Shared components
│   │   └── layout/            # Layout components
│   ├── services/
│   │   └── api.js             # API client
│   ├── hooks/                 # Custom React hooks
│   └── App.jsx                # Main application
├── public/                    # Static assets
├── boot-files/                # PXE boot configuration
├── install-standalone.sh      # Standalone installer
├── docker-compose.yml         # Docker configuration
├── INSTALL.md                 # Installation guide
└── README.md                  # This file
```

---

## API Documentation

Interactive API documentation available at:
- **Swagger UI:** http://YOUR_SERVER_IP/docs
- **ReDoc:** http://YOUR_SERVER_IP/redoc

Key API endpoints:
- `/api/v1/jobs` - Job management
- `/api/v1/profiles` - Master profiles
- `/api/v1/devices` - Device management
- `/api/v1/os-images` - OS image library
- `/api/v1/drivers` - Driver management
- `/api/v1/system-settings` - System configuration

---

## Development

### Frontend Development

```bash
# Install dependencies
npm install

# Start development server (with hot reload)
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

### Backend Development

```bash
cd backend

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Linux/Mac
# or
./venv/Scripts/activate   # Windows

# Install dependencies
pip install -r requirements.txt

# Run development server
uvicorn app.main:app --reload --port 8000
```

### Database Migrations

```bash
cd backend

# Create new migration
alembic revision -m "Description of changes"

# Apply migrations
alembic upgrade head

# Rollback migration
alembic downgrade -1
```

---

## Troubleshooting

### Common Issues

**Backend not starting:**
```bash
sudo systemctl status issyx-backend
sudo journalctl -u issyx-backend -n 100
```

**Database connection issues:**
```bash
sudo systemctl status postgresql
sudo -u postgres psql -d issyx -c "\dt"
```

**Frontend not loading:**
```bash
sudo systemctl status nginx
sudo nginx -t
sudo tail -f /var/log/nginx/error.log
```

**PXE boot not working:**
1. Verify DHCP options are configured
2. Check TFTP service: `sudo systemctl status tftpd-hpa`
3. Test TFTP: `tftp localhost -c get undionly.kpxe`
4. Verify boot files exist: `ls -la /var/lib/tftpboot/`

See [INSTALL.md](INSTALL.md#troubleshooting) for more details.

---

## Security Considerations

- Use HTTPS in production (configure SSL in Nginx)
- Change default database passwords
- Restrict network access to management interface
- Regular backups of database and images
- VLAN isolation for imaging network recommended

---

## Support

- **Documentation:** See [INSTALL.md](INSTALL.md) and other .md files
- **Issues:** https://github.com/issyx/issyx-imaging-platform/issues
- **Logs:** `/var/log/issyx/` (standalone) or `docker compose logs`

---

## License

Proprietary - Issyx Internal Use Only

---

**Version:** 2.5.1
**Last Updated:** November 2025
